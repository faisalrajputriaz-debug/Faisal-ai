package com.zariya.assistant

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zariya.assistant.recording.ScreenRecorderService
import com.zariya.assistant.ui.ZariyaViewModel
import com.zariya.assistant.ui.screens.AssistantChatScreen
import com.zariya.assistant.ui.screens.AutomationHubScreen
import com.zariya.assistant.ui.screens.JarvisLiveScreen
import com.zariya.assistant.ui.screens.PermissionsDashboardScreen
import com.zariya.assistant.ui.screens.SettingsPrivacyScreen
import com.zariya.assistant.ui.theme.ObsidianBlack
import com.zariya.assistant.ui.theme.ObsidianSurface
import com.zariya.assistant.ui.theme.ZariyaTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ZariyaTheme {
                val vm: ZariyaViewModel = viewModel()
                var selectedTab by remember { mutableIntStateOf(0) }
                var pendingProjectionMode by remember { mutableStateOf("RECORD") }
                val projectionTrigger by vm.pendingMediaProjectionRequest.collectAsState()

                val permissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) {
                    vm.refreshPermissions()
                }

                val roleLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.StartActivityForResult()
                ) {
                    vm.refreshPermissions()
                }

                val mediaProjectionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                        if (pendingProjectionMode == "SNAPSHOT") {
                            ScreenRecorderService.captureFrame(this, result.resultCode, result.data!!)
                        } else {
                            ScreenRecorderService.startRecording(
                                context = this,
                                resultCode = result.resultCode,
                                data = result.data!!,
                                withMic = vm.memory.recordMicWithScreen
                            )
                        }
                    }
                }

                fun launchMediaProjection(mode: String) {
                    pendingProjectionMode = mode
                    val mgr = getSystemService(MediaProjectionManager::class.java)
                    mediaProjectionLauncher.launch(mgr.createScreenCaptureIntent())
                }

                LaunchedEffect(projectionTrigger) {
                    projectionTrigger?.let { mode ->
                        vm.clearMediaProjectionTrigger()
                        launchMediaProjection(mode)
                    }
                }

                Scaffold(
                    containerColor = ObsidianBlack,
                    bottomBar = {
                        NavigationBar(containerColor = ObsidianSurface) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.GraphicEq, contentDescription = "Live") },
                                label = { Text("Live") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Chat") },
                                label = { Text("Chat") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                icon = { Icon(Icons.Default.Tune, contentDescription = "Control") },
                                label = { Text("Control") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { selectedTab = 3 },
                                icon = { Icon(Icons.Default.Security, contentDescription = "Access") },
                                label = { Text("Access") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 4,
                                onClick = { selectedTab = 4 },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Setup") },
                                label = { Text("Setup") }
                            )
                        }
                    }
                ) { padding ->
                    androidx.compose.foundation.layout.Box(modifier = Modifier.padding(padding)) {
                        when (selectedTab) {
                            0 -> JarvisLiveScreen(vm)
                            1 -> AssistantChatScreen(vm)
                            2 -> AutomationHubScreen(
                                viewModel = vm,
                                onRequestScreenRecord = { launchMediaProjection("RECORD") },
                                onRequestScreenSnapshot = { launchMediaProjection("SNAPSHOT") }
                            )
                            3 -> PermissionsDashboardScreen(
                                viewModel = vm,
                                onRequestPermission = { item ->
                                    when {
                                        item.id == "call_screening" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                                            val rm = getSystemService(RoleManager::class.java)
                                            if (rm?.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) == true) {
                                                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
                                            }
                                        }
                                        item.isSpecialSystemAccess -> {
                                            startActivity(Intent(item.androidPermission))
                                        }
                                        else -> {
                                            permissionLauncher.launch(item.androidPermission)
                                        }
                                    }
                                },
                                onOpenAppSettings = {
                                    startActivity(
                                        Intent(
                                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.fromParts("package", packageName, null)
                                        )
                                    )
                                }
                            )
                            4 -> SettingsPrivacyScreen(vm)
                        }
                    }
                }
            }
        }
    }
}
