package com.zariya.assistant.data.remote

import com.zariya.assistant.BuildConfig
import com.zariya.assistant.data.model.CommandIntentResponse
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

@Serializable
data class CommandRequestDto(
    val text: String,
    val assistantName: String,
    val preferredLanguage: String,
    val persona: String = "punjabi_legend",
    val screenSummary: String? = null,
    val unreadNotificationsCount: Int = 0
)

@Serializable
data class ChatRequestDto(
    val message: String,
    val assistantName: String,
    val preferredLanguage: String,
    val persona: String = "punjabi_legend",
    val history: List<Map<String, String>> = emptyList()
)

@Serializable
data class ChatResponseDto(
    val reply: String,
    val language: String = "en",
    val modelUsed: String? = null
)

@Serializable
data class ScreenAnalyzeRequestDto(
    val imageBase64: String? = null,
    val mimeType: String = "image/jpeg",
    val accessibilitySummary: String? = null,
    val prompt: String = "Summarize what is visible on this screen and highlight actionable items."
)

@Serializable
data class ScreenAnalyzeResponseDto(
    val summary: String,
    val elements: List<String> = emptyList(),
    val suggestedAction: String? = null
)

@Serializable
data class WhatsAppAnalyzeRequestDto(
    val sender: String,
    val message: String,
    val preferredLanguage: String = "auto"
)

@Serializable
data class WhatsAppAnalyzeResponseDto(
    val isUrgent: Boolean,
    val reason: String,
    val suggestedReply: String
)

@Serializable
data class TtsRequestDto(
    val text: String,
    val gender: String = "MALE",
    val persona: String = "punjabi_legend",
    val language: String = "auto"
)

@Serializable
data class TtsResponseDto(
    val audioBase64: String,
    val mimeType: String = "audio/wav",
    val voiceName: String = "Fenrir",
    val persona: String = "punjabi_legend",
    val modelUsed: String? = null
)

interface ZariyaApiService {
    @POST("/api/ai/command")
    suspend fun parseCommand(@Body req: CommandRequestDto): CommandIntentResponse

    @POST("/api/ai/chat")
    suspend fun chat(@Body req: ChatRequestDto): ChatResponseDto

    @POST("/api/ai/analyze-screen")
    suspend fun analyzeScreen(@Body req: ScreenAnalyzeRequestDto): ScreenAnalyzeResponseDto

    @POST("/api/ai/whatsapp-reply")
    suspend fun analyzeWhatsApp(@Body req: WhatsAppAnalyzeRequestDto): WhatsAppAnalyzeResponseDto

    @POST("/api/ai/tts")
    suspend fun tts(@Body req: TtsRequestDto): TtsResponseDto
}

class ZariyaBackendClient(baseUrl: String) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        })
        .build()

    val api: ZariyaApiService = Retrofit.Builder()
        .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
        .client(okHttp)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()
        .create(ZariyaApiService::class.java)
}
