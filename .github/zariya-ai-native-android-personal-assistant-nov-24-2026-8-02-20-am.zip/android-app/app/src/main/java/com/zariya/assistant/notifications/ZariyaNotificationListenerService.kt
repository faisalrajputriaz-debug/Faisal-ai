package com.zariya.assistant.notifications

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.zariya.assistant.ZariyaApplication
import com.zariya.assistant.data.model.AutoReplyAudience
import com.zariya.assistant.data.model.WhatsAppNotificationItem
import com.zariya.assistant.data.remote.WhatsAppAnalyzeRequestDto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap

/**
 * Real NotificationListenerService for authorized WhatsApp & WhatsApp Business notifications.
 * Stores RemoteInput reply actions in memory and honors user-defined auto-reply rules & cooldowns.
 */
class ZariyaNotificationListenerService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        _isConnected.value = true
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        _isConnected.value = false
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (pkg != WHATSAPP_PKG && pkg != WHATSAPP_BUSINESS_PKG) return

        val extras = sbn.notification?.extras ?: return
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val message = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (sender.isEmpty() || message.isEmpty()) return

        // Ignore summary group notifications without actual message body
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val replyAction = findReplyAction(sbn.notification)
        if (replyAction != null) {
            replyActions[sbn.key] = replyAction
        }

        val item = WhatsAppNotificationItem(
            key = sbn.key,
            packageName = pkg,
            senderName = sender,
            messageText = message,
            timestampMs = sbn.postTime,
            isUrgent = detectQuickUrgency(message),
            hasReplyAction = replyAction != null
        )

        val current = _messages.value.filterNot { it.key == sbn.key && it.messageText == message }
        _messages.value = (listOf(item) + current).take(50)

        val app = applicationContext as? ZariyaApplication ?: return
        scope.launch {
            // Optional AI classification & draft reply via server-side Gemini
            runCatching {
                val aiResult = app.backendClient.api.analyzeWhatsApp(
                    WhatsAppAnalyzeRequestDto(
                        sender = sender,
                        message = message,
                        preferredLanguage = app.memoryStore.preferredLanguage.code
                    )
                )
                updateMessageMetadata(item.key, aiResult.isUrgent, aiResult.suggestedReply)
            }

            // Evaluate explicit user-enabled auto-reply rules
            evaluateAutoReply(app, item)
        }
    }

    private fun updateMessageMetadata(key: String, urgent: Boolean, draft: String) {
        _messages.value = _messages.value.map { msg ->
            if (msg.key == key) msg.copy(isUrgent = urgent, aiDraftReply = draft) else msg
        }
    }

    private fun evaluateAutoReply(app: ZariyaApplication, item: WhatsAppNotificationItem) {
        val rule = app.memoryStore.autoReplyRule
        if (!rule.enabled || !item.hasReplyAction) return

        if (rule.scheduleEnabled && !isWithinSchedule(rule.startHour, rule.endHour)) {
            return
        }

        val priorityContacts = app.memoryStore.priorityContacts
        val senderLower = item.senderName.lowercase()
        val isSelected = priorityContacts.any { it.lowercase() == senderLower }

        val allowed = when (rule.audience) {
            AutoReplyAudience.SELECTED_CONTACTS_ONLY,
            AutoReplyAudience.PRIORITY_CONTACTS_ONLY -> isSelected
            AutoReplyAudience.EVERYONE_EXPLICIT -> true
        }
        if (!allowed) return

        // Avoid duplicate replies within cooldown window
        val lastSent = lastReplyTimestamp[senderLower] ?: 0L
        val cooldownMs = rule.cooldownMinutes * 60_000L
        if (System.currentTimeMillis() - lastSent < cooldownMs) return

        val sent = sendReply(item.key, rule.activeTemplate)
        if (sent) {
            lastReplyTimestamp[senderLower] = System.currentTimeMillis()
            _messages.value = _messages.value.map { msg ->
                if (msg.key == item.key) msg.copy(autoReplied = true) else msg
            }
        }
    }

    fun sendReply(notificationKey: String, replyText: String): Boolean {
        val action = replyActions[notificationKey] ?: return false
        val remoteInputs = action.remoteInputs ?: return false
        if (remoteInputs.isEmpty()) return false

        val intent = Intent()
        val bundle = Bundle()
        for (input: RemoteInput in remoteInputs) {
            bundle.putCharSequence(input.resultKey, replyText)
        }
        RemoteInput.addResultsToIntent(remoteInputs, intent, bundle)
        return try {
            action.actionIntent.send(this, 0, intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun findReplyAction(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        return actions.firstOrNull { action ->
            val inputs = action.remoteInputs
            inputs != null && inputs.isNotEmpty()
        }
    }

    private fun detectQuickUrgency(text: String): Boolean {
        val lower = text.lowercase()
        return listOf("urgent", "emergency", "asap", "jaldi", "zaroori", "call me", "fouri").any {
            lower.contains(it)
        }
    }

    private fun isWithinSchedule(startHour: Int, endHour: Int): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (startHour <= endHour) {
            hour in startHour..endHour
        } else {
            hour >= startHour || hour <= endHour
        }
    }

    companion object {
        const val WHATSAPP_PKG = "com.whatsapp"
        const val WHATSAPP_BUSINESS_PKG = "com.whatsapp.w4b"

        @Volatile
        var instance: ZariyaNotificationListenerService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected

        private val _messages = MutableStateFlow<List<WhatsAppNotificationItem>>(emptyList())
        val messages: StateFlow<List<WhatsAppNotificationItem>> = _messages

        private val replyActions = ConcurrentHashMap<String, Notification.Action>()
        private val lastReplyTimestamp = ConcurrentHashMap<String, Long>()
    }
}
