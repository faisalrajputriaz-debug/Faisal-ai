package com.zariya.assistant.orchestrator

import android.content.Context
import com.zariya.assistant.ZariyaApplication
import com.zariya.assistant.accessibility.ZariyaAccessibilityService
import com.zariya.assistant.calls.CallControlHelper
import com.zariya.assistant.calls.ZariyaCallScreeningService
import com.zariya.assistant.control.DeviceControlManager
import com.zariya.assistant.data.model.CommandIntentResponse
import com.zariya.assistant.data.model.DailyTaskItem
import com.zariya.assistant.data.model.TaskExecutionReport
import com.zariya.assistant.data.remote.ChatRequestDto
import com.zariya.assistant.data.remote.CommandRequestDto
import com.zariya.assistant.data.remote.ScreenAnalyzeRequestDto
import com.zariya.assistant.notifications.ZariyaNotificationListenerService
import com.zariya.assistant.recording.ScreenRecorderService
import java.util.UUID

/**
 * 6-Step Jarvis Command Execution Pipeline for SMW AI:
 * 1. Understand request locally via LocalCommandMatcher (or Gemini AI backend for open-ended queries)
 * 2. Identify target app/action
 * 3. Check required Android permissions & service bindings
 * 4. Request confirmation if sensitive/unconfigured
 * 5. Execute native Android capability
 * 6. Return truthful TaskExecutionReport
 */
class JarvisCommandOrchestrator(
    private val context: Context,
    private val deviceControl: DeviceControlManager,
    private val callControl: CallControlHelper,
    private val onRequestMediaProjectionStart: () -> Unit,
    private val onRequestMediaProjectionSnapshot: () -> Unit,
    private val onSpeakResponse: (String) -> Unit
) {

    suspend fun processCommand(
        rawCommand: String,
        confirmedSensitiveAction: Boolean = false
    ): Pair<String, TaskExecutionReport> {
        val app = context.applicationContext as ZariyaApplication
        val accessibility = ZariyaAccessibilityService.instance
        val screenSnap = accessibility?.captureCurrentScreen()
        val unreadCount = ZariyaNotificationListenerService.messages.value.size

        // 1. Try deterministic on-device local command matcher first (zero network latency, immune to 503)
        val localMatch = LocalCommandMatcher.match(rawCommand)
        val source: String
        val parsed: CommandIntentResponse

        if (localMatch != null) {
            source = "Local Native Engine"
            parsed = localMatch
        } else if (!LocalCommandMatcher.isLikelyDeviceAction(rawCommand)) {
            // Conversational greeting or Q&A -> route directly to fast conversational /api/ai/chat endpoint
            source = "Gemini AI"
            val chatResult = runCatching {
                app.backendClient.api.chat(
                    ChatRequestDto(
                        message = rawCommand,
                        assistantName = app.memoryStore.assistantName,
                        preferredLanguage = app.memoryStore.preferredLanguage.code,
                        persona = app.memoryStore.voicePersona.apiValue
                    )
                )
            }
            return chatResult.fold(
                onSuccess = { chatRes ->
                    onSpeakResponse(chatRes.reply)
                    Pair(
                        chatRes.reply,
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "CONVERSATIONAL_CHAT",
                            requiredPermission = "INTERNET (Gemini Chat)",
                            actionPerformed = chatRes.modelUsed?.let { "Conversational reply via $it" }
                                ?: "Conversational reply via Gemini AI",
                            succeeded = true,
                            executionSource = source
                        )
                    )
                },
                onFailure = { err ->
                    val errorText = err.message ?: "AI chat server unavailable"
                    onSpeakResponse("AI server is currently busy. Native device commands still work offline.")
                    Pair(
                        errorText,
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "CONVERSATIONAL_CHAT",
                            requiredPermission = "INTERNET",
                            actionPerformed = "Attempted conversational reply via /api/ai/chat",
                            succeeded = false,
                            failureReason = errorText,
                            executionSource = source
                        )
                    )
                }
            )
        } else {
            source = "Gemini AI"
            parsed = runCatching {
                app.backendClient.api.parseCommand(
                    CommandRequestDto(
                        text = rawCommand,
                        assistantName = app.memoryStore.assistantName,
                        preferredLanguage = app.memoryStore.preferredLanguage.code,
                        persona = app.memoryStore.voicePersona.apiValue,
                        screenSummary = screenSnap?.visibleTexts?.take(12)?.joinToString(" | "),
                        unreadNotificationsCount = unreadCount
                    )
                )
            }.getOrElse { err ->
                val errorText = err.message ?: "AI server unavailable"
                onSpeakResponse("AI server is currently busy. Native device commands still work offline.")
                return Pair(
                    errorText,
                    TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "AI_COMMAND_PARSE",
                        requiredPermission = "INTERNET",
                        actionPerformed = "Attempted device-action parsing via Gemini AI",
                        succeeded = false,
                        failureReason = errorText,
                        executionSource = source
                    )
                )
            }
        }

        if (parsed.needsConfirmation && !confirmedSensitiveAction) {
            val prompt = parsed.confirmationPrompt ?: parsed.spokenReply
            onSpeakResponse(prompt)
            return Pair(
                prompt,
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = parsed.requiredPermission,
                    actionPerformed = "Awaiting explicit user confirmation",
                    succeeded = false,
                    failureReason = "Confirmation required before executing ${parsed.intent}.",
                    executionSource = source
                )
            )
        }

        val report = executeParsedIntent(app, parsed, rawCommand, source)
        val finalReply = if (report.succeeded) {
            parsed.spokenReply
        } else {
            report.failureReason ?: "Action could not be completed."
        }
        onSpeakResponse(finalReply)
        return Pair(finalReply, report)
    }

    private suspend fun executeParsedIntent(
        app: ZariyaApplication,
        parsed: CommandIntentResponse,
        rawCommand: String,
        source: String
    ): TaskExecutionReport {
        val accessibility = ZariyaAccessibilityService.instance
        val notifListener = ZariyaNotificationListenerService.instance

        return when (parsed.intent.uppercase()) {
            "OPEN_APP" -> {
                val target = parsed.targetApp ?: "WhatsApp"
                val res = deviceControl.openAppByName(target)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_APP ($target)",
                    requiredPermission = "QUERY_ALL_PACKAGES / LAUNCHER_QUERY",
                    actionPerformed = res.getOrElse { "Attempted to open $target" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "YOUTUBE_SEARCH" -> {
                val query = parsed.queryOrText ?: ""
                val res = deviceControl.searchYouTube(query)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "YOUTUBE_SEARCH",
                    requiredPermission = "None (Android Intent)",
                    actionPerformed = res.getOrElse { "Failed YouTube search" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "READ_SCREEN", "EXPLAIN_SCREEN", "ANALYZE_SCREEN" -> {
                if (accessibility == null) {
                    return TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = parsed.intent,
                        requiredPermission = "AccessibilityService (BIND_ACCESSIBILITY_SERVICE)",
                        actionPerformed = "Checked AccessibilityService binding",
                        succeeded = false,
                        failureReason = "Accessibility Service is disabled. Enable SMW AI Screen Reader in Android Settings.",
                        executionSource = source
                    )
                }
                val snap = accessibility.captureCurrentScreen()
                if (snap == null || snap.visibleTexts.isEmpty()) {
                    onRequestMediaProjectionSnapshot()
                    return TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = parsed.intent,
                        requiredPermission = "MediaProjection / AccessibilityService",
                        actionPerformed = "Requested screen frame capture authorization",
                        succeeded = false,
                        failureReason = "No accessible text nodes found; authorize MediaProjection to analyze pixels.",
                        executionSource = source
                    )
                }
                val analysis = runCatching {
                    app.backendClient.api.analyzeScreen(
                        ScreenAnalyzeRequestDto(
                            accessibilitySummary = "App: ${snap.appTitle}\nHeadings: ${snap.headings.joinToString(", ")}\nButtons: ${snap.buttons.joinToString(", ")}\nText: ${snap.visibleTexts.joinToString(" | ")}",
                            prompt = rawCommand
                        )
                    )
                }
                val summary = analysis.getOrNull()?.summary ?: snap.visibleTexts.take(10).joinToString(". ")
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "AccessibilityService",
                    actionPerformed = summary,
                    succeeded = true,
                    executionSource = source
                )
            }

            "SCROLL_DOWN" -> {
                val ok = accessibility?.scrollForward() == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SCROLL_DOWN",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Scrolled down current view." else "Scroll failed.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService or view is not scrollable." else null,
                    executionSource = source
                )
            }

            "SCROLL_UP" -> {
                val ok = accessibility?.scrollBackward() == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SCROLL_UP",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Scrolled up current view." else "Scroll failed.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService or view is not scrollable." else null,
                    executionSource = source
                )
            }

            "NAVIGATE_BACK" -> {
                val ok = accessibility?.performBack() == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "NAVIGATE_BACK",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Performed Android Back action." else "Back action failed.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService to navigate back." else null,
                    executionSource = source
                )
            }

            "CLICK_ELEMENT" -> {
                val label = parsed.queryOrText.orEmpty()
                val ok = accessibility?.clickNodeByLabel(label) == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "CLICK_ELEMENT ($label)",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Clicked \"$label\"." else "Could not find clickable \"$label\".",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService or element not visible." else null,
                    executionSource = source
                )
            }

            "TYPE_TEXT" -> {
                val textToFill = parsed.queryOrText.orEmpty()
                val ok = accessibility?.fillFocusedOrFirstEditable(textToFill) == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "TYPE_TEXT",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Typed text into active field." else "No editable field found.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService or focus an editable field." else null,
                    executionSource = source
                )
            }

            "READ_WHATSAPP" -> {
                if (!ZariyaNotificationListenerService.isConnected.value) {
                    return TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "READ_WHATSAPP",
                        requiredPermission = "NotificationListenerService",
                        actionPerformed = "Checked Notification Access",
                        succeeded = false,
                        failureReason = "Notification Listener permission is not enabled in Android Settings.",
                        executionSource = source
                    )
                }
                val msgs = ZariyaNotificationListenerService.messages.value
                val summary = if (msgs.isEmpty()) {
                    "No recent authorized WhatsApp notifications captured yet."
                } else {
                    msgs.take(3).joinToString(" | ") { "${it.senderName}: ${it.messageText}" }
                }
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "READ_WHATSAPP",
                    requiredPermission = "NotificationListenerService",
                    actionPerformed = summary,
                    succeeded = true,
                    executionSource = source
                )
            }

            "REPLY_WHATSAPP" -> {
                val target = parsed.targetContact.orEmpty()
                val replyText = parsed.queryOrText.orEmpty()
                val match = ZariyaNotificationListenerService.messages.value.firstOrNull {
                    target.isEmpty() || it.senderName.contains(target, ignoreCase = true)
                }
                if (notifListener == null || match == null || !match.hasReplyAction) {
                    return TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "REPLY_WHATSAPP",
                        requiredPermission = "NotificationListenerService + RemoteInput",
                        actionPerformed = "Checked active WhatsApp notification reply action",
                        succeeded = false,
                        failureReason = "No active replyable WhatsApp notification found for \"$target\".",
                        executionSource = source
                    )
                }
                val sent = notifListener.sendReply(match.key, replyText)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "REPLY_WHATSAPP (${match.senderName})",
                    requiredPermission = "NotificationListenerService",
                    actionPerformed = if (sent) "Replied to ${match.senderName}: \"$replyText\"" else "Failed sending RemoteInput.",
                    succeeded = sent,
                    failureReason = if (!sent) "PendingIntent reply action rejected by OS." else null,
                    executionSource = source
                )
            }

            "AUTO_REPLY_RULE" -> {
                app.memoryStore.autoReplyRule = app.memoryStore.autoReplyRule.copy(enabled = true)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "AUTO_REPLY_RULE",
                    requiredPermission = "NotificationListenerService",
                    actionPerformed = "Enabled WhatsApp automatic busy reply rule.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "START_RECORDING" -> {
                onRequestMediaProjectionStart()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "START_RECORDING",
                    requiredPermission = "MediaProjection + FOREGROUND_SERVICE_MEDIA_PROJECTION",
                    actionPerformed = "Prompted Android screen-capture consent dialog",
                    succeeded = true,
                    executionSource = source
                )
            }

            "PAUSE_RECORDING" -> {
                ScreenRecorderService.sendControl(context, ScreenRecorderService.ACTION_PAUSE)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "PAUSE_RECORDING",
                    requiredPermission = "MediaProjection",
                    actionPerformed = "Paused active screen recording.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "RESUME_RECORDING" -> {
                ScreenRecorderService.sendControl(context, ScreenRecorderService.ACTION_RESUME)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "RESUME_RECORDING",
                    requiredPermission = "MediaProjection",
                    actionPerformed = "Resumed screen recording.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "STOP_RECORDING" -> {
                ScreenRecorderService.sendControl(context, ScreenRecorderService.ACTION_STOP)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "STOP_RECORDING",
                    requiredPermission = "MediaProjection",
                    actionPerformed = "Stopped active screen recording and saved output.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "CAPTURE_SCREENSHOT" -> {
                onRequestMediaProjectionSnapshot()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "CAPTURE_SCREENSHOT",
                    requiredPermission = "MediaProjection",
                    actionPerformed = "Prompted MediaProjection frame capture for AI Vision.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "ANSWER_CALL" -> {
                val res = callControl.acceptRingingCall()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "ANSWER_CALL",
                    requiredPermission = "ANSWER_PHONE_CALLS",
                    actionPerformed = res.getOrElse { "Attempted to answer call" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "REJECT_CALL", "END_CALL" -> {
                val res = callControl.endOrRejectCall()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "ANSWER_PHONE_CALLS",
                    actionPerformed = res.getOrElse { "Attempted to reject/end call" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "SPEAKERPHONE_ON" -> {
                val res = callControl.setSpeakerphone(true)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SPEAKERPHONE_ON",
                    requiredPermission = "MODIFY_AUDIO_SETTINGS",
                    actionPerformed = res.getOrElse { "Failed speakerphone toggle" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "TELL_CALLER_BUSY" -> {
                val latestNumber = ZariyaCallScreeningService.latestIncomingCall.value?.phoneNumber.orEmpty()
                if (latestNumber.isEmpty()) {
                    TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "TELL_CALLER_BUSY",
                        requiredPermission = "CallScreeningService",
                        actionPerformed = "Checked recent screened caller number",
                        succeeded = false,
                        failureReason = "No recent incoming caller number available.",
                        executionSource = source
                    )
                } else {
                    val res = callControl.openBusyMessageComposer(
                        latestNumber,
                        app.memoryStore.callAssistantConfig.defaultBusyNotice
                    )
                    TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "TELL_CALLER_BUSY",
                        requiredPermission = "Telecom / SMS Intent",
                        actionPerformed = res.getOrElse { "Failed opening SMS busy notice" },
                        succeeded = res.isSuccess,
                        failureReason = res.exceptionOrNull()?.message,
                        executionSource = source
                    )
                }
            }

            "FLASHLIGHT_ON", "FLASHLIGHT_OFF" -> {
                val on = parsed.intent.uppercase() == "FLASHLIGHT_ON"
                val res = deviceControl.setFlashlight(on)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "CAMERA",
                    actionPerformed = res.getOrElse { "Failed flashlight toggle" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "VOLUME_UP", "VOLUME_DOWN", "VOLUME_MUTE" -> {
                val dir = when (parsed.intent.uppercase()) {
                    "VOLUME_UP" -> "up"
                    "VOLUME_DOWN" -> "down"
                    else -> "mute"
                }
                val res = deviceControl.adjustVolume(dir)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "AudioManager",
                    actionPerformed = res.getOrElse { "Failed volume adjustment" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "MEDIA_PLAY", "MEDIA_PAUSE", "MEDIA_NEXT" -> {
                val act = parsed.intent.substringAfter("MEDIA_").lowercase()
                val res = deviceControl.controlMediaPlayback(act)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "AudioManager",
                    actionPerformed = res.getOrElse { "Failed media control" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "SET_ALARM" -> {
                val res = deviceControl.setAlarm(7, 0, parsed.queryOrText ?: "SMW AI Alarm")
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SET_ALARM",
                    requiredPermission = "SET_ALARM",
                    actionPerformed = res.getOrElse { "Failed to open alarm" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "SET_TIMER" -> {
                val res = deviceControl.setTimer(300, parsed.queryOrText ?: "SMW AI Timer")
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SET_TIMER",
                    requiredPermission = "SET_ALARM",
                    actionPerformed = res.getOrElse { "Failed to start timer" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "ADD_NOTE", "ADD_REMINDER" -> {
                val item = DailyTaskItem(
                    id = UUID.randomUUID().toString(),
                    type = if (parsed.intent.uppercase() == "ADD_NOTE") "note" else "reminder",
                    title = parsed.queryOrText ?: rawCommand,
                    detail = "Saved via voice command"
                )
                app.memoryStore.addDailyTask(item)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "EncryptedSharedPreferences (Local)",
                    actionPerformed = "Saved ${item.type}: ${item.title}",
                    succeeded = true,
                    executionSource = source
                )
            }

            "OPEN_SETTINGS" -> {
                val res = deviceControl.openSystemSettings()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_SETTINGS",
                    requiredPermission = "None",
                    actionPerformed = res.getOrDefault("Opened Settings"),
                    succeeded = res.isSuccess,
                    executionSource = source
                )
            }

            "OPEN_CAMERA" -> {
                val res = deviceControl.openCamera()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_CAMERA",
                    requiredPermission = "None",
                    actionPerformed = res.getOrDefault("Opened Camera"),
                    succeeded = res.isSuccess,
                    executionSource = source
                )
            }

            "OPEN_DIALER" -> {
                val res = deviceControl.openDialer()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_DIALER",
                    requiredPermission = "None",
                    actionPerformed = res.getOrDefault("Opened Dialer"),
                    succeeded = res.isSuccess,
                    executionSource = source
                )
            }

            else -> {
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = parsed.requiredPermission,
                    actionPerformed = parsed.spokenReply,
                    succeeded = true,
                    executionSource = source
                )
            }
        }
    }
}
