package com.zariya.assistant.orchestrator

import com.zariya.assistant.data.model.CommandIntentResponse
import java.util.Locale

/**
 * Deterministic on-device multilingual command matcher for SMW AI.
 * Executes Punjabi, Urdu, Roman Urdu, Hindi, and English Android commands locally in <2ms
 * without requiring an external Gemini API round-trip.
 */
object LocalCommandMatcher {

    private fun detectLanguage(text: String): String {
        if (Regex("[\\u0600-\\u06FF]").containsMatchIn(text)) return "ur"
        if (Regex("[\\u0900-\\u097F]").containsMatchIn(text)) return "hi"
        val romanPattern = Regex(
            "\\b(kholo|karo|parho|batao|bata|likho|band|shuru|jalao|uthao|barhao|kam|neeche|upar|peeche|mera|meri|mujhe|main|hoon|hai|kya|aur|abhi|kaun|kis|kisi|bhej|dein|do|lo)\\b",
            RegexOption.IGNORE_CASE
        )
        return if (romanPattern.containsMatchIn(text)) "roman-ur" else "en"
    }

    private fun reply(lang: String, en: String, romanUr: String): String =
        if (lang == "en") en else romanUr

    fun match(rawText: String): CommandIntentResponse? {
        val text = rawText.trim()
        if (text.isEmpty()) return null
        val lower = text.lowercase(Locale.ROOT)
        val lang = detectLanguage(text)

        // 1. Auto-reply rule
        if (Regex("\\b(jis\\s*kisi|everyone|sab\\s*ko|auto\\s*reply|busy\\s*mode)\\b").containsMatchIn(lower) &&
            (lower.contains("message") || lower.contains("whatsapp") || lower.contains("busy") || lower.contains("kaam"))
        ) {
            return CommandIntentResponse(
                intent = "AUTO_REPLY_RULE",
                targetApp = "WhatsApp",
                queryOrText = text,
                requiredPermission = "NotificationListenerService",
                needsConfirmation = true,
                confirmationPrompt = reply(
                    lang,
                    "Enable automatic WhatsApp busy replies for incoming messages? Please confirm.",
                    "Kya main incoming WhatsApp messages par automatic busy reply on kar doon? Confirm karein."
                ),
                spokenReply = reply(lang, "WhatsApp auto-reply rule activated.", "WhatsApp auto-reply rule activate kar diya hai."),
                detectedLanguage = lang
            )
        }

        // 2. WhatsApp open + read latest message
        if ((lower.contains("whatsapp") || text.contains("واٹس ایپ") || text.contains("व्हाट्सएप")) &&
            (lower.contains("message") || lower.contains("parho") || lower.contains("read") || lower.contains("kis") || lower.contains("who"))
        ) {
            return CommandIntentResponse(
                intent = "READ_WHATSAPP",
                targetApp = "WhatsApp",
                requiredPermission = "NotificationListenerService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Reading your latest authorized WhatsApp messages.", "Aapke latest WhatsApp messages parh raha hoon."),
                detectedLanguage = lang
            )
        }

        // 3. Read WhatsApp notifications
        if (Regex("\\b(read|check|summarize|parho|sunao|batao)\\b.*\\b(whatsapp|messages|notifications|unread)\\b").containsMatchIn(lower) ||
            Regex("\\bwho\\s+(just\\s+)?messaged\\b").containsMatchIn(lower) ||
            Regex("\\b(kis\\s*ka|kaun)\\s+message\\b").containsMatchIn(lower) ||
            lower.contains("urgent message")
        ) {
            return CommandIntentResponse(
                intent = "READ_WHATSAPP",
                targetApp = "WhatsApp",
                requiredPermission = "NotificationListenerService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Checking your authorized WhatsApp notifications.", "Authorized WhatsApp notifications check kar raha hoon."),
                detectedLanguage = lang
            )
        }

        // 4. Reply to contact
        val romanReply = Regex("^([a-zA-Z\\u0600-\\u06FF]+)\\s+ko\\s+(?:bata\\s*do|likh\\s*do|message\\s*kar\\s*do|reply\\s*karo)\\s+(?:ke\\s+)?(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (romanReply != null) {
            val contact = romanReply.groupValues[1].trim()
            val msg = romanReply.groupValues[2].trim()
            return CommandIntentResponse(
                intent = "REPLY_WHATSAPP",
                targetApp = "WhatsApp",
                targetContact = contact,
                queryOrText = msg,
                requiredPermission = "NotificationListenerService + RemoteInput",
                needsConfirmation = true,
                confirmationPrompt = reply(lang, "Send reply \"$msg\" to $contact?", "Kya main $contact ko yeh reply bhej doon: \"$msg\"?"),
                spokenReply = reply(lang, "Sent reply to $contact.", "$contact ko reply bhej diya hai."),
                detectedLanguage = lang
            )
        }

        val enReply = Regex("^(?:reply\\s+to|message|tell)\\s+([a-zA-Z]+)\\s+(?:that\\s+)?(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (enReply != null && !enReply.groupValues[1].equals("caller", true) && !enReply.groupValues[1].equals("everyone", true)) {
            val contact = enReply.groupValues[1].trim()
            val msg = enReply.groupValues[2].trim()
            return CommandIntentResponse(
                intent = "REPLY_WHATSAPP",
                targetApp = "WhatsApp",
                targetContact = contact,
                queryOrText = msg,
                requiredPermission = "NotificationListenerService + RemoteInput",
                needsConfirmation = true,
                confirmationPrompt = "Confirm sending WhatsApp reply to $contact: \"$msg\"?",
                spokenReply = "Replied to $contact.",
                detectedLanguage = lang
            )
        }

        // 5. Screen Recording & Screenshot (STOP/PAUSE/RESUME before START)
        if (Regex("\\b(stop|band|end|rok)\\b.*\\b(record|recording)\\b").containsMatchIn(lower) ||
            Regex("\\b(recording)\\b.*\\b(band|stop|rok)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "STOP_RECORDING",
                requiredPermission = "MediaProjection",
                needsConfirmation = false,
                spokenReply = reply(lang, "Stopping screen recording.", "Screen recording band kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(pause)\\b.*\\b(record|recording)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "PAUSE_RECORDING",
                requiredPermission = "MediaProjection",
                needsConfirmation = false,
                spokenReply = reply(lang, "Pausing screen recording.", "Screen recording pause kar di hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(resume)\\b.*\\b(record|recording)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "RESUME_RECORDING",
                requiredPermission = "MediaProjection",
                needsConfirmation = false,
                spokenReply = reply(lang, "Resuming screen recording.", "Screen recording dobara shuru kar di hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(start|begin|shuru|on)\\b.*\\b(screen\\s*record|recording)\\b").containsMatchIn(lower) ||
            Regex("\\b(screen\\s*record|recording)\\b.*\\b(start|shuru)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "START_RECORDING",
                requiredPermission = "MediaProjection + FOREGROUND_SERVICE_MEDIA_PROJECTION",
                needsConfirmation = false,
                spokenReply = reply(lang, "Starting screen recording authorization.", "Screen recording shuru karne ki ijazat maang raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(screenshot|capture\\s*screen|analyze\\s*(?:my\\s*)?screen)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "CAPTURE_SCREENSHOT",
                requiredPermission = "MediaProjection",
                needsConfirmation = false,
                spokenReply = reply(lang, "Requesting screen capture for AI analysis.", "Screen analysis ke liye capture shuru kar raha hoon."),
                detectedLanguage = lang
            )
        }

        // 6. Accessibility Screen Reading & Navigation
        if (Regex("\\b(read\\s*(?:my\\s*)?screen|what\\s*is\\s*written|explain\\s*this\\s*(?:page|screen)|summarize\\s*(?:the\\s*)?(?:current\\s*)?screen)\\b").containsMatchIn(lower) ||
            Regex("\\b(screen\\s*par|screen\\s*parho|kya\\s*likha|is\\s*page\\s*ko\\s*samjhao)\\b").containsMatchIn(lower) ||
            text.contains("اسکرین") || text.contains("स्क्रीन")
        ) {
            return CommandIntentResponse(
                intent = if (lower.contains("explain") || lower.contains("samjhao")) "EXPLAIN_SCREEN" else "READ_SCREEN",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Reading visible screen content.", "Screen par maujood content parh raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(scroll\\s*down|neeche\\s*scroll|niche\\s*karo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SCROLL_DOWN",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Scrolling down.", "Neeche scroll kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(scroll\\s*up|upar\\s*scroll|oopar\\s*karo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SCROLL_UP",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Scrolling up.", "Upar scroll kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(go\\s*back|navigate\\s*back|peeche\\s*jao|back\\s*jao|wapas\\s*jao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "NAVIGATE_BACK",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Going back.", "Back ja raha hoon."),
                detectedLanguage = lang
            )
        }

        val clickMatch = Regex("^(?:click|tap|press|find)\\s+(?:the\\s+)?(.+?)(?:\\s+button)?$", RegexOption.IGNORE_CASE).find(text)
        if (clickMatch != null) {
            val label = clickMatch.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "CLICK_ELEMENT",
                queryOrText = label,
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Clicking $label.", "$label par click kar raha hoon."),
                detectedLanguage = lang
            )
        }

        // 7. Call Handling
        if (Regex("\\b(answer|pick\\s*up|receive|uthao)\\b.*\\b(call)\\b").containsMatchIn(lower) ||
            Regex("\\b(call)\\b.*\\b(receive|uthao|answer)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "ANSWER_CALL",
                requiredPermission = "ANSWER_PHONE_CALLS",
                needsConfirmation = false,
                spokenReply = reply(lang, "Answering incoming call.", "Call receive kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(reject|decline|cut|kaat)\\b.*\\b(call)\\b").containsMatchIn(lower) ||
            Regex("\\b(call)\\b.*\\b(reject|cut|kaat)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "REJECT_CALL",
                requiredPermission = "ANSWER_PHONE_CALLS",
                needsConfirmation = false,
                spokenReply = reply(lang, "Rejecting call.", "Call reject kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(end|disconnect|band)\\b.*\\b(call)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "END_CALL",
                requiredPermission = "ANSWER_PHONE_CALLS",
                needsConfirmation = false,
                spokenReply = reply(lang, "Ending call.", "Call end kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(speaker|speakerphone|loudspeaker)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SPEAKERPHONE_ON",
                requiredPermission = "MODIFY_AUDIO_SETTINGS",
                needsConfirmation = false,
                spokenReply = reply(lang, "Turning speakerphone on.", "Speakerphone on kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(tell\\s*(?:the\\s*)?caller|caller\\s*ko\\s*batao).*\\b(busy)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "TELL_CALLER_BUSY",
                requiredPermission = "Telecom / Authorized SMS Notice",
                needsConfirmation = false,
                spokenReply = reply(lang, "Sending AI assistant busy notice to caller.", "Caller ko AI busy notice bhej raha hoon."),
                detectedLanguage = lang
            )
        }

        // 8. Flashlight, Volume & Media
        if (Regex("\\b(turn\\s*on|on\\s*karo|jalao|enable)\\b.*\\b(flashlight|torch|light)\\b").containsMatchIn(lower) ||
            Regex("\\b(flashlight|torch)\\b.*\\b(on|jalao)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "FLASHLIGHT_ON",
                requiredPermission = "CAMERA",
                needsConfirmation = false,
                spokenReply = reply(lang, "Turning flashlight on.", "Flashlight on kar di hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(turn\\s*off|off\\s*karo|band|bujhao|disable)\\b.*\\b(flashlight|torch|light)\\b").containsMatchIn(lower) ||
            Regex("\\b(flashlight|torch)\\b.*\\b(off|band)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "FLASHLIGHT_OFF",
                requiredPermission = "CAMERA",
                needsConfirmation = false,
                spokenReply = reply(lang, "Turning flashlight off.", "Flashlight band kar di hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(volume\\s*up|increase\\s*volume|awaz\\s*barhao|awaaz\\s*tez)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "VOLUME_UP",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Increasing volume.", "Volume barha raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(volume\\s*down|decrease\\s*volume|awaz\\s*kam|awaaz\\s*halki)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "VOLUME_DOWN",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Decreasing volume.", "Volume kam kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(pause\\s*(?:music|media|video)|gaana\\s*roko)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "MEDIA_PAUSE",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Pausing media.", "Media pause kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(play\\s*(?:music|media)|resume\\s*music|gaana\\s*chalao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "MEDIA_PLAY",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Playing media.", "Media play kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(next\\s*(?:track|song)|agla\\s*gaana)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "MEDIA_NEXT",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Skipping to next track.", "Next track chala raha hoon."),
                detectedLanguage = lang
            )
        }

        // 9. Alarms, Timers, Reminders, Notes
        if (Regex("\\b(set\\s*(?:an\\s*)?alarm|alarm\\s*lagao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SET_ALARM",
                queryOrText = text,
                requiredPermission = "SET_ALARM",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Clock to set alarm.", "Alarm set kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(set\\s*(?:a\\s*)?timer|timer\\s*lagao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SET_TIMER",
                queryOrText = text,
                requiredPermission = "SET_ALARM",
                needsConfirmation = false,
                spokenReply = reply(lang, "Starting timer.", "Timer set kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(remind\\s*me|yaad\\s*dilana|reminder\\s*lagao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "ADD_REMINDER",
                queryOrText = text,
                requiredPermission = "EncryptedSharedPreferences (Local)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Reminder saved.", "Reminder save kar diya hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(add\\s*note|create\\s*note|note\\s*likho|take\\s*a\\s*note)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "ADD_NOTE",
                queryOrText = text,
                requiredPermission = "EncryptedSharedPreferences (Local)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Note saved.", "Note save kar diya hai."),
                detectedLanguage = lang
            )
        }

        // 10. YouTube Search & App Launch
        val ytMatch = Regex("youtube\\s+(?:kholo\\s+(?:aur\\s+)?search\\s+karo|par\\s+search\\s+karo|search)\\s+(.+)", RegexOption.IGNORE_CASE).find(text)
        if (ytMatch != null) {
            val query = ytMatch.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "YOUTUBE_SEARCH",
                targetApp = "YouTube",
                queryOrText = query,
                requiredPermission = "None (Android Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Searching YouTube for $query.", "YouTube par \"$query\" search kar raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(open\\s*settings|settings\\s*kholo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "OPEN_SETTINGS",
                targetApp = "Settings",
                requiredPermission = "None (Android Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Settings.", "Settings khol raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(open\\s*camera|camera\\s*kholo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "OPEN_CAMERA",
                targetApp = "Camera",
                requiredPermission = "None (Android Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Camera.", "Camera khol raha hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(open\\s*dialer|dialer\\s*kholo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "OPEN_DIALER",
                targetApp = "Dialer",
                requiredPermission = "None (Android Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Dialer.", "Phone Dialer khol raha hoon."),
                detectedLanguage = lang
            )
        }

        val openEn = Regex("^open\\s+([a-zA-Z0-9\\s]+)$", RegexOption.IGNORE_CASE).find(text)
        if (openEn != null) {
            val app = openEn.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "OPEN_APP",
                targetApp = app,
                requiredPermission = "QUERY_ALL_PACKAGES / LAUNCHER_QUERY",
                needsConfirmation = false,
                spokenReply = "Opening $app.",
                detectedLanguage = lang
            )
        }

        val openUr = Regex("^([a-zA-Z0-9\\s]+?)\\s+(?:kholo|open\\s*karo|chalao)$", RegexOption.IGNORE_CASE).find(text)
        if (openUr != null) {
            val app = openUr.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "OPEN_APP",
                targetApp = app,
                requiredPermission = "QUERY_ALL_PACKAGES / LAUNCHER_QUERY",
                needsConfirmation = false,
                spokenReply = "$app khol raha hoon.",
                detectedLanguage = lang
            )
        }

        return null
    }

    /**
     * Distinguishes greetings and conversational Q&A from ambiguous OS/device automation requests
     * so normal chat messages route directly to /api/ai/chat instead of /api/ai/command.
     */
    fun isLikelyDeviceAction(rawText: String): Boolean {
        val lower = rawText.trim().lowercase(Locale.ROOT)
        if (Regex("^(hi|hello|hey|salam|assalamualaikum|kya haal|kaise ho|how are you|who are you|what is|explain|tell me|help me)\\b").containsMatchIn(lower)) {
            return false
        }
        return Regex("\\b(open|kholo|launch|scroll|click|tap|record|recording|screenshot|screen|whatsapp|message|reply|call|speaker|flashlight|torch|volume|alarm|timer|camera|dialer|settings|youtube|mute|pause|play|remind|note)\\b").containsMatchIn(lower)
    }
}
