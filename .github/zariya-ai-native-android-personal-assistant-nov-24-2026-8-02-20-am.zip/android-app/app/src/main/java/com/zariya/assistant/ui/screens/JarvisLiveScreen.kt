package com.zariya.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.zariya.assistant.R
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zariya.assistant.data.model.OrbState
import com.zariya.assistant.ui.ZariyaViewModel
import com.zariya.assistant.ui.components.JarvisOrbCanvas
import com.zariya.assistant.ui.theme.ElectricBlue
import com.zariya.assistant.ui.theme.HairlineBorder
import com.zariya.assistant.ui.theme.ObsidianBlack
import com.zariya.assistant.ui.theme.ObsidianSurface
import com.zariya.assistant.ui.theme.SkyCyan
import com.zariya.assistant.ui.theme.StatusError
import com.zariya.assistant.ui.theme.StatusNominal
import com.zariya.assistant.ui.theme.TextMuted
import com.zariya.assistant.ui.theme.TextPrimary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JarvisLiveScreen(viewModel: ZariyaViewModel) {
    val orbState by viewModel.orbState.collectAsState()
    val rmsLevel by viewModel.voiceEngine.rmsLevel.collectAsState()
    val partialTranscript by viewModel.voiceEngine.partialTranscript.collectAsState()
    val handsFree by viewModel.handsFreeActive.collectAsState()
    val report by viewModel.latestTaskReport.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.smw_ai_identity),
            contentDescription = "SMW AI Identity",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .border(2.dp, ElectricBlue, CircleShape)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "${viewModel.memory.assistantName} Live Mode",
            color = TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = when (orbState) {
                OrbState.IDLE -> "Tap the orb to speak or toggle hands-free mode"
                OrbState.LISTENING -> "Listening (Urdu, Roman Urdu, Hindi, English)"
                OrbState.THINKING -> "Understanding intent and verifying permissions"
                OrbState.SPEAKING -> "Speaking — tap orb or speak to interrupt"
            },
            color = SkyCyan,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        JarvisOrbCanvas(
            state = orbState,
            rmsLevel = rmsLevel,
            onClick = {
                if (orbState == OrbState.SPEAKING) {
                    viewModel.voiceEngine.interruptSpeech()
                } else {
                    viewModel.toggleListening(handsFree = false)
                }
            }
        )

        if (partialTranscript.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "\"$partialTranscript\"",
                color = TextPrimary,
                fontSize = 15.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { viewModel.toggleListening(handsFree = false) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (orbState == OrbState.LISTENING) "Stop Mic" else "Speak Command")
            }

            OutlinedButton(
                onClick = { viewModel.voiceEngine.interruptSpeech() },
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, HairlineBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Interrupt Voice", color = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ObsidianSurface,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, HairlineBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Hands-Free Foreground Mode", color = TextPrimary, fontWeight = FontWeight.Medium)
                    Text(
                        "Keeps mic active with visible Android notification",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
                Switch(
                    checked = handsFree,
                    onCheckedChange = { viewModel.toggleListening(handsFree = it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Quick Voice Prompts",
            color = TextMuted,
            fontSize = 13.sp,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))

        val quickCommands = listOf(
            "Meri screen par kya likha hai?",
            "WhatsApp kholo aur latest message parho",
            "Start screen recording",
            "Turn on the flashlight",
            "Scroll down",
            "Go back"
        )
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickCommands.forEach { cmd ->
                OutlinedButton(
                    onClick = { viewModel.sendCommandOrChat(cmd) },
                    border = BorderStroke(1.dp, HairlineBorder),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(cmd, color = TextPrimary, fontSize = 12.sp)
                }
            }
        }

        report?.let { task ->
            Spacer(modifier = Modifier.height(20.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = ObsidianSurface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, HairlineBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (task.succeeded) "Task Succeeded" else "Task Incomplete",
                        color = if (task.succeeded) StatusNominal else StatusError,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Text("Requested: ${task.userRequest}", color = TextPrimary, fontSize = 13.sp)
                    Text("Engine: ${task.executionSource}", color = SkyCyan, fontSize = 12.sp)
                    Text("Action: ${task.identifiedAction}", color = TextMuted, fontSize = 12.sp)
                    Text("Permission: ${task.requiredPermission}", color = SkyCyan, fontSize = 12.sp)
                    Text("Result: ${task.actionPerformed}", color = TextPrimary, fontSize = 13.sp)
                    task.failureReason?.let { reason ->
                        Text("Detail: $reason", color = StatusError, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
