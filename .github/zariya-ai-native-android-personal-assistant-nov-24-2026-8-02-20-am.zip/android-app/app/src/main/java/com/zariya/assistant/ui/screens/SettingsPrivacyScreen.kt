package com.zariya.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zariya.assistant.data.model.AssistantLanguage
import com.zariya.assistant.data.model.VoiceGender
import com.zariya.assistant.data.model.VoicePersona
import com.zariya.assistant.ui.ZariyaViewModel
import com.zariya.assistant.ui.theme.ElectricBlue
import com.zariya.assistant.ui.theme.HairlineBorder
import com.zariya.assistant.ui.theme.ObsidianBlack
import com.zariya.assistant.ui.theme.ObsidianSurface
import com.zariya.assistant.ui.theme.StatusError
import com.zariya.assistant.ui.theme.TextMuted
import com.zariya.assistant.ui.theme.TextPrimary

@Composable
fun SettingsPrivacyScreen(viewModel: ZariyaViewModel) {
    var name by remember { mutableStateOf(viewModel.memory.assistantName) }
    var wakePhrase by remember { mutableStateOf(viewModel.memory.wakePhrase) }
    var wakeEnabled by remember { mutableStateOf(viewModel.memory.wakeWordEnabled) }
    var gender by remember { mutableStateOf(viewModel.memory.voiceGender) }
    var persona by remember { mutableStateOf(viewModel.memory.voicePersona) }
    var language by remember { mutableStateOf(viewModel.memory.preferredLanguage) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Personalization & Memory", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ObsidianSurface,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, HairlineBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        viewModel.memory.assistantName = it
                    },
                    label = { Text("Assistant Name") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = HairlineBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                OutlinedTextField(
                    value = wakePhrase,
                    onValueChange = {
                        wakePhrase = it
                        viewModel.memory.wakePhrase = it
                        viewModel.syncVoiceConfig()
                    },
                    label = { Text("Custom Wake Phrase (Hands-Free Mode)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = HairlineBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Require Wake Phrase in Live Mode", color = TextPrimary, fontSize = 14.sp)
                    Switch(
                        checked = wakeEnabled,
                        onCheckedChange = {
                            wakeEnabled = it
                            viewModel.memory.wakeWordEnabled = it
                            viewModel.syncVoiceConfig()
                        }
                    )
                }

                Text("Voice Persona", color = TextMuted, fontSize = 13.sp)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    VoicePersona.entries.forEach { option ->
                        val selected = persona == option
                        OutlinedButton(
                            onClick = {
                                persona = option
                                viewModel.memory.voicePersona = option
                                if (option == VoicePersona.PUNJABI_LEGEND) {
                                    gender = VoiceGender.MALE
                                    viewModel.memory.voiceGender = VoiceGender.MALE
                                }
                                viewModel.syncVoiceConfig()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, if (selected) ElectricBlue else HairlineBorder)
                        ) {
                            Text(option.label, color = if (selected) ElectricBlue else TextPrimary)
                        }
                    }
                }

                Text("Voice Gender", color = TextMuted, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    VoiceGender.entries.forEach { option ->
                        val selected = gender == option
                        OutlinedButton(
                            onClick = {
                                gender = option
                                viewModel.memory.voiceGender = option
                                viewModel.syncVoiceConfig()
                            },
                            border = BorderStroke(1.dp, if (selected) ElectricBlue else HairlineBorder)
                        ) {
                            Text(option.name, color = if (selected) ElectricBlue else TextPrimary)
                        }
                    }
                }

                Text("Preferred Language", color = TextMuted, fontSize = 13.sp)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistantLanguage.entries.forEach { lang ->
                        val selected = language == lang
                        OutlinedButton(
                            onClick = {
                                language = lang
                                viewModel.memory.preferredLanguage = lang
                                viewModel.syncVoiceConfig()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, if (selected) ElectricBlue else HairlineBorder)
                        ) {
                            Text(lang.label, color = if (selected) ElectricBlue else TextPrimary)
                        }
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ObsidianSurface,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, HairlineBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Encrypted Local Storage", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(
                    "Preferences, templates, and tasks are encrypted locally with AES256-GCM via Android EncryptedSharedPreferences. No silent background spying or unauthorized network uploads occur.",
                    color = TextMuted,
                    fontSize = 12.sp
                )
                Button(
                    onClick = { viewModel.clearAllLocalMemory() },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Clear Local Encrypted Memory")
                }
            }
        }
    }
}
