package com.zariya.assistant.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import com.zariya.assistant.ZariyaApplication
import com.zariya.assistant.data.model.AssistantLanguage
import com.zariya.assistant.data.model.VoiceGender
import com.zariya.assistant.data.model.VoicePersona
import com.zariya.assistant.data.remote.TtsRequestDto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID

class VoiceEngine(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var mediaPlayer: MediaPlayer? = null
    private var currentAudioFile: File? = null
    private var speakJob: Job? = null
    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript

    private var continuousHandsFree = false
    private var wakeWordEnabled = false
    private var wakePhrase = "hey assistant"
    private var currentLanguage = AssistantLanguage.AUTO
    private var currentGender = VoiceGender.MALE
    private var currentPersona = VoicePersona.PUNJABI_LEGEND
    private var onFinalTranscript: ((String) -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    if (continuousHandsFree) {
                        engineScope.launch { startListeningInternal() }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
            applyVoicePreferences(currentLanguage, currentGender, currentPersona)
        }
    }

    fun configure(
        language: AssistantLanguage,
        gender: VoiceGender,
        persona: VoicePersona,
        wakeEnabled: Boolean,
        wakeWord: String
    ) {
        currentLanguage = language
        currentGender = gender
        currentPersona = persona
        wakeWordEnabled = wakeEnabled
        wakePhrase = wakeWord.lowercase(Locale.ROOT).trim()
        if (ttsReady) {
            applyVoicePreferences(language, gender, persona)
        }
    }

    private fun applyVoicePreferences(
        language: AssistantLanguage,
        gender: VoiceGender,
        persona: VoicePersona
    ) {
        val targetLocale = when (language) {
            AssistantLanguage.PUNJABI -> Locale("pa", "IN")
            AssistantLanguage.HINDI -> Locale("hi", "IN")
            AssistantLanguage.URDU, AssistantLanguage.ROMAN_URDU -> Locale("ur", "PK")
            AssistantLanguage.ENGLISH -> Locale.US
            AssistantLanguage.AUTO -> Locale("en", "IN")
        }
        tts?.language = targetLocale

        val isLegend = persona == VoicePersona.PUNJABI_LEGEND
        val effectiveGender = if (isLegend) VoiceGender.MALE else gender
        val availableVoices = tts?.voices.orEmpty()
        val matchingVoice: Voice? = availableVoices.firstOrNull { voice ->
            val localeMatch = voice.locale.language == targetLocale.language ||
                (isLegend && (voice.locale.language == "pa" || voice.locale.language == "hi" || voice.locale.country == "IN"))
            val nameLower = voice.name.lowercase(Locale.ROOT)
            val genderMatch = when (effectiveGender) {
                VoiceGender.FEMALE -> nameLower.contains("female") || nameLower.contains("sfg") || nameLower.contains("tpf") || nameLower.contains("iob")
                VoiceGender.MALE -> nameLower.contains("male") || nameLower.contains("iom") || nameLower.contains("sfb") || nameLower.contains("rjs") || nameLower.contains("iod")
            }
            localeMatch && genderMatch
        }
        if (matchingVoice != null) {
            tts?.voice = matchingVoice
        }

        if (isLegend) {
            // Deep, bass-rich, calm cinematic Punjabi male cadence
            tts?.setPitch(0.76f)
            tts?.setSpeechRate(0.92f)
        } else {
            tts?.setPitch(if (effectiveGender == VoiceGender.FEMALE) 1.06f else 0.88f)
            tts?.setSpeechRate(1.0f)
        }
    }

    fun speak(text: String, interruptCurrent: Boolean = true) {
        val cleanText = text.replace(Regex("[*_`#]+"), "").trim()
        if (cleanText.isBlank()) return
        if (interruptCurrent) {
            interruptSpeech()
        }

        val app = context.applicationContext as? ZariyaApplication
        if (app != null && cleanText.length <= 850) {
            speakJob = engineScope.launch {
                val ttsResponse = withContext(Dispatchers.IO) {
                    runCatching {
                        app.backendClient.api.tts(
                            TtsRequestDto(
                                text = cleanText,
                                gender = if (currentPersona == VoicePersona.PUNJABI_LEGEND) VoiceGender.MALE.name else currentGender.name,
                                persona = currentPersona.apiValue,
                                language = currentLanguage.code
                            )
                        )
                    }.getOrNull()
                }
                if (ttsResponse != null && ttsResponse.audioBase64.isNotBlank()) {
                    val played = playAudioBytes(ttsResponse.audioBase64)
                    if (played) return@launch
                }
                speakWithLocalTts(cleanText)
            }
        } else {
            speakWithLocalTts(cleanText)
        }
    }

    private suspend fun playAudioBytes(base64Audio: String): Boolean {
        return runCatching {
            val bytes = Base64.decode(base64Audio, Base64.DEFAULT)
            if (bytes.isEmpty()) return false

            val tempFile = withContext(Dispatchers.IO) {
                File.createTempFile("smw_voice_", ".wav", context.cacheDir).apply {
                    writeBytes(bytes)
                }
            }
            cleanupMediaPlayer()
            currentAudioFile = tempFile

            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(tempFile.absolutePath)
                setOnCompletionListener {
                    _isSpeaking.value = false
                    cleanupMediaPlayer()
                    if (continuousHandsFree) {
                        engineScope.launch { startListeningInternal() }
                    }
                }
                setOnErrorListener { _, _, _ ->
                    _isSpeaking.value = false
                    cleanupMediaPlayer()
                    true
                }
                prepare()
                start()
            }
            mediaPlayer = player
            _isSpeaking.value = true
            true
        }.getOrDefault(false)
    }

    private fun speakWithLocalTts(text: String) {
        if (!ttsReady || text.isBlank()) return
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, UUID.randomUUID().toString())
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, UUID.randomUUID().toString())
    }

    private fun cleanupMediaPlayer() {
        runCatching {
            mediaPlayer?.stop()
        }
        runCatching {
            mediaPlayer?.release()
        }
        mediaPlayer = null
        runCatching {
            currentAudioFile?.delete()
        }
        currentAudioFile = null
    }

    fun interruptSpeech() {
        speakJob?.cancel()
        speakJob = null
        cleanupMediaPlayer()
        tts?.stop()
        _isSpeaking.value = false
    }

    fun startListening(
        handsFree: Boolean,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        continuousHandsFree = handsFree
        onFinalTranscript = onResult
        onErrorCallback = onError
        // Barge-in: interrupt assistant TTS as soon as user triggers listening
        interruptSpeech()
        startListeningInternal()
    }

    fun stopListening() {
        continuousHandsFree = false
        _isListening.value = false
        _rmsLevel.value = 0f
        speechRecognizer?.stopListening()
        speechRecognizer?.cancel()
    }

    private fun startListeningInternal() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onErrorCallback?.invoke("Android SpeechRecognizer service is not available on this device.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                }

                override fun onBeginningOfSpeech() {
                    interruptSpeech()
                }

                override fun onRmsChanged(rmsdB: Float) {
                    _rmsLevel.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                }

                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                    if (continuousHandsFree && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                        startListeningInternal()
                    } else if (error != SpeechRecognizer.ERROR_CLIENT) {
                        onErrorCallback?.invoke("Voice recognition paused (code $error).")
                    }
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.trim().orEmpty()
                    _partialTranscript.value = ""
                    if (text.isNotEmpty()) {
                        if (wakeWordEnabled && continuousHandsFree) {
                            val lower = text.lowercase(Locale.ROOT)
                            if (lower.contains(wakePhrase)) {
                                val cleaned = text.replace(Regex("(?i)${Regex.escape(wakePhrase)}[,\\s]*"), "").trim()
                                onFinalTranscript?.invoke(cleaned.ifEmpty { "Yes, I am listening." })
                            } else {
                                startListeningInternal()
                            }
                        } else {
                            onFinalTranscript?.invoke(text)
                        }
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    _partialTranscript.value = matches?.firstOrNull().orEmpty()
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val localeTag = when (currentLanguage) {
            AssistantLanguage.PUNJABI -> "pa-IN"
            AssistantLanguage.HINDI -> "hi-IN"
            AssistantLanguage.URDU, AssistantLanguage.ROMAN_URDU -> "ur-PK"
            AssistantLanguage.ENGLISH -> "en-US"
            AssistantLanguage.AUTO -> "en-IN"
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    fun release() {
        stopListening()
        interruptSpeech()
        engineScope.cancel()
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
    }
}
