import crypto from "crypto";

export const DEFAULT_GEMINI_MODELS = [
  "gemini-4-hydrogen",
  "gemini-3.1-flash-lite",
] as const;

export const DEFAULT_TTS_MODELS = [
  "gemini-3.8-flash-lite-tts",
  "gemini-3.8-flash-tts",
] as const;

export const PUNJABI_LEGEND_TTS_MODELS = [
  "gemini-3.8-flash-tts",
  "gemini-3.8-flash-lite-tts",
] as const;

export const PER_MODEL_TIMEOUT_MS = 18_000;

export const HIGH_RISK_CONFIRM_INTENTS = new Set([
  "REPLY_WHATSAPP",
  "AUTO_REPLY_RULE",
  "REJECT_CALL",
  "END_CALL",
  "TELL_CALLER_BUSY",
]);

export interface FallbackExecutionResult<T> {
  result: T;
  modelUsed: string;
}

export function sanitizeSecretStrings(input: string): string {
  return input
    .replace(/AIza[0-9A-Za-z_-]{20,}/g, "[REDACTED_API_KEY]")
    .replace(/AQ\.[0-9A-Za-z._-]{16,}/g, "[REDACTED_TOKEN]")
    .replace(/Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi, "Bearer [REDACTED_TOKEN]")
    .replace(/ya29\.[0-9A-Za-z\-_]+/g, "[REDACTED_OAUTH_TOKEN]");
}

const VALID_GEMINI_MODEL_RE = /^gemini-[a-z0-9]+(?:[.-][a-z0-9]+)*$/i;

export function normalizeGeminiModelName(rawModel: string): string | null {
  const clean = rawModel.trim().replace(/^models\//i, "");
  if (!clean || !VALID_GEMINI_MODEL_RE.test(clean)) return null;
  return clean;
}

export function resolveGeminiModelConfig(
  envValue?: string,
  primaryEnvValue?: string,
): { models: string[] } {
  const rawPrimary = (primaryEnvValue ?? process.env.GEMINI_PRIMARY_MODEL ?? "").trim();
  const rawFallbacks = (envValue ?? process.env.GEMINI_MODEL_FALLBACKS ?? "").trim();
  const banned = new Set([
    "gemini-1.5-flash",
    "gemini-1.5-pro",
    "gemini-pro",
    "gemini-2.0-flash",
    "gemini-2.0-pro",
    "gemini-2.0-flash-thinking",
  ]);
  const rawParts = [
    ...(rawPrimary ? [rawPrimary] : []),
    ...(rawFallbacks ? rawFallbacks.split(",") : []),
  ];
  if (rawParts.length === 0) {
    return { models: [...DEFAULT_GEMINI_MODELS] };
  }
  const seen = new Set<string>();
  const parsed: string[] = [];
  for (const part of rawParts) {
    const clean = normalizeGeminiModelName(part);
    if (!clean || banned.has(clean.toLowerCase()) || seen.has(clean)) continue;
    seen.add(clean);
    parsed.push(clean);
  }
  if (parsed.length === 0) {
    return { models: [...DEFAULT_GEMINI_MODELS] };
  }
  for (const fallbackDefault of DEFAULT_GEMINI_MODELS) {
    if (!seen.has(fallbackDefault)) {
      seen.add(fallbackDefault);
      parsed.push(fallbackDefault);
    }
  }
  return { models: parsed };
}

function isPermanentAuthError(err: unknown): boolean {
  const status = (err as { status?: number })?.status;
  const msg = err instanceof Error ? err.message : String(err);
  if (status === 401) return true;
  return /API_KEY_INVALID|invalid api key|unauthorized/i.test(msg);
}

export async function executeWithGeminiFallback<T>(
  runner: (model: string) => Promise<T>,
  options?: { models?: readonly string[]; timeoutMs?: number },
): Promise<FallbackExecutionResult<T>> {
  const models =
    options?.models && options.models.length > 0
      ? [...new Set(options.models)]
      : resolveGeminiModelConfig().models;
  const timeoutMs = options?.timeoutMs ?? PER_MODEL_TIMEOUT_MS;

  const failures: string[] = [];
  for (const model of models) {
    try {
      const result = await Promise.race<T>([
        runner(model),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout after ${timeoutMs}ms on ${model}`)), timeoutMs),
        ),
      ]);
      return { result, modelUsed: model };
    } catch (err) {
      const safeMsg = sanitizeSecretStrings(err instanceof Error ? err.message : String(err));
      failures.push(`${model}: ${safeMsg}`);
      if (isPermanentAuthError(err)) {
        throw new Error(`Gemini authentication failed: ${safeMsg}`);
      }
    }
  }
  throw new Error(`All Gemini models failed (${failures.join(" | ")})`);
}

export function safeDecodeRequestPath(rawPath: string): { ok: true; decoded: string } | { ok: false } {
  let current = rawPath || "/";
  for (let pass = 0; pass < 3; pass++) {
    try {
      const next = decodeURIComponent(current);
      if (next.includes("..") || next.includes("\0")) {
        return { ok: false };
      }
      if (next === current) {
        return { ok: true, decoded: next };
      }
      current = next;
    } catch {
      return { ok: false };
    }
  }
  return { ok: !current.includes("..") && !current.includes("\0"), decoded: current } as
    | { ok: true; decoded: string }
    | { ok: false };
}

export function validateUploadedImagePayload(
  base64Input: string,
  declaredMime: string,
): { ok: true; cleanBase64: string; detectedMime: string } | { ok: false; error: string } {
  if (!base64Input || typeof base64Input !== "string") {
    return { ok: false, error: "Image payload is missing." };
  }
  const stripped = base64Input.replace(/^data:image\/[a-z0-9.+-]+;base64,/i, "").trim();
  if (!stripped || stripped.length > 6_000_000) {
    return { ok: false, error: "Image payload exceeds 4 MB size limit." };
  }
  let buf: Buffer;
  try {
    buf = Buffer.from(stripped, "base64");
  } catch {
    return { ok: false, error: "Invalid base64 image payload." };
  }
  if (buf.length === 0 || buf.length > 4 * 1024 * 1024) {
    return { ok: false, error: "Decoded image must be between 1 byte and 4 MB." };
  }

  const isPng =
    buf.length >= 8 &&
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47 &&
    buf[4] === 0x0d &&
    buf[5] === 0x0a &&
    buf[6] === 0x1a &&
    buf[7] === 0x0a;
  const isJpeg = buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const isGif =
    buf.length >= 6 &&
    (buf.subarray(0, 6).toString("ascii") === "GIF87a" ||
      buf.subarray(0, 6).toString("ascii") === "GIF89a");
  const isWebp =
    buf.length >= 12 &&
    buf.subarray(0, 4).toString("ascii") === "RIFF" &&
    buf.subarray(8, 12).toString("ascii") === "WEBP";

  if (!isPng && !isJpeg && !isGif && !isWebp) {
    return {
      ok: false,
      error: "Uploaded file magic bytes do not match a valid PNG, JPEG, GIF, or WebP image.",
    };
  }

  const detectedMime = isPng
    ? "image/png"
    : isJpeg
      ? "image/jpeg"
      : isGif
        ? "image/gif"
        : "image/webp";

  const normDeclared = (declaredMime || "").toLowerCase();
  if (normDeclared && normDeclared !== detectedMime && !(normDeclared === "image/jpg" && detectedMime === "image/jpeg")) {
    return { ok: false, error: "Declared image MIME type does not match actual file signature." };
  }

  return { ok: true, cleanBase64: stripped, detectedMime };
}

export function enforceCommandConfirmationPolicy<
  T extends { intent?: string; needsConfirmation?: boolean },
>(parsed: T): T & { needsConfirmation: boolean } {
  const intent = String(parsed.intent || "CONVERSATION").toUpperCase();
  const forceConfirm = HIGH_RISK_CONFIRM_INTENTS.has(intent);
  return {
    ...parsed,
    needsConfirmation: Boolean(parsed.needsConfirmation) || forceConfirm,
  };
}

export function isOriginAllowedForMutation(params: {
  origin?: string;
  host?: string;
  forwardedHost?: string;
  appUrl?: string;
  sharedAppUrl?: string;
}): boolean {
  const { origin, host, forwardedHost, appUrl, sharedAppUrl } = params;
  if (!origin) return true;
  let originUrl: URL;
  try {
    originUrl = new URL(origin);
  } catch {
    return false;
  }
  const originHost = originUrl.host.toLowerCase();
  const originHostname = originUrl.hostname.toLowerCase();
  const allowedHosts = new Set<string>();
  const allowedPortlessHostnames = new Set<string>();

  if (host) allowedHosts.add(host.toLowerCase());
  if (forwardedHost) {
    for (const part of forwardedHost.split(",")) {
      const h = part.trim().toLowerCase();
      if (!h) continue;
      allowedHosts.add(h);
      if (!h.includes(":")) {
        allowedPortlessHostnames.add(h);
      }
    }
  }
  for (const candidateUrl of [appUrl, sharedAppUrl]) {
    if (!candidateUrl) continue;
    try {
      allowedHosts.add(new URL(candidateUrl).host.toLowerCase());
    } catch {
      // ignore malformed URL env
    }
  }

  if (allowedHosts.has(originHost)) return true;
  if (allowedPortlessHostnames.has(originHostname)) return true;
  return false;
}

export function isAuthorizedHealthCheck(params: {
  providedToken?: string;
  expectedToken?: string;
  remoteAddress?: string;
  forwardedFor?: string;
}): boolean {
  const { providedToken, expectedToken, remoteAddress, forwardedFor } = params;
  if (expectedToken && providedToken) {
    const a = Buffer.from(providedToken);
    const b = Buffer.from(expectedToken);
    if (a.length === b.length && crypto.timingSafeEqual(a, b)) {
      return true;
    }
  }
  const isLoopback =
    remoteAddress === "127.0.0.1" ||
    remoteAddress === "::1" ||
    remoteAddress === "::ffff:127.0.0.1";
  return isLoopback && !forwardedFor;
}

const ANDROID_ALLOWED_EXTENSIONS = new Set([
  ".kt",
  ".kts",
  ".xml",
  ".pro",
  ".properties",
  ".toml",
  ".md",
]);

const ANDROID_EXCLUDED_SEGMENTS = new Set([
  ".gradle",
  ".git",
  "build",
  "local.properties",
  "keystore.properties",
  "google-services.json",
]);

export function isSafeAndroidRelativePath(relPath: string): boolean {
  if (!relPath || relPath.includes("\0") || relPath.startsWith("/") || relPath.startsWith("\\")) {
    return false;
  }
  const normalized = relPath.replace(/\\/g, "/");
  const segments = normalized.split("/").filter(Boolean);
  if (segments.length === 0) return false;
  for (const seg of segments) {
    if (seg === "." || seg === ".." || ANDROID_EXCLUDED_SEGMENTS.has(seg)) {
      return false;
    }
    if (/\.(keystore|jks|p12|pfx|pem|key)$/i.test(seg)) {
      return false;
    }
  }
  const last = segments[segments.length - 1];
  const dotIdx = last.lastIndexOf(".");
  if (dotIdx === -1) return false;
  const ext = last.slice(dotIdx).toLowerCase();
  return ANDROID_ALLOWED_EXTENSIONS.has(ext);
}

