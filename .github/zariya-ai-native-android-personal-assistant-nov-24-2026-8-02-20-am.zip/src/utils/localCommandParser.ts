export interface LocalParsedCommand {
  intent: string;
  targetApp?: string;
  queryOrText?: string;
  targetContact?: string;
  requiredPermission: string;
  needsConfirmation: boolean;
  confirmationPrompt?: string;
  spokenReply: string;
}

const DEVICE_ACTION_VERBS =
  /\b(open|kholo|launch|scroll|neeche|uppar|upar|back|peeche|wapis|read|parho|explain|samjhao|flashlight|torch|volume|awaz|awaaz|mute|play|pause|stop|next|alarm|timer|reminder|note|record|recording|screenshot|screen|whatsapp|youtube|settings|camera|dialer|call|phone|answer|reject|end|speaker|busy|reply|bata|bhej)\b/i;

export function isLikelyDeviceAction(input: string): boolean {
  const trimmed = input.trim();
  if (!trimmed) return false;
  return DEVICE_ACTION_VERBS.test(trimmed);
}

export function parseLocalCommand(input: string): LocalParsedCommand | null {
  const text = input.trim();
  if (!text) return null;
  const lower = text.toLowerCase();

  // Flashlight / Torch
  if (/\b(flashlight|torch)\b/i.test(lower)) {
    const turnOff = /\b(off|band|disable|close)\b/i.test(lower);
    return {
      intent: turnOff ? 'FLASHLIGHT_OFF' : 'FLASHLIGHT_ON',
      requiredPermission: 'CAMERA',
      needsConfirmation: false,
      spokenReply: turnOff
        ? 'Flashlight band kar di hai.'
        : 'Flashlight on kar di hai.',
    };
  }

  // Screen scroll & navigation
  if (/\b(scroll down|neeche scroll|niche scroll|scroll neeche)\b/i.test(lower)) {
    return {
      intent: 'SCROLL_DOWN',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Screen neeche scroll kar di hai.',
    };
  }

  if (/\b(scroll up|uppar scroll|upar scroll|scroll upar)\b/i.test(lower)) {
    return {
      intent: 'SCROLL_UP',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Screen upar scroll kar di hai.',
    };
  }

  if (/\b(go back|navigate back|peeche jao|wapis jao)\b/i.test(lower)) {
    return {
      intent: 'NAVIGATE_BACK',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Pichli screen par wapis ja raha hoon.',
    };
  }

  // Screen reading
  if (
    /\b(read screen|what is on my screen|meri screen par kya|screen parho|explain screen|screen samjhao)\b/i.test(
      lower,
    )
  ) {
    return {
      intent: /explain|samjhao/i.test(lower) ? 'EXPLAIN_SCREEN' : 'READ_SCREEN',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Screen ka summary:',
    };
  }

  // WhatsApp read & reply
  if (
    /\bwhatsapp\b/i.test(lower) &&
    /\b(read|parho|check|latest|message|messages)\b/i.test(lower)
  ) {
    return {
      intent: 'READ_WHATSAPP',
      targetApp: 'WhatsApp',
      requiredPermission: 'NotificationListenerService',
      needsConfirmation: false,
      spokenReply: 'Latest WhatsApp notification:',
    };
  }

  if (/\b(ali|ammi|office manager)\b/i.test(lower) && /\b(bata|reply|send|bhej|busy)\b/i.test(lower)) {
    const contactMatch = lower.match(/\b(ali|ammi|office manager)\b/i);
    const contact = contactMatch
      ? contactMatch[1].replace(/\b\w/g, (c) => c.toUpperCase())
      : 'Ali';
    return {
      intent: 'REPLY_WHATSAPP',
      targetApp: 'WhatsApp',
      targetContact: contact,
      queryOrText: 'Main abhi busy hoon, baad mein rabta karta hoon.',
      requiredPermission: 'NotificationListenerService + RemoteInput',
      needsConfirmation: true,
      confirmationPrompt: `Kya main ${contact} ko WhatsApp par reply bhej doon: "Main abhi busy hoon, baad mein rabta karta hoon."?`,
      spokenReply: `${contact} ko reply bhejne ke liye aapki tasdeeq chahiye.`,
    };
  }

  // YouTube search
  if (/\byoutube\b/i.test(lower) && /\bsearch\b/i.test(lower)) {
    const qMatch = text.match(/search(?:\s+karo|\s+for)?\s+(.+)$/i);
    const query = qMatch?.[1]?.trim() || 'Lo-fi focus';
    return {
      intent: 'YOUTUBE_SEARCH',
      targetApp: 'YouTube',
      queryOrText: query,
      requiredPermission: 'Android Search Intent',
      needsConfirmation: false,
      spokenReply: `YouTube par "${query}" search kar diya hai.`,
    };
  }

  // Open common apps
  if (/\b(open|kholo|launch)\s+(whatsapp|settings|camera|dialer|phone|youtube)\b/i.test(lower)) {
    const appMatch = lower.match(/\b(whatsapp|settings|camera|dialer|phone|youtube)\b/i);
    const target = appMatch?.[1] || 'App';
    if (target === 'settings') {
      return {
        intent: 'OPEN_SETTINGS',
        targetApp: 'Settings',
        requiredPermission: 'Android Settings Intent',
        needsConfirmation: false,
        spokenReply: 'Device Settings khol raha hoon.',
      };
    }
    if (target === 'camera') {
      return {
        intent: 'OPEN_CAMERA',
        targetApp: 'Camera',
        requiredPermission: 'Android Intent',
        needsConfirmation: false,
        spokenReply: 'Camera khol raha hoon.',
      };
    }
    if (target === 'dialer' || target === 'phone') {
      return {
        intent: 'OPEN_DIALER',
        targetApp: 'Phone Dialer',
        requiredPermission: 'Android Intent',
        needsConfirmation: false,
        spokenReply: 'Phone dialer khol raha hoon.',
      };
    }
    const properName = target.charAt(0).toUpperCase() + target.slice(1);
    return {
      intent: 'OPEN_APP',
      targetApp: properName,
      requiredPermission: 'Launcher Intent',
      needsConfirmation: false,
      spokenReply: `${properName} khol raha hoon.`,
    };
  }

  // Volume & Media
  if (/\b(volume up|increase volume|awaz barhao|awaaz zyada)\b/i.test(lower)) {
    return {
      intent: 'VOLUME_UP',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Volume barha diya hai.',
    };
  }
  if (/\b(volume down|decrease volume|awaz kam|awaaz kam)\b/i.test(lower)) {
    return {
      intent: 'VOLUME_DOWN',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Volume kam kar diya hai.',
    };
  }
  if (/\b(play music|play media|resume music|gaana chalao)\b/i.test(lower)) {
    return {
      intent: 'MEDIA_PLAY',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Media playback shuru kar diya hai.',
    };
  }
  if (/\b(pause music|pause media|stop music)\b/i.test(lower)) {
    return {
      intent: 'MEDIA_PAUSE',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Media pause kar diya hai.',
    };
  }
  if (/\b(next track|next song|agla gaana)\b/i.test(lower)) {
    return {
      intent: 'MEDIA_NEXT',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Agla track chala raha hoon.',
    };
  }

  // Alarms & Reminders
  if (/\bset\s+(?:an\s+)?alarm\b/i.test(lower)) {
    return {
      intent: 'SET_ALARM',
      queryOrText: text,
      requiredPermission: 'SET_ALARM / Local Encrypted Store',
      needsConfirmation: false,
      spokenReply: 'Alarm note kar liya hai.',
    };
  }

  if (/\b(?:set\s+(?:a\s+)?timer)\b/i.test(lower)) {
    return {
      intent: 'SET_TIMER',
      queryOrText: text,
      requiredPermission: 'SET_ALARM / Local Encrypted Store',
      needsConfirmation: false,
      spokenReply: 'Timer set kar diya hai.',
    };
  }

  // Calls
  if (/\b(answer the call|pick up the call|call uthao)\b/i.test(lower)) {
    return {
      intent: 'ANSWER_CALL',
      requiredPermission: 'ANSWER_PHONE_CALLS / TelecomManager',
      needsConfirmation: false,
      spokenReply: 'Incoming call answer kar raha hoon.',
    };
  }
  if (/\b(reject the call|end the call|call band|call kaato)\b/i.test(lower)) {
    const isEnd = /\bend\b/i.test(lower);
    return {
      intent: isEnd ? 'END_CALL' : 'REJECT_CALL',
      requiredPermission: 'ANSWER_PHONE_CALLS / TelecomManager',
      needsConfirmation: true,
      confirmationPrompt: 'Confirm ending or rejecting the active phone call?',
      spokenReply: 'Call action ke liye confirmation darkar hai.',
    };
  }
  if (/\b(tell the caller i am busy|caller ko busy)\b/i.test(lower)) {
    return {
      intent: 'TELL_CALLER_BUSY',
      requiredPermission: 'ANSWER_PHONE_CALLS / TelecomManager',
      needsConfirmation: true,
      confirmationPrompt: 'Send AI busy disclosure notice to the caller?',
      spokenReply: 'Caller ko busy notice bhejne ke liye confirm karein.',
    };
  }

  // Screen recording & screenshot
  if (/\bstart\s+screen\s+recording\b/i.test(lower)) {
    return {
      intent: 'START_RECORDING',
      requiredPermission: 'MediaProjection',
      needsConfirmation: false,
      spokenReply: 'Screen recording session Device Lab mein ready hai.',
    };
  }
  if (/\b(take a screenshot|capture screenshot)\b/i.test(lower)) {
    return {
      intent: 'CAPTURE_SCREENSHOT',
      requiredPermission: 'MediaProjection',
      needsConfirmation: false,
      spokenReply: 'Screenshot capture request Device Lab ko bhej di hai.',
    };
  }

  return null;
}
