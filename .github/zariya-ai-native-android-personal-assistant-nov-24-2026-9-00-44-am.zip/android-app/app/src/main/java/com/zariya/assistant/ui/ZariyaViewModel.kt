package com.zariya.assistant.ui

import android.Manifest
import android.app.Application
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zariya.assistant.ZariyaApplication
import com.zariya.assistant.accessibility.ZariyaAccessibilityService
import com.zariya.assistant.calls.CallControlHelper
import com.zariya.assistant.calls.ZariyaCallScreeningService
import com.zariya.assistant.control.DeviceControlManager
import com.zariya.assistant.data.model.AssistantLanguage
import com.zariya.assistant.data.model.AutoReplyRule
import com.zariya.assistant.data.model.CallAssistantConfig
import com.zariya.assistant.data.model.ChatMessage
import com.zariya.assistant.data.model.DailyTaskItem
import com.zariya.assistant.data.model.OrbState
import com.zariya.assistant.data.model.PermissionItemState
import com.zariya.assistant.data.model.TaskExecutionReport
import com.zariya.assistant.data.model.VoiceGender
import com.zariya.assistant.data.remote.ChatRequestDto
import com.zariya.assistant.data.remote.ScreenAnalyzeRequestDto
import com.zariya.assistant.notifications.ZariyaNotificationListenerService
import com.zariya.assistant.orchestrator.JarvisCommandOrchestrator
import com.zariya.assistant.recording.ScreenRecorderService
import com.zariya.assistant.voice.JarvisForegroundService
import com.zariya.assistant.voice.VoiceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class ZariyaViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as ZariyaApplication
    val memory = app.memoryStore
    val voiceEngine = VoiceEngine(application)
    val deviceControl = DeviceControlManager(application)
    val callControl = CallControlHelper(application)

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    val orbState: StateFlow<OrbState> = _orbState

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                id = UUID.randomUUID().toString(),
                role = "assistant",
                text = "Sat Sri Akal! Main ${memory.assistantName} haan — Punjabi, Urdu, Hindi te English vich hukam deo ya koi vi sawaal pucho."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _latestTaskReport = MutableStateFlow<TaskExecutionReport?>(null)
    val latestTaskReport: StateFlow<TaskExecutionReport?> = _latestTaskReport

    private val _permissions = MutableStateFlow<List<PermissionItemState>>(emptyList())
    val permissions: StateFlow<List<PermissionItemState>> = _permissions

    private val _handsFreeActive = MutableStateFlow(false)
    val handsFreeActive: StateFlow<Boolean> = _handsFreeActive

    private val _pendingMediaProjectionRequest = MutableStateFlow<String?>(null)
    val pendingMediaProjectionRequest: StateFlow<String?> = _pendingMediaProjectionRequest

    private val _dailyTasks = MutableStateFlow(memory.dailyTasks)
    val dailyTasks: StateFlow<List<DailyTaskItem>> = _dailyTasks

    private var pendingConfirmationCommand: String? = null
    private var lastAnnouncedArrivalKey: String? = null

    private val orchestrator = JarvisCommandOrchestrator(
        context = application,
        deviceControl = deviceControl,
        callControl = callControl,
        onRequestMediaProjectionStart = { _pendingMediaProjectionRequest.value = "RECORD" },
        onRequestMediaProjectionSnapshot = { _pendingMediaProjectionRequest.value = "SNAPSHOT" },
        onSpeakResponse = { reply -> voiceEngine.speak(reply, interruptCurrent = true) }
    )

    init {
        syncVoiceConfig()
        refreshPermissions()
        viewModelScope.launch {
            voiceEngine.isListening.collect { listening ->
                if (listening) _orbState.value = OrbState.LISTENING
                else if (_orbState.value == OrbState.LISTENING) _orbState.value = OrbState.IDLE
            }
        }
        viewModelScope.launch {
            voiceEngine.isSpeaking.collect { speaking ->
                if (speaking) _orbState.value = OrbState.SPEAKING
                else if (_orbState.value == OrbState.SPEAKING) _orbState.value = OrbState.IDLE
            }
        }
        viewModelScope.launch {
            ScreenRecorderService.latestFrameBase64.collect { base64 ->
                if (!base64.isNullOrEmpty()) {
                    analyzeCapturedFrame(base64)
                    ScreenRecorderService.clearCapturedFrame()
                }
            }
        }
        viewModelScope.launch {
            ZariyaNotificationListenerService.latestArrival.collect { arrival ->
                if (arrival != null && memory.readWhatsAppAloud && arrival.key + arrival.messageText != lastAnnouncedArrivalKey) {
                    lastAnnouncedArrivalKey = arrival.key + arrival.messageText
                    val notice = "Faisal, ${arrival.senderName} ka message aaya hai."
                    appendAssistantMessage(notice)
                    voiceEngine.speak(notice, interruptCurrent = false)
                }
            }
        }
    }

    fun clearMediaProjectionTrigger() {
        _pendingMediaProjectionRequest.value = null
    }

    fun syncVoiceConfig() {
        voiceEngine.configure(
            language = memory.preferredLanguage,
            gender = memory.voiceGender,
            persona = memory.voicePersona,
            wakeEnabled = memory.wakeWordEnabled,
            wakeWord = memory.wakePhrase
        )
    }

    fun toggleListening(handsFree: Boolean) {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            appendAssistantMessage("Microphone permission (RECORD_AUDIO) is required before voice listening can start.")
            return
        }
        if (voiceEngine.isSpeaking.value) {
            voiceEngine.interruptSpeech()
        }
        if (voiceEngine.isListening.value || _handsFreeActive.value) {
            voiceEngine.stopListening()
            _handsFreeActive.value = false
            JarvisForegroundService.stop(app)
        } else {
            _handsFreeActive.value = handsFree
            if (handsFree) {
                JarvisForegroundService.start(app)
            }
            voiceEngine.startListening(
                handsFree = handsFree,
                onResult = { spokenText -> sendCommandOrChat(spokenText) },
                onError = { err -> appendAssistantMessage(err) }
            )
        }
    }

    fun sendCommandOrChat(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return
        _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            role = "user",
            text = trimmed
        )
        _orbState.value = OrbState.THINKING

        val isVoiceConfirm = Regex("^(yes|yeah|confirm|haan|han|ok|okay|bhej do|kar do|send it|call करो)$", RegexOption.IGNORE_CASE)
            .matches(trimmed.trimEnd('.', '!'))
        val pendingCmd = pendingConfirmationCommand
        val commandToRun = if (isVoiceConfirm && pendingCmd != null) pendingCmd else trimmed
        val isConfirmed = isVoiceConfirm && pendingCmd != null
        if (isConfirmed) {
            pendingConfirmationCommand = null
        }

        viewModelScope.launch {
            val (reply, report) = orchestrator.processCommand(commandToRun, confirmedSensitiveAction = isConfirmed)
            if (!report.succeeded && report.failureReason?.startsWith("Confirmation required") == true) {
                pendingConfirmationCommand = commandToRun
            }
            _latestTaskReport.value = report
            _dailyTasks.value = memory.dailyTasks
            _messages.value = _messages.value + ChatMessage(
                id = UUID.randomUUID().toString(),
                role = "assistant",
                text = reply,
                taskReport = report
            )
            if (!voiceEngine.isSpeaking.value) {
                _orbState.value = OrbState.IDLE
            }
        }
    }

    private fun analyzeCapturedFrame(base64: String) {
        _orbState.value = OrbState.THINKING
        viewModelScope.launch {
            val result = runCatching {
                app.backendClient.api.analyzeScreen(
                    ScreenAnalyzeRequestDto(
                        imageBase64 = base64,
                        mimeType = "image/jpeg",
                        prompt = "Explain what is visible on this Android screen and list actionable buttons or key information."
                    )
                )
            }
            val summary = result.getOrNull()?.summary ?: "Screen frame captured, but AI analysis failed."
            appendAssistantMessage(summary)
            voiceEngine.speak(summary)
            _orbState.value = OrbState.IDLE
        }
    }

    fun refreshPermissions() {
        val list = listOf(
            PermissionItemState(
                id = "mic",
                title = "Microphone (Voice Input & Live Mode)",
                androidPermission = Manifest.permission.RECORD_AUDIO,
                reason = "Captures voice commands only when you tap Speak or enable Hands-Free Live Mode.",
                isGranted = hasPermission(Manifest.permission.RECORD_AUDIO)
            ),
            PermissionItemState(
                id = "notif",
                title = "Post Notifications",
                androidPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.POST_NOTIFICATIONS else "POST_NOTIFICATIONS",
                reason = "Displays transparent indicators while Live Mode or Screen Recording is active.",
                isGranted = if (Build.VERSION.SDK_INT >= 33) hasPermission(Manifest.permission.POST_NOTIFICATIONS) else true
            ),
            PermissionItemState(
                id = "accessibility",
                title = "Accessibility Service (Screen Reader & Navigation)",
                androidPermission = Settings.ACTION_ACCESSIBILITY_SETTINGS,
                reason = "Reads visible non-password text, scrolls, clicks buttons, and assists navigation.",
                isGranted = ZariyaAccessibilityService.isConnected.value,
                isSpecialSystemAccess = true
            ),
            PermissionItemState(
                id = "notif_listener",
                title = "Notification Listener (WhatsApp Reader & Reply)",
                androidPermission = Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS,
                reason = "Reads incoming WhatsApp messages and sends authorized RemoteInput replies.",
                isGranted = NotificationManagerCompat.getEnabledListenerPackages(app).contains(app.packageName),
                isSpecialSystemAccess = true
            ),
            PermissionItemState(
                id = "contacts",
                title = "Contacts",
                androidPermission = Manifest.permission.READ_CONTACTS,
                reason = "Matches caller IDs and priority WhatsApp contact rules.",
                isGranted = hasPermission(Manifest.permission.READ_CONTACTS)
            ),
            PermissionItemState(
                id = "phone",
                title = "Phone State & Answer Calls",
                androidPermission = Manifest.permission.ANSWER_PHONE_CALLS,
                reason = "Allows voice-controlled answering, rejecting, and ending calls.",
                isGranted = hasPermission(Manifest.permission.ANSWER_PHONE_CALLS) && hasPermission(Manifest.permission.READ_PHONE_STATE)
            ),
            PermissionItemState(
                id = "call_screening",
                title = "Call Screening Role",
                androidPermission = "ROLE_CALL_SCREENING",
                reason = "Identifies incoming callers before ringing to announce caller name aloud.",
                isGranted = isCallScreeningHeld(),
                isSpecialSystemAccess = true
            ),
            PermissionItemState(
                id = "camera",
                title = "Camera (Flashlight & Camera Launch)",
                androidPermission = Manifest.permission.CAMERA,
                reason = "Controls the device flashlight torch via CameraManager.",
                isGranted = hasPermission(Manifest.permission.CAMERA)
            )
        )
        _permissions.value = list
    }

    private fun isCallScreeningHeld(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val rm = app.getSystemService(RoleManager::class.java)
        return rm?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(app, permission) == PackageManager.PERMISSION_GRANTED

    private fun appendAssistantMessage(text: String) {
        _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            role = "assistant",
            text = text
        )
    }

    fun updateAutoReplyRule(rule: AutoReplyRule) {
        memory.autoReplyRule = rule
    }

    fun updateCallConfig(config: CallAssistantConfig) {
        memory.callAssistantConfig = config
    }

    fun clearAllLocalMemory() {
        memory.clearAllMemory()
        _dailyTasks.value = emptyList()
        appendAssistantMessage("Local encrypted assistant memory has been cleared.")
    }

    override fun onCleared() {
        voiceEngine.release()
        super.onCleared()
    }
}
