import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Battery,
  BatteryCharging,
  Download,
  Image as ImageIcon,
  Mic,
  MicOff,
  Send,
  Settings,
  Sparkles,
  Volume2,
  X,
} from 'lucide-react';
import AvatarVoiceMode from './components/AvatarVoiceMode';
import { AndroidStudioPanel } from './components/AndroidStudioPanel';
import { AutomationPanel } from './components/AutomationPanel';
import { DeviceLabPanel } from './components/DeviceLabPanel';
import { PermissionsPrivacyPanel } from './components/PermissionsPrivacyPanel';
import { SmwEmblem } from './components/SmwEmblem';
import {
  AssistantMemory,
  AutoReplyRule,
  CallConfig,
  CallSession,
  ChatEntry,
  DailyTask,
  DeviceHardwareState,
  OrbState,
  PermissionRecord,
  TaskExecutionReport,
  WhatsAppMessage,
} from './types/assistant';
import {
  isLikelyDeviceAction,
  parseLocalCommand,
  resolveKnownContacts,
  stripWakePrefix,
} from './utils/localCommandParser';
import {
  AuthenticatedProfile,
  getGreetingFirstName,
  googleSignIn,
  initAuth,
  logout,
} from './lib/googleAuth';

const INITIAL_PERMISSIONS: PermissionRecord[] = [
  {
    id: 'mic',
    title: 'Microphone (RECORD_AUDIO)',
    androidPermission: 'android.permission.RECORD_AUDIO',
    category: 'Runtime',
    reason: 'Captures voice commands only when you tap Speak or enable Hands-Free Live Mode.',
    granted: true,
  },
  {
    id: 'accessibility',
    title: 'Accessibility Service (Screen Reader & Control)',
    androidPermission: 'android.permission.BIND_ACCESSIBILITY_SERVICE',
    category: 'Special System Access',
    reason: 'Reads visible non-protected text, summarizes screens, scrolls, and clicks supported elements.',
    granted: true,
  },
  {
    id: 'notif_listener',
    title: 'Notification Listener (WhatsApp Reader & Reply)',
    androidPermission: 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE',
    category: 'Special System Access',
    reason: 'Reads authorized WhatsApp notifications and executes RemoteInput replies.',
    granted: true,
  },
  {
    id: 'mediaprojection',
    title: 'Screen Capture (MediaProjection)',
    androidPermission: 'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION',
    category: 'Special System Access',
    reason: 'Records the screen or captures a frame for AI analysis only after explicit consent.',
    granted: true,
  },
  {
    id: 'phone',
    title: 'Phone State & Answer Calls',
    androidPermission: 'android.permission.ANSWER_PHONE_CALLS',
    category: 'Runtime',
    reason: 'Enables voice-controlled call answering, rejecting, and ending via TelecomManager.',
    granted: true,
  },
  {
    id: 'camera',
    title: 'Camera & Flashlight',
    androidPermission: 'android.permission.CAMERA',
    category: 'Runtime',
    reason: 'Toggles the hardware torch via CameraManager and opens Camera.',
    granted: true,
  },
];

const DEFAULT_MEMORY: AssistantMemory = {
  assistantName: 'SMW AI',
  wakePhrase: 'Hey Assistant',
  wakeWordRequired: false,
  voiceGender: 'MALE',
  voicePersona: 'punjabi_legend',
  preferredLanguage: 'auto',
  priorityContacts: ['Ali', 'Ammi', 'Office Manager'],
  templates: [
    'Assalamualaikum, main abhi kaam kar raha hoon. Main baad mein aapse baat karta hoon.',
    'Main abhi busy hoon, aapka message mil gaya hai. Main free hote hi reply karunga.',
    'Main abhi available nahi hoon. Zaroori baat ho to message chhor dein.',
  ],
  readWhatsAppAloud: false,
  recordMicWithScreen: false,
};

const STORAGE_KEY = 'faizan_ai_memory_v1';

const QUICK_PROMPTS = [
  'Sat Sri Akal, ki haal aa?',
  'Meri screen par kya likha hai?',
  'Turn on the flashlight',
  'WhatsApp latest message parho',
];

function formatTime(): string {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

async function safeFetchJson<T = Record<string, unknown>>(
  url: string,
  init: RequestInit,
  timeoutMs = 25000,
): Promise<{ ok: boolean; status: number; data: T & { error?: string } }> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    const rawText = await res.text();
    let parsed: unknown = {};
    if (rawText) {
      try {
        parsed = JSON.parse(rawText);
      } catch {
        parsed = { error: res.ok ? 'Invalid response format from server.' : `Server error (${res.status}).` };
      }
    }
    const data =
      parsed && typeof parsed === 'object' ? (parsed as T & { error?: string }) : ({} as T & { error?: string });
    return { ok: res.ok, status: res.status, data };
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Request timed out. Please check your connection and try again.');
    }
    throw err;
  } finally {
    window.clearTimeout(timer);
  }
}

type WorkspaceTab = 'assistant' | 'device' | 'automation' | 'permissions' | 'android';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('assistant');
  const [orbState, setOrbState] = useState<OrbState>('IDLE');
  const [handsFreeMode, setHandsFreeMode] = useState(false);
  const [avatarModeOpen, setAvatarModeOpen] = useState(false);
  const [partialTranscript, setPartialTranscript] = useState('');
  const [input, setInput] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [authProfile, setAuthProfile] = useState<AuthenticatedProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [splashVisible, setSplashVisible] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [memory, setMemory] = useState<AssistantMemory>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return DEFAULT_MEMORY;
      const parsed = JSON.parse(saved) as Partial<AssistantMemory> | null;
      if (!parsed || typeof parsed !== 'object') return DEFAULT_MEMORY;
      const migratedName =
        typeof parsed.assistantName === 'string' &&
        parsed.assistantName.trim() &&
        parsed.assistantName.trim().toUpperCase() !== 'FAIZAN AI'
          ? parsed.assistantName
          : 'SMW AI';
      return {
        ...DEFAULT_MEMORY,
        ...parsed,
        assistantName: migratedName,
        voicePersona: parsed.voicePersona || 'punjabi_legend',
      };
    } catch {
      return DEFAULT_MEMORY;
    }
  });

  const [permissions, setPermissions] = useState<PermissionRecord[]>(INITIAL_PERMISSIONS);
  const [latestReport, setLatestReport] = useState<TaskExecutionReport | null>(null);
  const [messages, setMessages] = useState<ChatEntry[]>([]);

  const [hardware, setHardware] = useState<DeviceHardwareState>({
    flashlightOn: false,
    volumePercent: 65,
    mediaPlaying: false,
    mediaTrack: 'Ambient Focus Mix',
    screenScrollIndex: 0,
    activeScreenKey: 'whatsapp',
    batteryPercent: null,
    batteryCharging: false,
  });

  const [dailyTasks, setDailyTasks] = useState<DailyTask[]>([
    {
      id: 't-1',
      type: 'reminder',
      title: 'Send Q4 presentation deck to Ali',
      detail: '4:00 PM today',
      createdAt: formatTime(),
    },
  ]);

  const [whatsappMessages, setWhatsappMessages] = useState<WhatsAppMessage[]>([
    {
      id: 'wa-1',
      appSource: 'WhatsApp',
      sender: 'Ali',
      text: 'Salam bhai, client presentation 4 PM ko confirm hui hai. Urgent deck bhej dein.',
      timestamp: formatTime(),
      isUrgent: true,
      urgencyReason: 'Time-sensitive client presentation request.',
      aiDraftReply: 'Walaikum Assalam Ali, deck 15 minutes mein bhej raha hoon.',
      autoReplied: false,
    },
  ]);

  const [autoReplyRule, setAutoReplyRule] = useState<AutoReplyRule>({
    enabled: false,
    audience: 'SELECTED_CONTACTS_ONLY',
    activeTemplate: DEFAULT_MEMORY.templates[0],
    scheduleEnabled: false,
    startHour: 9,
    endHour: 18,
    cooldownMinutes: 30,
    askBeforeUnconfigured: true,
  });

  const [callConfig, setCallConfig] = useState<CallConfig>({
    enabled: true,
    announceCallerAloud: true,
    autoAnswerSelectedContacts: false,
    handsFreeMode: false,
    speakerphoneActive: false,
    busyNotice:
      'Hello, I am the owner’s AI assistant. The owner is currently busy and will contact you later.',
  });

  const [activeCall, setActiveCall] = useState<CallSession | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioUrlRef = useRef<string | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const speechRafRef = useRef<number | null>(null);
  const speechLevelRef = useRef<number>(0);
  const recognitionRef = useRef<unknown>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, orbState]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(memory));
    } catch {
      // Ignore storage restrictions
    }
  }, [memory]);

  useEffect(() => {
    const unsubscribe = initAuth(
      (profile) => {
        setAuthProfile(profile);
        setAuthError(null);
        setAuthLoading(false);
      },
      () => {
        setAuthProfile(null);
        setAuthLoading(false);
      },
    );
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => setSplashVisible(false), 650);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    interface BatteryManagerLike extends EventTarget {
      level: number;
      charging: boolean;
    }
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<BatteryManagerLike>;
    };
    if (typeof nav.getBattery !== 'function') return;

    let batteryRef: BatteryManagerLike | null = null;
    let active = true;

    const syncBattery = () => {
      if (!active || !batteryRef) return;
      setHardware((prev) => ({
        ...prev,
        batteryPercent: Math.round(batteryRef!.level * 100),
        batteryCharging: Boolean(batteryRef!.charging),
      }));
    };

    nav
      .getBattery()
      .then((battery) => {
        if (!active) return;
        batteryRef = battery;
        syncBattery();
        battery.addEventListener('levelchange', syncBattery);
        battery.addEventListener('chargingchange', syncBattery);
      })
      .catch(() => {
        // Battery Status API unavailable
      });

    return () => {
      active = false;
      if (batteryRef) {
        batteryRef.removeEventListener('levelchange', syncBattery);
        batteryRef.removeEventListener('chargingchange', syncBattery);
      }
    };
  }, []);

  const handleGoogleLogin = useCallback(async () => {
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      const profile = await googleSignIn();
      setAuthProfile(profile);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Unable to complete Google Sign-In.';
      setAuthError(message);
    } finally {
      setIsLoggingIn(false);
    }
  }, []);

  const handleGoogleLogout = useCallback(async () => {
    setAuthError(null);
    await logout();
    setAuthProfile(null);
  }, []);

  const greetingName = getGreetingFirstName(authProfile);

  const isGranted = useCallback(
    (id: string) => permissions.find((p) => p.id === id)?.granted ?? false,
    [permissions],
  );

  const stopSpeechMeter = useCallback(() => {
    if (speechRafRef.current !== null) {
      window.cancelAnimationFrame(speechRafRef.current);
      speechRafRef.current = null;
    }
    speechLevelRef.current = 0;
  }, []);

  const ensureAudioContext = useCallback((): AudioContext | null => {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;
    if (!audioContextRef.current) {
      audioContextRef.current = new AudioCtx();
    }
    if (audioContextRef.current.state === 'suspended') {
      void audioContextRef.current.resume().catch(() => {});
    }
    return audioContextRef.current;
  }, []);

  const interruptSpeech = useCallback(() => {
    stopSpeechMeter();
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setOrbState((prev) => (prev === 'SPEAKING' ? 'IDLE' : prev));
  }, [stopSpeechMeter]);

  useEffect(() => {
    return () => {
      stopSpeechMeter();
      if (audioUrlRef.current) {
        URL.revokeObjectURL(audioUrlRef.current);
        audioUrlRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        void audioContextRef.current.close().catch(() => {});
      }
    };
  }, [stopSpeechMeter]);

  const speakText = useCallback(
    async (text: string) => {
      if (!text.trim()) return;
      interruptSpeech();
      setOrbState('SPEAKING');
      const activePersona = memory.voicePersona || 'punjabi_legend';
      const isLegend = activePersona === 'punjabi_legend' && memory.voiceGender !== 'FEMALE';

      try {
        const { ok, data } = await safeFetchJson<{ audioBase64?: string; mimeType?: string }>(
          '/api/ai/tts',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              text,
              gender: memory.voiceGender,
              persona: activePersona,
              language: memory.preferredLanguage,
            }),
          },
          22000,
        );
        if (ok && data.audioBase64) {
          const binary = window.atob(data.audioBase64);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
          }
          const wavBlob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
          const objectUrl = URL.createObjectURL(wavBlob);
          audioUrlRef.current = objectUrl;

          const audio = new Audio(objectUrl);
          audioRef.current = audio;

          const cleanupAudio = () => {
            stopSpeechMeter();
            if (audioUrlRef.current === objectUrl) {
              URL.revokeObjectURL(objectUrl);
              audioUrlRef.current = null;
            }
            if (audioRef.current === audio) {
              audioRef.current = null;
            }
            setOrbState('IDLE');
          };

          audio.onended = cleanupAudio;
          audio.onerror = cleanupAudio;

          const ctx = ensureAudioContext();
          if (ctx) {
            try {
              const source = ctx.createMediaElementSource(audio);
              const analyser = ctx.createAnalyser();
              analyser.fftSize = 256;

              if (isLegend) {
                // Deep, bass-rich vocal mastering chain for Punjabi Legend presence
                const bassShelf = ctx.createBiquadFilter();
                bassShelf.type = 'lowshelf';
                bassShelf.frequency.value = 135;
                bassShelf.gain.value = 4.2;

                const grainPresence = ctx.createBiquadFilter();
                grainPresence.type = 'peaking';
                grainPresence.frequency.value = 2600;
                grainPresence.Q.value = 1.1;
                grainPresence.gain.value = 1.6;

                const compressor = ctx.createDynamicsCompressor();
                compressor.threshold.value = -18;
                compressor.knee.value = 12;
                compressor.ratio.value = 3.2;
                compressor.attack.value = 0.008;
                compressor.release.value = 0.16;

                source.connect(bassShelf);
                bassShelf.connect(grainPresence);
                grainPresence.connect(compressor);
                compressor.connect(analyser);
              } else {
                source.connect(analyser);
              }
              analyser.connect(ctx.destination);
              analyserRef.current = analyser;

              const dataArray = new Uint8Array(analyser.frequencyBinCount);
              const tickMeter = () => {
                if (!audioRef.current || audioRef.current.paused || audioRef.current.ended) {
                  speechLevelRef.current = 0;
                  return;
                }
                analyser.getByteTimeDomainData(dataArray);
                let sumSq = 0;
                for (let i = 0; i < dataArray.length; i++) {
                  const normalized = (dataArray[i] - 128) / 128;
                  sumSq += normalized * normalized;
                }
                const rms = Math.sqrt(sumSq / dataArray.length);
                speechLevelRef.current = Math.min(1, Math.max(0, rms * 3.8));
                speechRafRef.current = window.requestAnimationFrame(tickMeter);
              };
              speechRafRef.current = window.requestAnimationFrame(tickMeter);
            } catch {
              const start = performance.now();
              const tickEnvelope = (now: number) => {
                if (!audioRef.current || audioRef.current.paused || audioRef.current.ended) {
                  speechLevelRef.current = 0;
                  return;
                }
                const elapsed = (now - start) * 0.001;
                speechLevelRef.current = 0.25 + 0.45 * Math.abs(Math.sin(elapsed * 11));
                speechRafRef.current = window.requestAnimationFrame(tickEnvelope);
              };
              speechRafRef.current = window.requestAnimationFrame(tickEnvelope);
            }
          }

          await audio.play();
          return;
        }
      } catch {
        // Fallback to browser SpeechSynthesis below
      }

      if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(text);
        const voices = window.speechSynthesis.getVoices();
        const preferLang =
          memory.preferredLanguage !== 'auto'
            ? memory.preferredLanguage
            : /[\u0A00-\u0A7F]/.test(text)
              ? 'pa-IN'
              : /[\u0600-\u06FF]/.test(text)
                ? 'ur-PK'
                : /[\u0900-\u097F]/.test(text)
                  ? 'hi-IN'
                  : 'en-IN';
        utter.lang = preferLang;

        if (voices.length > 0) {
          const wantMale = isLegend || memory.voiceGender === 'MALE';
          const scored = voices
            .map((v) => {
              let score = 0;
              const name = v.name.toLowerCase();
              const lang = v.lang.toLowerCase();
              if (lang.startsWith(preferLang.slice(0, 2).toLowerCase())) score += 4;
              if (lang.includes('-in') || lang.includes('-pk')) score += 2;
              if (wantMale && /(male|rishi|prabhat|madhur|david|daniel|alex|google.*uk.*male|guy)/i.test(name)) {
                score += 5;
              }
              if (!wantMale && /(female|lekha|swara|heera|samantha|zira|google.*female)/i.test(name)) {
                score += 5;
              }
              return { v, score };
            })
            .sort((a, b) => b.score - a.score);
          if (scored[0] && scored[0].score > 0) {
            utter.voice = scored[0].v;
          }
        }

        utter.pitch = isLegend ? 0.72 : memory.voiceGender === 'FEMALE' ? 1.1 : 0.88;
        utter.rate = isLegend ? 0.92 : memory.voiceGender === 'FEMALE' ? 1.12 : 1.02;

        let pulseBoost = 0.65;
        const start = performance.now();
        const tickSynth = (now: number) => {
          if (!window.speechSynthesis.speaking) {
            speechLevelRef.current = 0;
            speechRafRef.current = null;
            return;
          }
          const t = (now - start) * 0.001;
          pulseBoost = Math.max(0.22, pulseBoost * 0.93);
          speechLevelRef.current = Math.min(
            1,
            pulseBoost * (0.55 + 0.45 * Math.abs(Math.sin(t * 13.5))),
          );
          speechRafRef.current = window.requestAnimationFrame(tickSynth);
        };

        utter.onboundary = () => {
          pulseBoost = 0.88;
        };
        utter.onstart = () => {
          speechRafRef.current = window.requestAnimationFrame(tickSynth);
        };
        utter.onend = () => {
          stopSpeechMeter();
          setOrbState('IDLE');
        };
        utter.onerror = () => {
          stopSpeechMeter();
          setOrbState('IDLE');
        };
        window.speechSynthesis.speak(utter);
      } else {
        stopSpeechMeter();
        setOrbState('IDLE');
      }
    },
    [
      ensureAudioContext,
      interruptSpeech,
      memory.preferredLanguage,
      memory.voiceGender,
      memory.voicePersona,
      stopSpeechMeter,
    ],
  );

  const executeParsedCommand = useCallback(
    (
      rawCommand: string,
      parsed: {
        intent: string;
        targetApp?: string;
        queryOrText?: string;
        targetContact?: string;
        requiredPermission: string;
        needsConfirmation: boolean;
        confirmationPrompt?: string;
        spokenReply: string;
      },
      confirmed: boolean,
      executionSource: 'Local Native Engine' | 'Gemini AI',
    ): { reply: string; report: TaskExecutionReport; pendingConfirm?: boolean } => {
      const intent = (parsed.intent || 'CONVERSATION').toUpperCase();
      const knownContacts = Array.from(
        new Set([
          ...memory.priorityContacts,
          ...whatsappMessages.map((m) => m.sender),
        ]),
      );

      let resolvedContact = parsed.targetContact?.trim() || '';
      if (
        resolvedContact &&
        ['REPLY_WHATSAPP', 'SEND_WHATSAPP_VOICE', 'CALL_CONTACT', 'SEND_SMS'].includes(intent)
      ) {
        const contactCheck = resolveKnownContacts(resolvedContact, knownContacts);
        if (contactCheck.status === 'ambiguous') {
          const clarifyMsg = `Multiple contacts match "${resolvedContact}": ${contactCheck.matches.join(', ')}. Please specify the exact contact name before I proceed.`;
          return {
            reply: clarifyMsg,
            report: {
              userRequest: rawCommand,
              identifiedAction: `${intent} (Ambiguous Contact)`,
              requiredPermission: parsed.requiredPermission || 'Contacts',
              actionPerformed: 'Blocked ambiguous contact selection',
              succeeded: false,
              failureReason: clarifyMsg,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }
        if (contactCheck.status === 'unique') {
          resolvedContact = contactCheck.matches[0];
        }
      }

      const highRiskIntent = [
        'REPLY_WHATSAPP',
        'AUTO_REPLY_RULE',
        'REJECT_CALL',
        'END_CALL',
        'TELL_CALLER_BUSY',
        'CALL_CONTACT',
        'SEND_SMS',
        'SEND_WHATSAPP_VOICE',
        'SHARE_FILE',
      ].includes(intent);

      if ((parsed.needsConfirmation || highRiskIntent) && !confirmed) {
        return {
          reply:
            parsed.confirmationPrompt ||
            parsed.spokenReply ||
            `Confirm executing ${intent.toLowerCase().replace(/_/g, ' ')}?`,
          pendingConfirm: true,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: parsed.requiredPermission,
            actionPerformed: 'Waiting for explicit user approval',
            succeeded: false,
            failureReason: 'Confirmation required before executing external or irreversible action.',
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (
        [
          'READ_SCREEN',
          'EXPLAIN_SCREEN',
          'SCROLL_DOWN',
          'SCROLL_UP',
          'NAVIGATE_BACK',
          'NAVIGATE_HOME',
          'CLOSE_APP',
          'CLICK_ELEMENT',
          'TYPE_TEXT',
        ].includes(intent) &&
        !isGranted('accessibility')
      ) {
        const msg =
          'Accessibility Service is disabled. Please enable it in Settings before I can read or control the screen.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'AccessibilityService',
            actionPerformed: 'Verified AccessibilityService permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (
        [
          'READ_WHATSAPP',
          'SHOW_WHATSAPP_MESSAGES',
          'OPEN_CONTACT_MESSAGE',
          'READ_CONTACT_MESSAGE',
          'READ_NOTIFICATIONS',
          'REPLY_WHATSAPP',
          'SEND_WHATSAPP_VOICE',
          'AUTO_REPLY_RULE',
        ].includes(intent) &&
        !isGranted('notif_listener')
      ) {
        const msg =
          'Notification Listener permission is not allowed. Enable it to read or reply to WhatsApp messages.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'NotificationListenerService',
            actionPerformed: 'Verified Notification Access',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (['FLASHLIGHT_ON', 'FLASHLIGHT_OFF', 'CAPTURE_PHOTO'].includes(intent) && !isGranted('camera')) {
        const msg = 'Camera permission is required to control the flashlight or capture photos.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'CAMERA',
            actionPerformed: 'Checked CAMERA permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (['ANSWER_CALL', 'REJECT_CALL', 'END_CALL', 'CALL_CONTACT'].includes(intent) && !isGranted('phone')) {
        const msg = 'Phone Call permission is disabled. Enable it in Permissions before placing or managing calls.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'ANSWER_PHONE_CALLS',
            actionPerformed: 'Checked Phone Call permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      switch (intent) {
        case 'WAKE_ACK':
          return {
            reply: greetingName
              ? `Haan ${greetingName}, boliye. Main sun rahi hoon.`
              : parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'WAKE_ACK',
              requiredPermission: 'Microphone (RECORD_AUDIO)',
              actionPerformed: 'Activated on wake word',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_APP': {
          const target = (parsed.targetApp || 'WhatsApp').toLowerCase();
          if (target.includes('whatsapp')) {
            setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          } else if (target.includes('setting')) {
            setHardware((h) => ({ ...h, activeScreenKey: 'settings' }));
          } else {
            setHardware((h) => ({ ...h, activeScreenKey: 'article' }));
          }
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: `OPEN_APP (${parsed.targetApp || 'App'})`,
              requiredPermission: 'Launcher Intent',
              actionPerformed: `Opened ${parsed.targetApp || 'target app'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'CLOSE_APP':
        case 'NAVIGATE_HOME':
          setHardware((h) => ({ ...h, screenScrollIndex: 0 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AccessibilityService',
              actionPerformed:
                intent === 'CLOSE_APP'
                  ? `Closed ${parsed.targetApp || 'app'} and returned Home`
                  : 'Navigated to Home screen',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_SETTINGS':
          setHardware((h) => ({ ...h, activeScreenKey: 'settings' }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'OPEN_SETTINGS',
              requiredPermission: 'Android Settings Intent',
              actionPerformed: 'Opened Android Settings',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_CAMERA':
        case 'CAPTURE_PHOTO':
        case 'OPEN_DIALER':
        case 'OPEN_GALLERY':
        case 'OPEN_CONTACTS':
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'Android Intent',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'WEB_SEARCH':
        case 'YOUTUBE_SEARCH':
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'Android Search Intent',
              actionPerformed: `Searched: ${parsed.queryOrText || rawCommand}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'CHECK_BATTERY': {
          const batteryReply =
            hardware.batteryPercent !== null
              ? `Battery level is ${hardware.batteryPercent}%${hardware.batteryCharging ? ' (Charging)' : ''}.`
              : 'Device battery telemetry is managed natively on Android via BatteryManager.';
          return {
            reply: `${parsed.spokenReply} ${batteryReply}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'CHECK_BATTERY',
              requiredPermission: 'BatteryManager',
              actionPerformed: batteryReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'ENABLE_DND':
        case 'DISABLE_DND': {
          const dndOn = intent === 'ENABLE_DND';
          setHardware((h) => ({ ...h, dndEnabled: dndOn }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'ACCESS_NOTIFICATION_POLICY',
              actionPerformed: `Set Do Not Disturb to ${dndOn ? 'ON' : 'OFF'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'READ_SCREEN':
        case 'EXPLAIN_SCREEN': {
          const latestWa = whatsappMessages[0];
          const screenText =
            hardware.activeScreenKey === 'whatsapp' && latestWa
              ? `WhatsApp chat with ${latestWa.sender}: "${latestWa.text}". Buttons visible: Reply, Voice Call, Video Call.`
              : hardware.activeScreenKey === 'settings'
                ? 'Android Settings screen: Bluetooth ready, Digital Assistant set to SMW AI.'
                : 'Chrome article: Android Accessibility and MediaProjection privacy boundaries.';
          return {
            reply: `${parsed.spokenReply} ${screenText}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AccessibilityService',
              actionPerformed: screenText,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SCROLL_DOWN':
          setHardware((h) => ({ ...h, screenScrollIndex: h.screenScrollIndex + 240 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SCROLL_DOWN',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Scrolled down 240px',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'SCROLL_UP':
          setHardware((h) => ({
            ...h,
            screenScrollIndex: Math.max(0, h.screenScrollIndex - 240),
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SCROLL_UP',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Scrolled up 240px',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'NAVIGATE_BACK':
          setHardware((h) => ({ ...h, activeScreenKey: 'settings', screenScrollIndex: 0 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'NAVIGATE_BACK',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Performed Android GLOBAL_ACTION_BACK',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'SHOW_WHATSAPP_MESSAGES': {
          setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          const list = whatsappMessages
            .slice(0, 3)
            .map((m) => `${m.sender}: "${m.text}"`)
            .join(' | ');
          const summary = list || 'No WhatsApp messages in stream.';
          return {
            reply: `${parsed.spokenReply} ${summary}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SHOW_WHATSAPP_MESSAGES',
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'OPEN_CONTACT_MESSAGE':
        case 'READ_CONTACT_MESSAGE': {
          const contactQuery = (resolvedContact || parsed.targetContact || '').toLowerCase();
          const matched = whatsappMessages.find((m) =>
            m.sender.toLowerCase().includes(contactQuery),
          );
          if (intent === 'OPEN_CONTACT_MESSAGE') {
            setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          }
          const summary = matched
            ? matched.repliedText
              ? `${matched.sender}: "${matched.text}". Sent reply: "${matched.repliedText}"`
              : `${matched.sender} ne bheja hai: "${matched.text}"`
            : `${resolvedContact || parsed.targetContact || 'Contact'} ka koi unread WhatsApp message nahi mila.`;
          return {
            reply: summary,
            report: {
              userRequest: rawCommand,
              identifiedAction: `${intent} (${resolvedContact || parsed.targetContact || 'Contact'})`,
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: Boolean(matched),
              failureReason: matched ? undefined : 'No message found for requested contact.',
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'READ_WHATSAPP':
        case 'READ_NOTIFICATIONS': {
          const latest = whatsappMessages[0];
          const summary =
            parsed.queryOrText === 'full' && latest
              ? `${latest.sender} ka poora message: "${latest.text}"`
              : latest
                ? `${latest.sender} sent (${latest.isUrgent ? 'Urgent' : 'Normal'}): "${latest.text}"`
                : 'No unread WhatsApp notifications.';
          return {
            reply: `${parsed.spokenReply} ${summary}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SEND_WHATSAPP_VOICE': {
          const contact = resolvedContact || parsed.targetContact || whatsappMessages[0]?.sender || 'Ali';
          setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          return {
            reply: `${contact} ki WhatsApp chat khol di hai taake aap voice message record karke bhej sakein.`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `SEND_WHATSAPP_VOICE (${contact})`,
              requiredPermission: 'NotificationListenerService + READ_CONTACTS',
              actionPerformed: `Opened WhatsApp chat for ${contact} voice message`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'REPLY_WHATSAPP': {
          const contact = resolvedContact || parsed.targetContact || whatsappMessages[0]?.sender || 'Ali';
          const replyText = parsed.queryOrText || autoReplyRule.activeTemplate;
          setWhatsappMessages((prev) => {
            const exists = prev.some((m) =>
              m.sender.toLowerCase().includes(contact.toLowerCase()),
            );
            if (!exists) {
              return [
                {
                  id: `wa-${Date.now()}`,
                  appSource: 'WhatsApp',
                  sender: contact,
                  text: 'Conversation started via SMW AI',
                  timestamp: formatTime(),
                  isUrgent: false,
                  autoReplied: true,
                  repliedText: replyText,
                },
                ...prev,
              ];
            }
            return prev.map((m) =>
              m.sender.toLowerCase().includes(contact.toLowerCase())
                ? { ...m, autoReplied: true, repliedText: replyText }
                : m,
            );
          });
          return {
            reply: `${contact} ko WhatsApp message bhej diya gaya hai: "${replyText}"`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `REPLY_WHATSAPP (${contact})`,
              requiredPermission: 'NotificationListenerService + RemoteInput',
              actionPerformed: `Sent WhatsApp message to ${contact}: "${replyText}"`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'CALL_CONTACT': {
          const contact = resolvedContact || parsed.targetContact || 'Contact';
          setActiveCall({
            id: `call-out-${Date.now()}`,
            callerName: contact,
            phoneNumber: 'Authorized Contact',
            status: 'ACTIVE',
          });
          return {
            reply: `${contact} ko call milayi ja rahi hai.`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `CALL_CONTACT (${contact})`,
              requiredPermission: 'ANSWER_PHONE_CALLS + Contacts',
              actionPerformed: `Initiated call to ${contact}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SEND_SMS': {
          const contact = resolvedContact || parsed.targetContact || 'Contact';
          const smsText = parsed.queryOrText || 'Please call me back.';
          return {
            reply: `${contact} ko SMS composer mein message tayyar karke bhej diya gaya hai: "${smsText}"`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `SEND_SMS (${contact})`,
              requiredPermission: 'SMS Intent + Contacts',
              actionPerformed: `Prepared SMS to ${contact}: "${smsText}"`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'FLASHLIGHT_ON':
        case 'FLASHLIGHT_OFF': {
          const on = intent === 'FLASHLIGHT_ON';
          setHardware((h) => ({ ...h, flashlightOn: on }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'CAMERA',
              actionPerformed: `Turned flashlight ${on ? 'ON' : 'OFF'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'VOLUME_UP':
        case 'VOLUME_DOWN': {
          const delta = intent === 'VOLUME_UP' ? 15 : -15;
          setHardware((h) => ({
            ...h,
            volumePercent: Math.max(0, Math.min(100, h.volumePercent + delta)),
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AudioManager',
              actionPerformed: `Adjusted volume (${delta > 0 ? '+15%' : '-15%'})`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'MEDIA_PLAY':
        case 'MEDIA_PAUSE':
        case 'MEDIA_NEXT': {
          setHardware((h) => ({
            ...h,
            mediaPlaying: intent !== 'MEDIA_PAUSE',
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AudioManager',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SET_ALARM':
        case 'SET_TIMER':
        case 'ADD_NOTE':
        case 'ADD_REMINDER': {
          const typeMap: Record<string, DailyTask['type']> = {
            SET_ALARM: 'alarm',
            SET_TIMER: 'timer',
            ADD_NOTE: 'note',
            ADD_REMINDER: 'reminder',
          };
          setDailyTasks((prev) => [
            {
              id: `task-${Date.now()}`,
              type: typeMap[intent] || 'note',
              title: parsed.queryOrText || rawCommand,
              detail: 'Created via SMW AI command',
              createdAt: formatTime(),
            },
            ...prev,
          ]);
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'SET_ALARM / Local Store',
              actionPerformed: `Saved ${typeMap[intent] || 'task'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'ANSWER_CALL':
        case 'REJECT_CALL':
        case 'END_CALL':
        case 'SPEAKERPHONE_ON':
        case 'TELL_CALLER_BUSY': {
          if (!activeCall && intent !== 'SPEAKERPHONE_ON') {
            return {
              reply: 'No active incoming call right now.',
              report: {
                userRequest: rawCommand,
                identifiedAction: intent,
                requiredPermission: 'ANSWER_PHONE_CALLS',
                actionPerformed: 'Checked active call state',
                succeeded: false,
                failureReason: 'No active call present.',
                executionSource,
                timestamp: formatTime(),
              },
            };
          }
          if (intent === 'ANSWER_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'ACTIVE' } : null));
          } else if (intent === 'REJECT_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'REJECTED' } : null));
          } else if (intent === 'END_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'ENDED' } : null));
          } else if (intent === 'SPEAKERPHONE_ON') {
            setCallConfig((cfg) => ({ ...cfg, speakerphoneActive: true }));
          } else if (intent === 'TELL_CALLER_BUSY') {
            setActiveCall((c) =>
              c ? { ...c, status: 'BUSY_NOTIFIED', aiDisclosureSent: callConfig.busyNotice } : null,
            );
          }
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'ANSWER_PHONE_CALLS',
              actionPerformed: `Executed ${intent}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        default:
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'None',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
      }
    },
    [
      activeCall,
      autoReplyRule.activeTemplate,
      callConfig.busyNotice,
      greetingName,
      hardware.activeScreenKey,
      hardware.batteryCharging,
      hardware.batteryPercent,
      isGranted,
      memory.priorityContacts,
      whatsappMessages,
    ],
  );

  const handleSendCommand = useCallback(
    async (text: string, confirmed = false) => {
      interruptSpeech();
      const latestPending = [...messages]
        .reverse()
        .find((m) => m.role === 'assistant' && m.pendingConfirmation)?.pendingConfirmation;

      if (!confirmed && latestPending) {
        const cleanLower = text.trim().toLowerCase().replace(/[.!?]+$/, '');
        if (/^(yes|yeah|yep|haan|han|ji|ok|okay|confirm|approved?|bhej\s*do|kar\s*do|send(?:\s*it)?|mila\s*do)$/i.test(cleanLower)) {
          setMessages((prev) => [
            ...prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
            {
              id: `u-${Date.now()}`,
              role: 'user',
              text,
              timestamp: formatTime(),
            },
          ]);
          await handleSendCommand(latestPending.rawCommand, true);
          return;
        }
        if (/^(no|nahi|cancel|abort|stop|mat\s*bhejo|rehne\s*do)$/i.test(cleanLower)) {
          setMessages((prev) => [
            ...prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
            {
              id: `u-${Date.now()}`,
              role: 'user',
              text,
              timestamp: formatTime(),
            },
            {
              id: `a-cancel-${Date.now()}`,
              role: 'assistant',
              text: 'Action cancelled. Kuch bhi nahi bheja gaya.',
              timestamp: formatTime(),
            },
          ]);
          void speakText('Action cancelled.');
          return;
        }
      }

      if (confirmed) {
        setMessages((prev) =>
          prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
        );
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: `u-${Date.now()}`,
            role: 'user',
            text,
            timestamp: formatTime(),
          },
        ]);
      }

      const localMatch = parseLocalCommand(text, memory.wakePhrase);
      if (localMatch) {
        const result = executeParsedCommand(text, localMatch, confirmed, 'Local Native Engine');
        setLatestReport(result.report);
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: 'assistant',
            text: result.reply,
            timestamp: formatTime(),
            taskReport: result.report,
            pendingConfirmation: result.pendingConfirm
              ? { rawCommand: text, prompt: result.reply }
              : undefined,
          },
        ]);
        speakText(result.reply);
        return;
      }

      setOrbState('THINKING');
      const wantsDeviceAction = isLikelyDeviceAction(text, memory.wakePhrase);

      if (!wantsDeviceAction) {
        try {
          const { ok, status, data } = await safeFetchJson<{ reply?: string; modelUsed?: string }>(
            '/api/ai/chat',
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                message: text,
                assistantName: memory.assistantName,
                preferredLanguage: memory.preferredLanguage,
                persona: memory.voicePersona || 'punjabi_legend',
                userName: greetingName || '',
                history: messages.slice(-6).map((m) => ({ role: m.role, text: m.text })),
              }),
            },
          );

          if (!ok) {
            throw new Error(data.error || `AI chat server returned status ${status}.`);
          }

          const replyText = data.reply || 'I am ready to help.';
          const chatReport: TaskExecutionReport = {
            userRequest: text,
            identifiedAction: 'CONVERSATIONAL_CHAT',
            requiredPermission: 'None',
            actionPerformed: data.modelUsed
              ? `Conversational reply generated via ${data.modelUsed}`
              : 'Conversational reply generated via Gemini AI',
            succeeded: true,
            executionSource: 'Gemini AI',
            timestamp: formatTime(),
          };
          setLatestReport(chatReport);
          setMessages((prev) => [
            ...prev,
            {
              id: `a-${Date.now()}`,
              role: 'assistant',
              text: replyText,
              timestamp: formatTime(),
              taskReport: chatReport,
            },
          ]);
          speakText(replyText);
        } catch (err) {
          const errMsg = err instanceof Error ? err.message : 'Network error reaching AI chat backend.';
          const failReport: TaskExecutionReport = {
            userRequest: text,
            identifiedAction: 'CONVERSATIONAL_CHAT',
            requiredPermission: 'Server AI API',
            actionPerformed: 'Attempted conversational reply via /api/ai/chat',
            succeeded: false,
            failureReason: errMsg,
            executionSource: 'Gemini AI',
            timestamp: formatTime(),
          };
          setLatestReport(failReport);
          setMessages((prev) => [
            ...prev,
            {
              id: `err-${Date.now()}`,
              role: 'assistant',
              text: `${errMsg} — Native device commands (Open WhatsApp, Read Screen, Flashlight, Scroll, Calls, Alarms) work locally without Gemini.`,
              timestamp: formatTime(),
              taskReport: failReport,
            },
          ]);
          setOrbState('IDLE');
        }
        return;
      }

      try {
        const { ok, status, data } = await safeFetchJson<{
          intent: string;
          targetApp?: string;
          queryOrText?: string;
          targetContact?: string;
          requiredPermission: string;
          needsConfirmation: boolean;
          confirmationPrompt?: string;
          spokenReply: string;
        }>('/api/ai/command', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text,
            assistantName: memory.assistantName,
            preferredLanguage: memory.preferredLanguage,
            persona: memory.voicePersona || 'punjabi_legend',
            screenSummary: `Active screen: ${hardware.activeScreenKey}`,
            unreadNotificationsCount: whatsappMessages.length,
          }),
        });

        if (!ok) {
          throw new Error(data.error || `AI server returned status ${status}.`);
        }

        const result = executeParsedCommand(text, data, confirmed, 'Gemini AI');
        setLatestReport(result.report);
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: 'assistant',
            text: result.reply,
            timestamp: formatTime(),
            taskReport: result.report,
            pendingConfirmation: result.pendingConfirm
              ? { rawCommand: text, prompt: result.reply }
              : undefined,
          },
        ]);
        speakText(result.reply);
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : 'Network error reaching AI backend.';
        const failReport: TaskExecutionReport = {
          userRequest: text,
          identifiedAction: 'AI_COMMAND_PARSE',
          requiredPermission: 'Server AI API',
          actionPerformed: 'Attempted device-action parsing via Gemini AI',
          succeeded: false,
          failureReason: errMsg,
          executionSource: 'Gemini AI',
          timestamp: formatTime(),
        };
        setLatestReport(failReport);
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            role: 'assistant',
            text: `${errMsg} — Native device commands (Open WhatsApp, Read Screen, Flashlight, Scroll, Calls, Alarms) work locally without Gemini.`,
            timestamp: formatTime(),
            taskReport: failReport,
          },
        ]);
        setOrbState('IDLE');
      }
    },
    [
      executeParsedCommand,
      greetingName,
      hardware.activeScreenKey,
      interruptSpeech,
      memory.assistantName,
      memory.preferredLanguage,
      memory.voicePersona,
      memory.wakePhrase,
      messages,
      speakText,
      whatsappMessages.length,
    ],
  );

  const startVoiceRecognition = useCallback(
    (continuous: boolean) => {
      if (!isGranted('mic')) {
        setMessages((prev) => [
          ...prev,
          {
            id: `mic-err-${Date.now()}`,
            role: 'assistant',
            text: 'Microphone permission is currently denied. Allow it in Settings to use voice commands.',
            timestamp: formatTime(),
          },
        ]);
        return;
      }

      const SpeechRec =
        (window as unknown as { SpeechRecognition?: new () => unknown; webkitSpeechRecognition?: new () => unknown })
          .SpeechRecognition ||
        (window as unknown as { webkitSpeechRecognition?: new () => unknown })
          .webkitSpeechRecognition;

      if (!SpeechRec) {
        setMessages((prev) => [
          ...prev,
          {
            id: `sr-na-${Date.now()}`,
            role: 'assistant',
            text: 'Browser SpeechRecognition is not supported in this browser tab. Use the text message input.',
            timestamp: formatTime(),
          },
        ]);
        return;
      }

      interruptSpeech();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const rec = new (SpeechRec as any)();
      rec.continuous = continuous;
      rec.interimResults = true;
      rec.lang =
        memory.preferredLanguage === 'pa-IN'
          ? 'pa-IN'
          : memory.preferredLanguage === 'hi-IN'
            ? 'hi-IN'
            : memory.preferredLanguage === 'ur-PK'
              ? 'ur-PK'
              : memory.preferredLanguage === 'en-US'
                ? 'en-US'
                : 'en-IN';

      rec.onstart = () => setOrbState('LISTENING');
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      rec.onresult = (event: any) => {
        const last = event.results[event.results.length - 1];
        const transcript = last[0]?.transcript?.trim() || '';
        setPartialTranscript(transcript);
        if (last.isFinal && transcript) {
          setPartialTranscript('');
          if (memory.wakeWordRequired && continuous) {
            const { wakeWord } = stripWakePrefix(transcript, memory.wakePhrase);
            if (!wakeWord) return;
          }
          if (!continuous) {
            rec.stop();
          }
          void handleSendCommand(transcript);
        }
      };
      rec.onerror = () => {
        setOrbState('IDLE');
        setPartialTranscript('');
      };
      rec.onend = () => {
        setOrbState((curr) => (curr === 'LISTENING' ? 'IDLE' : curr));
        setPartialTranscript('');
      };

      recognitionRef.current = rec;
      rec.start();
    },
    [
      handleSendCommand,
      interruptSpeech,
      isGranted,
      memory.preferredLanguage,
      memory.wakePhrase,
      memory.wakeWordRequired,
    ],
  );

  const stopVoiceRecognition = useCallback(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const rec = recognitionRef.current as any;
    if (rec) {
      rec.stop();
      recognitionRef.current = null;
    }
    setOrbState('IDLE');
    setPartialTranscript('');
  }, []);

  const handleToggleListen = () => {
    if (orbState === 'LISTENING') {
      setHandsFreeMode(false);
      stopVoiceRecognition();
    } else {
      startVoiceRecognition(false);
    }
  };

  const handleToggleHandsFree = (enabled: boolean) => {
    setHandsFreeMode(enabled);
    if (enabled) {
      startVoiceRecognition(true);
    } else {
      stopVoiceRecognition();
    }
  };

  const togglePermission = (id: string) => {
    setPermissions((prev) =>
      prev.map((p) => (p.id === id ? { ...p, granted: !p.granted } : p)),
    );
  };

  const grantPermission = (id: string) => {
    setPermissions((prev) =>
      prev.map((p) => (p.id === id ? { ...p, granted: true } : p)),
    );
  };

  const handleSubmitText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const text = input.trim();
    setInput('');
    void handleSendCommand(text);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const allowedImageTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];
    if (!allowedImageTypes.includes(file.type.toLowerCase()) || file.size > 4 * 1024 * 1024) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-img-val-${Date.now()}`,
          role: 'assistant',
          text: 'Only PNG, JPEG, WebP, or GIF images up to 4 MB are allowed.',
          timestamp: formatTime(),
        },
      ]);
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!dataUrl) return;
      setMessages((prev) => [
        ...prev,
        {
          id: `u-img-${Date.now()}`,
          role: 'user',
          text: `Uploaded image: ${file.name}`,
          timestamp: formatTime(),
        },
      ]);
      setOrbState('THINKING');
      try {
        const { ok, data } = await safeFetchJson<{ summary?: string }>(
          '/api/ai/analyze-screen',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: dataUrl,
              mimeType: file.type || 'image/jpeg',
              prompt: 'Describe and analyze this image concisely.',
            }),
          },
          30000,
        );
        if (!ok) throw new Error(data.error || 'Image analysis failed.');
        const summary = data.summary || 'Analysis completed.';
        setMessages((prev) => [
          ...prev,
          {
            id: `a-img-${Date.now()}`,
            role: 'assistant',
            text: summary,
            timestamp: formatTime(),
          },
        ]);
        speakText(summary);
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unable to analyze image.';
        setMessages((prev) => [
          ...prev,
          {
            id: `err-img-${Date.now()}`,
            role: 'assistant',
            text: msg,
            timestamp: formatTime(),
          },
        ]);
        setOrbState('IDLE');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleMicPress = () => {
    ensureAudioContext();
    if (orbState === 'SPEAKING') {
      interruptSpeech();
      return;
    }
    if (!isGranted('mic')) {
      grantPermission('mic');
    }
    handleToggleListen();
  };

  const handleOpenAvatarMode = () => {
    ensureAudioContext();
    setAvatarModeOpen(true);
    if (messages.length === 0) {
      const greetText = greetingName
        ? `Sat Sri Akal ${greetingName}! Main SMW AI haan. Bol ke dasso, aaj ki madad karaan?`
        : 'Sat Sri Akal! Main SMW AI haan. Bol ke dasso, aaj ki madad karaan?';
      void speakText(greetText);
    }
  };

  const handleSpeakGreeting = () => {
    ensureAudioContext();
    const greetText = greetingName
      ? `Sat Sri Akal ${greetingName}! How are you doing today? Main haan SMW AI, ready to help.`
      : 'Sat Sri Akal! Hello, how are you? Main haan SMW AI, ready to assist you.';
    void speakText(greetText);
  };

  const handleRunScreenReader = (mode: 'read' | 'explain' | 'click-reply') => {
    const cmd =
      mode === 'read'
        ? 'Read my screen'
        : mode === 'explain'
          ? 'Explain screen'
          : 'Ali ko reply bhej do';
    void handleSendCommand(cmd);
  };

  const handleAnalyzeCapturedImage = async (base64: string) => {
    const { ok, data } = await safeFetchJson<{
      summary?: string;
      elements?: string[];
      suggestedAction?: string;
    }>(
      '/api/ai/analyze-screen',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: 'image/jpeg',
          prompt: 'Summarize what is visible on this captured screen and highlight actionable items.',
        }),
      },
      30000,
    );
    if (!ok) {
      return {
        summary: data.error || 'Unable to analyze captured screen frame.',
        elements: [],
      };
    }
    const summary = data.summary || 'Screen captured and analyzed.';
    void speakText(summary);
    return {
      summary,
      elements: Array.isArray(data.elements) ? data.elements : [],
      suggestedAction: data.suggestedAction,
    };
  };

  const handleSimulateIncomingWhatsApp = async (sender: string, text: string) => {
    let isUrgent = false;
    let urgencyReason = '';
    let aiDraftReply = autoReplyRule.activeTemplate;

    try {
      const { ok, data } = await safeFetchJson<{
        isUrgent?: boolean;
        reason?: string;
        suggestedReply?: string;
      }>('/api/ai/whatsapp-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sender, message: text }),
      });
      if (ok) {
        isUrgent = Boolean(data.isUrgent);
        urgencyReason = data.reason || '';
        if (data.suggestedReply) aiDraftReply = data.suggestedReply;
      }
    } catch {
      // keep safe defaults
    }

    const newMsg: WhatsAppMessage = {
      id: `wa-${Date.now()}`,
      appSource: 'WhatsApp',
      sender,
      text,
      timestamp: formatTime(),
      isUrgent,
      urgencyReason,
      aiDraftReply,
      autoReplied: autoReplyRule.enabled,
      repliedText: autoReplyRule.enabled ? autoReplyRule.activeTemplate : undefined,
    };
    setWhatsappMessages((prev) => [newMsg, ...prev]);
    if (memory.readWhatsAppAloud) {
      const announceText = `${greetingName || 'Faisal'}, ${sender} ka message aaya hai.`;
      setMessages((prev) => [
        ...prev,
        {
          id: `wa-alert-${Date.now()}`,
          role: 'assistant',
          text: `${announceText} Say "Complete message parho" to hear the full message or reply by voice.`,
          timestamp: formatTime(),
        },
      ]);
      void speakText(announceText);
    }
  };

  const handleReplyWhatsApp = (id: string, replyText: string) => {
    if (!replyText.trim()) return;
    setWhatsappMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, autoReplied: true, repliedText: replyText.trim() } : m)),
    );
    void speakText('WhatsApp reply sent.');
  };

  const handleSimulateCall = (callerName: string | null, phoneNumber: string) => {
    const newCall: CallSession = {
      id: `call-${Date.now()}`,
      callerName,
      phoneNumber,
      status: 'RINGING',
    };
    setActiveCall(newCall);
    if (callConfig.announceCallerAloud) {
      void speakText(`Incoming call from ${callerName || phoneNumber}.`);
    }
  };

  const handleCallAction = (action: 'ANSWER' | 'REJECT' | 'END' | 'SPEAKER' | 'BUSY_NOTICE') => {
    if (action === 'SPEAKER') {
      setCallConfig((c) => ({ ...c, speakerphoneActive: !c.speakerphoneActive }));
      return;
    }
    if (!activeCall) return;
    if (action === 'ANSWER') {
      setActiveCall((c) => (c ? { ...c, status: 'ACTIVE' } : null));
      void speakText('Call answered.');
    } else if (action === 'REJECT') {
      setActiveCall((c) => (c ? { ...c, status: 'REJECTED' } : null));
    } else if (action === 'END') {
      setActiveCall((c) => (c ? { ...c, status: 'ENDED' } : null));
    } else if (action === 'BUSY_NOTICE') {
      setActiveCall((c) =>
        c ? { ...c, status: 'BUSY_NOTIFIED', aiDisclosureSent: callConfig.busyNotice } : null,
      );
      void speakText('AI busy notice sent.');
    }
  };

  const waveHeights = ['h-1.5', 'h-2.5', 'h-4', 'h-6', 'h-8', 'h-6', 'h-4', 'h-2.5', 'h-1.5'];
  const isAudioActive = orbState === 'LISTENING' || orbState === 'SPEAKING';

  return (
    <div className="min-h-screen w-full bg-[#02050D] text-white lg:flex lg:items-center lg:justify-center lg:p-6">
      <div className="relative flex min-h-screen w-full flex-col overflow-hidden bg-gradient-to-b from-[#040917] via-[#030713] to-[#02050D] lg:min-h-[760px] lg:max-w-5xl lg:rounded-[34px] lg:border lg:border-blue-500/20 lg:shadow-[0_0_90px_rgba(0,119,255,0.22)]">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[430px] bg-[radial-gradient(circle_at_50%_38%,rgba(14,116,255,0.24),transparent_72%)]" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[210px] bg-[radial-gradient(ellipse_at_50%_100%,rgba(0,140,255,0.28),transparent_72%)]" />

        {/* Tap-to-dismiss Splash Overlay */}
        {splashVisible && (
          <div
            onClick={() => setSplashVisible(false)}
            className="absolute inset-0 z-50 flex cursor-pointer flex-col items-center justify-center bg-[#02050D] px-6 text-center transition-opacity duration-300"
          >
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_42%,rgba(30,136,255,0.28),transparent_65%)]" />
            <div className="relative h-44 w-44 overflow-hidden rounded-3xl border border-[#1E88FF]/60 bg-[#02050D] shadow-[0_0_50px_rgba(30,136,255,0.45)]">
              <SmwEmblem alt="SMW AI Official Identity" className="h-full w-full select-none object-contain" />
            </div>
            <h2 className="mt-5 font-display text-2xl font-extrabold italic tracking-wide text-white">
              SMW <span className="text-[#1E88FF]">AI</span>
            </h2>
            <p className="mt-1 text-xs font-medium tracking-wide text-sky-300">
              Your Smart AI Companion
            </p>
            <div className="mt-5 h-1 w-28 overflow-hidden rounded-full bg-slate-800">
              <div className="h-full w-1/2 animate-pulse rounded-full bg-gradient-to-r from-[#1677FF] to-[#38BDF8]" />
            </div>
          </div>
        )}

        {/* Header Bar */}
        <header className="relative z-10 flex items-center justify-between gap-4 px-4 pt-4 pb-2 lg:px-8 lg:pt-6">
          <div className="flex items-center gap-3">
            <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-full bg-[#02050D] ring-2 ring-[#1D8BFF] shadow-[0_0_18px_rgba(29,139,255,0.78)]">
              <SmwEmblem alt="SMW AI" compact className="pointer-events-none h-full w-full select-none object-cover object-top" />
            </div>
            <div className="flex flex-col">
              <h1 className="whitespace-nowrap font-display text-2xl font-extrabold italic leading-none tracking-wide text-white">
                SMW <span className="text-[#1E88FF]">AI</span>
              </h1>
              <span className="mt-1 whitespace-nowrap text-[11px] font-medium tracking-wide text-slate-300">
                Your Smart AI Companion
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {hardware.batteryPercent !== null && (
              <span className="hidden items-center gap-1.5 text-xs font-mono tabular-nums text-slate-300 sm:inline-flex">
                {hardware.batteryCharging ? (
                  <BatteryCharging className="h-4 w-4 text-emerald-400" />
                ) : (
                  <Battery className="h-4 w-4 text-sky-400" />
                )}
                {hardware.batteryPercent}%
              </span>
            )}
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              aria-label="Settings"
              className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-full border border-blue-400/25 bg-[#0C152B]/90 text-white shadow-[0_0_14px_rgba(29,139,255,0.2)] transition-colors hover:border-blue-400/60 hover:bg-[#13203F]"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </header>

        {/* Compact Workspace Navigation */}
        <nav
          aria-label="SMW AI Workspaces"
          className="relative z-10 flex items-center gap-1.5 overflow-x-auto px-4 pb-2 lg:px-8"
        >
          {(
            [
              { id: 'assistant', label: 'Assistant' },
              { id: 'device', label: 'Device Lab' },
              { id: 'automation', label: 'WhatsApp & Calls' },
              { id: 'permissions', label: 'Permissions' },
              { id: 'android', label: 'Android Studio' },
            ] as const
          ).map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`min-h-[36px] shrink-0 whitespace-nowrap rounded-xl border px-3 py-1.5 text-xs font-medium transition-colors ${
                  active
                    ? 'border-[#38BDF8]/70 bg-[#1677FF]/25 text-white shadow-[0_0_14px_rgba(30,136,255,0.28)]'
                    : 'border-slate-800/80 bg-[#071022]/75 text-slate-300 hover:border-blue-400/40 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Responsive Body */}
        {activeTab === 'assistant' ? (
        <main className="relative z-10 grid flex-1 grid-cols-1 gap-4 px-4 pt-2 pb-4 lg:grid-cols-12 lg:gap-8 lg:px-8 lg:py-4">
          {/* Left Stage: Identity Showcase + Voice Orb + Avatar Mode CTA */}
          <div className="flex flex-col justify-between gap-4 lg:col-span-5">
            <section className="mx-auto flex w-full max-w-[390px] items-center justify-center lg:max-w-none">
              <div className="relative w-full overflow-hidden rounded-[26px] border border-[#1E88FF]/30 bg-[#02050D] shadow-[0_0_40px_rgba(14,116,255,0.24)]">
                <div className="h-[220px] w-full sm:h-[245px] lg:h-[290px]">
                  <SmwEmblem alt="SMW AI Assistant" className="pointer-events-none h-full w-full select-none object-contain" />
                </div>
                <div
                  role={!authProfile && !authLoading ? 'button' : undefined}
                  tabIndex={!authProfile && !authLoading ? 0 : undefined}
                  onClick={!authProfile && !authLoading ? () => void handleGoogleLogin() : undefined}
                  onKeyDown={
                    !authProfile && !authLoading
                      ? (e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            void handleGoogleLogin();
                          }
                        }
                      : undefined
                  }
                  className={`absolute right-2.5 top-2.5 flex min-w-[126px] max-w-[160px] -rotate-2 flex-col items-center justify-center rounded-[18px] border border-[#1E88FF]/80 bg-[#040C20]/92 px-3 py-2 text-center shadow-[0_0_24px_rgba(30,136,255,0.45)] backdrop-blur-sm ${
                    !authProfile && !authLoading ? 'cursor-pointer hover:border-[#38BDF8]' : ''
                  }`}
                >
                  <p className="font-display text-[12px] font-bold italic leading-tight text-white">
                    {greetingName ? `Hello ${greetingName}! 👋` : 'Hello! 👋'}
                  </p>
                  <p className="mt-0.5 text-[10px] leading-tight text-slate-200">
                    How can I help you?
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleSpeakGreeting}
                  aria-label="Hear Punjabi voice greeting"
                  className="absolute bottom-2.5 left-2.5 inline-flex min-h-[34px] items-center gap-1.5 rounded-xl border border-[#38BDF8]/50 bg-[#040C20]/90 px-2.5 py-1 text-[11px] font-medium text-sky-200 backdrop-blur-sm transition-colors hover:border-[#38BDF8] hover:text-white"
                >
                  <Volume2 className="h-3.5 w-3.5 text-[#38BDF8]" />
                  <span>Voice Greet</span>
                </button>
                <div className="pointer-events-none absolute inset-x-0 bottom-0 h-6 bg-gradient-to-t from-[#030816] to-transparent" />
              </div>
            </section>

            {/* Voice Orb + Symmetric Equalizer + Avatar Mode */}
            <section className="flex flex-col items-center justify-center rounded-[24px] border border-blue-400/15 bg-[#071022]/65 px-4 py-4">
              <div className="flex items-center justify-center gap-4">
                <div className="flex items-center gap-1.5" aria-hidden="true">
                  {waveHeights.map((h, i) => (
                    <span
                      key={`wl-${i}`}
                      className={`w-[3px] rounded-full bg-gradient-to-t from-[#0066FF] to-[#38BDF8] transition-all ${h} ${
                        isAudioActive ? 'animate-pulse opacity-100' : 'opacity-85'
                      }`}
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleMicPress}
                  aria-label={orbState === 'LISTENING' ? 'Stop listening' : 'Tap to Speak'}
                  className={`relative flex h-[74px] w-[74px] shrink-0 items-center justify-center rounded-full border-2 border-[#38BDF8] bg-gradient-to-b from-[#0C2D6B] to-[#051438] text-white transition-transform active:scale-95 ${
                    orbState === 'LISTENING'
                      ? 'animate-pulse shadow-[0_0_38px_rgba(56,189,248,0.95),inset_0_0_20px_rgba(56,189,248,0.6)]'
                      : 'shadow-[0_0_30px_rgba(0,149,255,0.85),inset_0_0_18px_rgba(56,189,248,0.45)]'
                  }`}
                >
                  {orbState === 'LISTENING' ? (
                    <MicOff className="h-8 w-8" />
                  ) : (
                    <Mic className="h-8 w-8" />
                  )}
                </button>

                <div className="flex items-center gap-1.5" aria-hidden="true">
                  {waveHeights.map((h, i) => (
                    <span
                      key={`wr-${i}`}
                      className={`w-[3px] rounded-full bg-gradient-to-t from-[#0066FF] to-[#38BDF8] transition-all ${h} ${
                        isAudioActive ? 'animate-pulse opacity-100' : 'opacity-85'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <p className="mt-2.5 text-center text-[13px] font-medium text-white">
                {orbState === 'LISTENING'
                  ? partialTranscript
                    ? `"${partialTranscript}"`
                    : 'Listening...'
                  : orbState === 'THINKING'
                    ? 'Thinking...'
                    : orbState === 'SPEAKING'
                      ? 'Speaking...'
                      : 'Tap to Speak'}
              </p>

              <button
                type="button"
                onClick={handleOpenAvatarMode}
                className="mt-3 inline-flex min-h-[44px] items-center gap-2 rounded-2xl border border-[#38BDF8]/55 bg-[#081736]/95 px-5 py-2.5 text-xs font-semibold tracking-wide text-sky-100 shadow-[0_6px_24px_rgba(14,116,255,0.32)] transition-all hover:border-[#38BDF8] hover:bg-[#0D2350] active:scale-95"
              >
                <Sparkles className="h-4 w-4 text-[#38BDF8]" />
                <span>Avatar Voice Mode</span>
              </button>
            </section>
          </div>

          {/* Right Column: Conversation Stream + Composer */}
          <div className="flex flex-col justify-between gap-4 lg:col-span-7">
            <section className="flex flex-1 flex-col justify-between rounded-[22px] border border-blue-400/20 bg-[#0A1326]/90 px-4 py-4 shadow-[0_0_28px_rgba(14,116,255,0.14)] backdrop-blur-md">
              {messages.length === 0 ? (
                <div className="flex flex-1 flex-col justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-3.5">
                      <div className="h-[70px] w-[70px] shrink-0 overflow-hidden rounded-2xl border border-[#1E88FF]/45 bg-[#02050D] shadow-[0_0_16px_rgba(30,136,255,0.28)]">
                        <SmwEmblem alt="SMW AI Profile" compact className="pointer-events-none h-full w-full select-none object-cover object-top" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h2 className="font-display text-lg font-bold tracking-tight text-white">
                          Welcome to <span className="text-[#1E88FF]">SMW AI!</span>
                        </h2>
                        <p className="mt-1 text-[13px] leading-snug text-slate-200/95">
                          Your Smart AI Companion. Chat, create, analyze, and speak in Punjabi, Urdu, Hindi, or English.
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-2">
                      {QUICK_PROMPTS.map((q) => (
                        <button
                          key={q}
                          type="button"
                          onClick={() => void handleSendCommand(q)}
                          className="min-h-[36px] rounded-xl border border-slate-700/75 bg-[#060E20] px-3 py-1.5 text-left text-xs text-slate-200 transition-colors hover:border-[#1E88FF] hover:text-white"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>

                  {!authLoading && !authProfile && (
                    <div className="flex flex-wrap items-center justify-between gap-2 border-t border-blue-400/15 pt-3">
                      <span className="text-[11px] text-slate-300">
                        Sign in to personalize your greeting
                      </span>
                      <button
                        type="button"
                        disabled={isLoggingIn}
                        onClick={() => void handleGoogleLogin()}
                        className="gsi-material-button shrink-0"
                      >
                        <div className="gsi-material-button-state" />
                        <div className="gsi-material-button-content-wrapper">
                          <div className="gsi-material-button-icon">
                            <svg
                              version="1.1"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 48 48"
                              className="block h-full w-full"
                            >
                              <path
                                fill="#EA4335"
                                d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                              />
                              <path
                                fill="#4285F4"
                                d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                              />
                              <path
                                fill="#FBBC05"
                                d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                              />
                              <path
                                fill="#34A853"
                                d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                              />
                              <path fill="none" d="M0 0h48v48H0z" />
                            </svg>
                          </div>
                          <span className="gsi-material-button-contents">
                            {isLoggingIn ? 'Signing in...' : 'Sign in with Google'}
                          </span>
                        </div>
                      </button>
                      {authError && (
                        <p className="w-full text-[11px] text-rose-400">{authError}</p>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div ref={chatScrollRef} className="max-h-[260px] space-y-2.5 overflow-y-auto pr-1 lg:max-h-[400px]">
                  {messages.map((msg) => {
                    const isUser = msg.role === 'user';
                    return (
                      <div
                        key={msg.id}
                        className={`rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed ${
                          isUser
                            ? 'ml-6 border border-blue-500/35 bg-[#112040]/90 text-white'
                            : 'mr-4 border border-slate-700/60 bg-[#070E1E]/95 text-slate-100'
                        }`}
                      >
                        {!isUser && (
                          <div className="mb-1.5 flex items-center gap-2">
                            <div className="h-5 w-5 overflow-hidden rounded-full ring-1 ring-[#1E88FF]">
                              <SmwEmblem alt="SMW AI" compact className="h-full w-full object-cover object-top" />
                            </div>
                            <span className="text-[11px] font-semibold tracking-wide text-[#38BDF8]">
                              SMW AI
                            </span>
                            <span className="text-[10px] text-slate-500">· {msg.timestamp}</span>
                          </div>
                        )}
                        <p className="break-words">{msg.text}</p>
                        {msg.pendingConfirmation && (
                          <button
                            type="button"
                            onClick={() => void handleSendCommand(msg.pendingConfirmation!.rawCommand, true)}
                            className="mt-2 min-h-[36px] rounded-lg bg-[#1677FF] px-3 py-1 text-xs font-medium text-white hover:bg-[#2585FF]"
                          >
                            Approve &amp; Send
                          </button>
                        )}
                      </div>
                    );
                  })}
                  {orbState === 'THINKING' && (
                    <div className="mr-4 flex items-center gap-2.5 rounded-2xl border border-blue-500/30 bg-[#070E1E]/95 px-3.5 py-2.5 text-xs text-sky-300">
                      <div className="h-5 w-5 animate-pulse overflow-hidden rounded-full ring-1 ring-[#1E88FF]">
                        <SmwEmblem alt="SMW AI" compact className="h-full w-full object-cover object-top" />
                      </div>
                      <span>SMW AI is thinking...</span>
                    </div>
                  )}
                </div>
              )}

              {/* Message Composer */}
              <form
                onSubmit={handleSubmitText}
                className="mt-4 flex items-center gap-2 rounded-full border border-blue-400/20 bg-[#0D1629]/95 p-1.5 shadow-[0_8px_28px_rgba(0,0,0,0.45)]"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  aria-label="Upload image"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#192338] text-slate-200 transition-colors hover:bg-[#23314D]"
                >
                  <ImageIcon className="h-[18px] w-[18px]" />
                </button>

                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Type your message..."
                  className="min-w-0 flex-1 bg-transparent px-1 text-[14px] text-white placeholder:text-slate-400 focus:outline-none"
                />

                <button
                  type="submit"
                  aria-label="Send message"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#1677FF] text-white shadow-[0_0_16px_rgba(22,119,255,0.55)] transition-colors hover:bg-[#2684FF]"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </section>
            {latestReport && (
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800/80 bg-[#071022]/75 px-3.5 py-2 text-[11px] text-slate-300">
                <span className="truncate">
                  <span className={latestReport.succeeded ? 'font-semibold text-emerald-400' : 'font-semibold text-amber-400'}>
                    {latestReport.succeeded ? 'Executed' : 'Pending'}
                  </span>{' '}
                  · {latestReport.identifiedAction}
                </span>
                <span className="font-mono text-sky-400">{latestReport.executionSource}</span>
              </div>
            )}
          </div>
        </main>
        ) : (
        <main className="relative z-10 flex-1 overflow-y-auto px-4 pt-2 pb-6 lg:px-8 lg:py-4">
          {activeTab === 'device' && (
            <DeviceLabPanel
              hardware={hardware}
              accessibilityGranted={isGranted('accessibility')}
              mediaProjectionGranted={isGranted('mediaprojection')}
              cameraGranted={isGranted('camera')}
              micGranted={isGranted('mic')}
              dailyTasks={dailyTasks}
              onUpdateHardware={(patch) => setHardware((prev) => ({ ...prev, ...patch }))}
              onAddDailyTask={(task) =>
                setDailyTasks((prev) => [
                  { ...task, id: `task-${Date.now()}`, createdAt: formatTime() },
                  ...prev,
                ])
              }
              onRunScreenReader={handleRunScreenReader}
              onAnalyzeCapturedImage={handleAnalyzeCapturedImage}
              onGrantPermission={grantPermission}
            />
          )}
          {activeTab === 'automation' && (
            <AutomationPanel
              whatsappMessages={whatsappMessages}
              autoReplyRule={autoReplyRule}
              priorityContacts={memory.priorityContacts}
              templates={memory.templates}
              callConfig={callConfig}
              activeCall={activeCall}
              notificationPermissionGranted={isGranted('notif_listener')}
              callPermissionGranted={isGranted('phone')}
              onUpdateAutoReply={(patch) => setAutoReplyRule((prev) => ({ ...prev, ...patch }))}
              onAddTemplate={(tpl) =>
                setMemory((prev) => ({ ...prev, templates: [tpl, ...prev.templates] }))
              }
              onReplyWhatsApp={handleReplyWhatsApp}
              onSimulateIncomingWhatsApp={handleSimulateIncomingWhatsApp}
              onReadMessageAloud={(txt) => void speakText(txt)}
              onUpdateCallConfig={(patch) => setCallConfig((prev) => ({ ...prev, ...patch }))}
              onSimulateCall={handleSimulateCall}
              onCallAction={handleCallAction}
              onGrantPermission={grantPermission}
            />
          )}
          {activeTab === 'permissions' && (
            <PermissionsPrivacyPanel
              permissions={permissions}
              memory={memory}
              onTogglePermission={togglePermission}
              onUpdateMemory={(patch) => setMemory((prev) => ({ ...prev, ...patch }))}
              onClearMemory={() => {
                setMemory(DEFAULT_MEMORY);
                try {
                  localStorage.removeItem(STORAGE_KEY);
                } catch {
                  // Ignore storage restrictions
                }
              }}
            />
          )}
          {activeTab === 'android' && <AndroidStudioPanel />}
        </main>
        )}

        {/* Footer */}
        <footer className="relative z-10 px-4 pt-1 pb-4 text-center">
          <div className="mx-auto mb-3 h-2 w-[88%] rounded-b-full border-b-2 border-[#1E88FF]/75 shadow-[0_4px_16px_rgba(30,136,255,0.65)]" />
          <div className="flex flex-wrap items-center justify-center gap-3 text-[12px] font-medium text-slate-200">
            <span>
              <span className="font-bold text-white">SMW</span>{' '}
              <span className="font-bold text-[#1E88FF]">AI</span> · v2.0
            </span>
            <a
              href="/app-debug.apk"
              download="app-debug.apk"
              className="inline-flex min-h-[40px] items-center gap-2 rounded-full border border-[#38BDF8]/60 bg-gradient-to-r from-[#1677FF] to-[#0284C7] px-4 py-2 text-xs font-semibold text-white shadow-[0_8px_24px_rgba(22,119,255,0.45)] transition-transform hover:scale-[1.02] hover:brightness-110 active:scale-95"
            >
              <Download className="h-3.5 w-3.5" />
              Download Zariya APK
            </a>
          </div>
        </footer>

        {/* Settings Drawer */}
        {settingsOpen && (
          <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/70 p-4 backdrop-blur-sm sm:items-center">
            <div className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-2xl border border-blue-400/25 bg-[#0A1326] p-5 text-sm text-slate-100 shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="h-7 w-7 overflow-hidden rounded-full ring-1 ring-[#1E88FF]">
                    <SmwEmblem alt="SMW AI" compact className="h-full w-full object-cover object-top" />
                  </div>
                  <h2 className="font-display text-base font-bold text-white">
                    SMW <span className="text-[#1E88FF]">AI</span> Settings
                  </h2>
                </div>
                <button
                  type="button"
                  onClick={() => setSettingsOpen(false)}
                  aria-label="Close settings"
                  className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full text-slate-400 hover:bg-slate-800 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-4 space-y-4">
                {/* Google Profile */}
                <div className="rounded-xl border border-slate-800 bg-[#050A15] p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium text-slate-400">Google Profile</span>
                    {authProfile && (
                      <button
                        type="button"
                        onClick={() => void handleGoogleLogout()}
                        className="text-xs font-medium text-rose-400 hover:text-rose-300"
                      >
                        Sign Out
                      </button>
                    )}
                  </div>
                  {authProfile ? (
                    <div className="mt-2.5 flex items-center justify-between gap-3">
                      <div className="flex min-w-0 items-center gap-2.5">
                        {authProfile.photoURL ? (
                          <img
                            src={authProfile.photoURL}
                            alt={authProfile.displayName || 'User'}
                            referrerPolicy="no-referrer"
                            className="h-9 w-9 shrink-0 rounded-full border border-blue-400/40 object-cover"
                          />
                        ) : (
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#1677FF] text-xs font-bold text-white">
                            {(greetingName || 'U').charAt(0).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="truncate text-xs font-semibold text-white">
                            {authProfile.displayName || greetingName}
                          </p>
                          <p className="truncate text-[11px] text-slate-400">
                            {authProfile.email}
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        disabled={isLoggingIn}
                        onClick={() => void handleGoogleLogin()}
                        className="shrink-0 rounded-lg border border-slate-700 px-2.5 py-1 text-[11px] font-medium text-slate-200 hover:border-blue-400"
                      >
                        Switch
                      </button>
                    </div>
                  ) : (
                    <div className="mt-2.5 flex flex-col items-start gap-2">
                      <p className="text-xs text-slate-300">
                        Sign in with Google so the assistant greets you by name.
                      </p>
                      <button
                        type="button"
                        disabled={isLoggingIn}
                        onClick={() => void handleGoogleLogin()}
                        className="gsi-material-button"
                      >
                        <span className="gsi-material-button-contents">
                          {isLoggingIn ? 'Signing in...' : 'Sign in with Google'}
                        </span>
                      </button>
                    </div>
                  )}
                  {authError && (
                    <p className="mt-2 text-[11px] text-rose-400">{authError}</p>
                  )}
                </div>

                {/* Battery Status */}
                <div className="rounded-xl border border-slate-800 bg-[#050A15] p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {hardware.batteryCharging ? (
                        <BatteryCharging className="h-4 w-4 text-emerald-400" />
                      ) : (
                        <Battery className="h-4 w-4 text-[#38BDF8]" />
                      )}
                      <span className="text-xs font-medium text-slate-300">Battery Status</span>
                    </div>
                    <span className="text-xs font-medium text-slate-300">
                      {hardware.batteryPercent === null
                        ? 'Unavailable'
                        : hardware.batteryCharging
                          ? 'Charging'
                          : 'On Battery'}
                    </span>
                  </div>
                  <div className="mt-2.5 flex items-center justify-between gap-3">
                    <div className="grid flex-1 grid-cols-5 gap-1">
                      {[20, 40, 60, 80, 100].map((threshold) => {
                        const activeCell =
                          hardware.batteryPercent !== null &&
                          hardware.batteryPercent >= threshold - 15;
                        return (
                          <span
                            key={threshold}
                            className={`h-2 rounded-full transition-colors ${
                              activeCell
                                ? hardware.batteryCharging
                                  ? 'bg-emerald-400'
                                  : (hardware.batteryPercent ?? 0) <= 20
                                    ? 'bg-rose-500'
                                    : 'bg-[#1E88FF]'
                                : 'bg-slate-800'
                            }`}
                          />
                        );
                      })}
                    </div>
                    <span className="min-w-[42px] text-right font-mono text-xs font-semibold tabular-nums text-white">
                      {hardware.batteryPercent !== null ? `${hardware.batteryPercent}%` : '--'}
                    </span>
                  </div>
                </div>

                {/* Voice Persona */}
                <div>
                  <label className="block text-xs font-medium text-slate-400">Voice Persona</label>
                  <div className="mt-1.5 grid grid-cols-2 gap-2">
                    {(
                      [
                        { id: 'punjabi_legend', label: 'Punjabi Legend' },
                        { id: 'standard', label: 'Standard' },
                      ] as const
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() =>
                          setMemory((m) => ({
                            ...m,
                            voicePersona: opt.id,
                            voiceGender: opt.id === 'punjabi_legend' ? 'MALE' : m.voiceGender,
                          }))
                        }
                        className={`min-h-[44px] rounded-xl border px-3 py-2 text-xs font-medium ${
                          (memory.voicePersona || 'punjabi_legend') === opt.id
                            ? 'border-[#1E88FF] bg-[#1677FF]/20 text-white'
                            : 'border-slate-800 bg-[#050A15] text-slate-400'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Voice Gender */}
                <div>
                  <label className="block text-xs font-medium text-slate-400">Voice Option</label>
                  <div className="mt-1.5 grid grid-cols-2 gap-2">
                    {(['FEMALE', 'MALE'] as const).map((g) => (
                      <button
                        key={g}
                        type="button"
                        onClick={() =>
                          setMemory((m) => ({
                            ...m,
                            voiceGender: g,
                            voicePersona: g === 'FEMALE' ? 'standard' : m.voicePersona || 'punjabi_legend',
                          }))
                        }
                        className={`min-h-[44px] rounded-xl border px-3 py-2 text-xs font-medium ${
                          memory.voiceGender === g
                            ? 'border-[#1E88FF] bg-[#1677FF]/20 text-white'
                            : 'border-slate-800 bg-[#050A15] text-slate-400'
                        }`}
                      >
                        {g === 'FEMALE' ? 'Female (Fast & Clear)' : 'Male'}
                      </button>
                    ))}
                  </div>
                  <p className="mt-1.5 text-[11px] text-slate-400">
                    Wake words: Hey Siri · Hey AI · Hello AI · Faizan AI · Okay AI
                  </p>
                </div>

                {/* Language */}
                <div>
                  <label className="block text-xs font-medium text-slate-400">Language</label>
                  <select
                    value={memory.preferredLanguage}
                    onChange={(e) =>
                      setMemory((m) => ({
                        ...m,
                        preferredLanguage: e.target.value as AssistantMemory['preferredLanguage'],
                      }))
                    }
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-800 bg-[#050A15] px-3 py-2 text-xs text-white focus:border-[#1E88FF] focus:outline-none"
                  >
                    <option value="auto">Auto (Punjabi · Urdu · Hindi · English)</option>
                    <option value="pa-IN">Punjabi</option>
                    <option value="ur-PK">Urdu</option>
                    <option value="hi-IN">Hindi</option>
                    <option value="en-US">English</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-300">Hands-Free Continuous Listening</span>
                  <button
                    type="button"
                    onClick={() => handleToggleHandsFree(!handsFreeMode)}
                    className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium ${
                      handsFreeMode ? 'bg-[#1677FF] text-white' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {handsFreeMode ? 'On' : 'Off'}
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-300">Microphone Permission</span>
                  <button
                    type="button"
                    onClick={() => togglePermission('mic')}
                    className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium ${
                      isGranted('mic')
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {isGranted('mic') ? 'Allowed' : 'Denied'}
                  </button>
                </div>

                {messages.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setMessages([]);
                      setSettingsOpen(false);
                    }}
                    className="min-h-[44px] w-full rounded-xl border border-slate-700 bg-[#050A15] py-2 text-xs font-medium text-slate-200 hover:border-slate-500"
                  >
                    Clear Conversation
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    interruptSpeech();
                    if (orbState === 'LISTENING') stopVoiceRecognition();
                    setMessages([]);
                    setDailyTasks([]);
                    setWhatsappMessages([]);
                    setLatestReport(null);
                    setMemory(DEFAULT_MEMORY);
                    try {
                      localStorage.removeItem(STORAGE_KEY);
                    } catch {
                      // Ignore storage restrictions
                    }
                    if (authProfile) {
                      void handleGoogleLogout();
                    }
                    setSettingsOpen(false);
                  }}
                  className="min-h-[44px] w-full rounded-xl border border-rose-500/40 bg-rose-950/30 py-2 text-xs font-medium text-rose-200 hover:border-rose-400/70 hover:bg-rose-950/50"
                >
                  Delete Local Data &amp; Sign Out
                </button>
              </div>
            </div>
          </div>
        )}

        <AvatarVoiceMode
          open={avatarModeOpen}
          onClose={() => {
            setAvatarModeOpen(false);
            if (orbState === 'LISTENING') {
              setHandsFreeMode(false);
              stopVoiceRecognition();
            }
          }}
          orbState={orbState}
          handsFreeMode={handsFreeMode}
          onToggleHandsFree={handleToggleHandsFree}
          onMicPress={handleMicPress}
          onSendMessage={(msg) => void handleSendCommand(msg)}
          partialTranscript={partialTranscript}
          messages={messages}
          speechLevelRef={speechLevelRef}
          greetingName={greetingName}
        />
      </div>
    </div>
  );
}
