package com.zariya.assistant.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.zariya.assistant.data.model.AssistantLanguage
import com.zariya.assistant.data.model.AutoReplyRule
import com.zariya.assistant.data.model.CallAssistantConfig
import com.zariya.assistant.data.model.DailyTaskItem
import com.zariya.assistant.data.model.VoiceGender
import com.zariya.assistant.data.model.VoicePersona
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class EncryptedMemoryStore(context: Context) {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private val prefs: SharedPreferences = run {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "zariya_encrypted_memory",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    var assistantName: String
        get() = prefs.getString(KEY_ASSISTANT_NAME, "FAIZAN AI") ?: "FAIZAN AI"
        set(value) = prefs.edit().putString(KEY_ASSISTANT_NAME, value.trim().ifEmpty { "FAIZAN AI" }).apply()

    var wakePhrase: String
        get() = prefs.getString(KEY_WAKE_PHRASE, "Faizan AI") ?: "Faizan AI"
        set(value) = prefs.edit().putString(KEY_WAKE_PHRASE, value.trim().ifEmpty { "Faizan AI" }).apply()

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean(KEY_WAKE_WORD_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_WAKE_WORD_ENABLED, value).apply()

    var voiceGender: VoiceGender
        get() = runCatching {
            VoiceGender.valueOf(prefs.getString(KEY_VOICE_GENDER, VoiceGender.FEMALE.name)!!)
        }.getOrDefault(VoiceGender.FEMALE)
        set(value) = prefs.edit().putString(KEY_VOICE_GENDER, value.name).apply()

    var voicePersona: VoicePersona
        get() = runCatching {
            VoicePersona.valueOf(prefs.getString(KEY_VOICE_PERSONA, VoicePersona.STANDARD.name)!!)
        }.getOrDefault(VoicePersona.STANDARD)
        set(value) = prefs.edit().putString(KEY_VOICE_PERSONA, value.name).apply()

    var preferredLanguage: AssistantLanguage
        get() = runCatching {
            AssistantLanguage.valueOf(prefs.getString(KEY_LANGUAGE, AssistantLanguage.AUTO.name)!!)
        }.getOrDefault(AssistantLanguage.AUTO)
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value.name).apply()

    var readWhatsAppAloud: Boolean
        get() = prefs.getBoolean(KEY_READ_WHATSAPP_ALOUD, true)
        set(value) = prefs.edit().putBoolean(KEY_READ_WHATSAPP_ALOUD, value).apply()

    var screenReadingFeatureEnabled: Boolean
        get() = prefs.getBoolean(KEY_SCREEN_READING_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SCREEN_READING_ENABLED, value).apply()

    var callAssistantFeatureEnabled: Boolean
        get() = prefs.getBoolean(KEY_CALL_ASSISTANT_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_CALL_ASSISTANT_ENABLED, value).apply()

    var recordMicWithScreen: Boolean
        get() = prefs.getBoolean(KEY_RECORD_MIC_WITH_SCREEN, false)
        set(value) = prefs.edit().putBoolean(KEY_RECORD_MIC_WITH_SCREEN, value).apply()

    var recordingFolderUri: String?
        get() = prefs.getString(KEY_RECORDING_URI, null)
        set(value) = prefs.edit().putString(KEY_RECORDING_URI, value).apply()

    var priorityContacts: Set<String>
        get() = prefs.getStringSet(KEY_PRIORITY_CONTACTS, setOf("Ali", "Ammi", "Office Manager")) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_PRIORITY_CONTACTS, value).apply()

    var customTemplates: List<String>
        get() {
            val raw = prefs.getString(KEY_CUSTOM_TEMPLATES, null)
            return if (raw != null) {
                runCatching { json.decodeFromString<List<String>>(raw) }.getOrDefault(defaultTemplates())
            } else {
                defaultTemplates()
            }
        }
        set(value) = prefs.edit().putString(KEY_CUSTOM_TEMPLATES, json.encodeToString(value)).apply()

    var autoReplyRule: AutoReplyRule
        get() {
            val raw = prefs.getString(KEY_AUTO_REPLY_RULE, null) ?: return AutoReplyRule()
            return runCatching { json.decodeFromString<AutoReplyRule>(raw) }.getOrDefault(AutoReplyRule())
        }
        set(value) = prefs.edit().putString(KEY_AUTO_REPLY_RULE, json.encodeToString(value)).apply()

    var callAssistantConfig: CallAssistantConfig
        get() {
            val raw = prefs.getString(KEY_CALL_CONFIG, null) ?: return CallAssistantConfig()
            return runCatching { json.decodeFromString<CallAssistantConfig>(raw) }.getOrDefault(CallAssistantConfig())
        }
        set(value) = prefs.edit().putString(KEY_CALL_CONFIG, json.encodeToString(value)).apply()

    var dailyTasks: List<DailyTaskItem>
        get() {
            val raw = prefs.getString(KEY_DAILY_TASKS, null) ?: return emptyList()
            return runCatching { json.decodeFromString<List<DailyTaskItem>>(raw) }.getOrDefault(emptyList())
        }
        set(value) = prefs.edit().putString(KEY_DAILY_TASKS, json.encodeToString(value)).apply()

    fun addDailyTask(item: DailyTaskItem) {
        dailyTasks = listOf(item) + dailyTasks
    }

    fun clearAllMemory() {
        prefs.edit().clear().apply()
    }

    private fun defaultTemplates(): List<String> = listOf(
        "Assalamualaikum, main abhi kaam kar raha hoon. Main baad mein aapse baat karta hoon.",
        "Main abhi busy hoon, aapka message mil gaya hai. Main free hote hi reply karunga.",
        "Main abhi available nahi hoon. Zaroori baat ho to message chhor dein."
    )

    companion object {
        private const val KEY_ASSISTANT_NAME = "assistant_name"
        private const val KEY_WAKE_PHRASE = "wake_phrase"
        private const val KEY_WAKE_WORD_ENABLED = "wake_word_enabled"
        private const val KEY_VOICE_GENDER = "voice_gender"
        private const val KEY_VOICE_PERSONA = "voice_persona"
        private const val KEY_LANGUAGE = "preferred_language"
        private const val KEY_READ_WHATSAPP_ALOUD = "read_whatsapp_aloud"
        private const val KEY_SCREEN_READING_ENABLED = "screen_reading_enabled"
        private const val KEY_CALL_ASSISTANT_ENABLED = "call_assistant_enabled"
        private const val KEY_RECORD_MIC_WITH_SCREEN = "record_mic_with_screen"
        private const val KEY_RECORDING_URI = "recording_folder_uri"
        private const val KEY_PRIORITY_CONTACTS = "priority_contacts"
        private const val KEY_CUSTOM_TEMPLATES = "custom_templates"
        private const val KEY_AUTO_REPLY_RULE = "auto_reply_rule"
        private const val KEY_CALL_CONFIG = "call_config"
        private const val KEY_DAILY_TASKS = "daily_tasks"
    }
}
