package com.zariya.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zariya.assistant.R
import com.zariya.assistant.ui.ZariyaViewModel
import com.zariya.assistant.ui.theme.ElectricBlue
import com.zariya.assistant.ui.theme.HairlineBorder
import com.zariya.assistant.ui.theme.ObsidianBlack
import com.zariya.assistant.ui.theme.ObsidianElevated
import com.zariya.assistant.ui.theme.ObsidianSurface
import com.zariya.assistant.ui.theme.SkyCyan
import com.zariya.assistant.ui.theme.StatusError
import com.zariya.assistant.ui.theme.StatusNominal
import com.zariya.assistant.ui.theme.TextMuted
import com.zariya.assistant.ui.theme.TextPrimary

@Composable
fun AssistantChatScreen(viewModel: ZariyaViewModel) {
    val messages by viewModel.messages.collectAsState()
    val hasPendingConfirmation by viewModel.hasPendingConfirmation.collectAsState()
    var inputText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.faizan_female_avatar),
                    contentDescription = "FAIZAN AI Avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, ElectricBlue, CircleShape)
                )
                Column {
                    Text(
                        text = "${viewModel.memory.assistantName} Chat",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Urdu · Roman Urdu · Hindi · English",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
            if (messages.isNotEmpty()) {
                TextButton(onClick = { viewModel.clearConversation() }) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Clear Chat",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear", color = TextMuted, fontSize = 12.sp)
                }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = if (isUser) ObsidianElevated else ObsidianSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, if (isUser) ElectricBlue.copy(alpha = 0.45f) else HairlineBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!isUser) {
                                Image(
                                    painter = painterResource(id = R.drawable.faizan_female_avatar),
                                    contentDescription = "FAIZAN AI Profile",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, ElectricBlue, CircleShape)
                                )
                            }
                            Text(
                                text = if (isUser) "You" else viewModel.memory.assistantName,
                                color = if (isUser) SkyCyan else ElectricBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = msg.text, color = TextPrimary, fontSize = 14.sp)
                        msg.taskReport?.let { rep ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "${if (rep.succeeded) "Completed" else "Blocked"} · ${rep.identifiedAction} · ${rep.requiredPermission}",
                                color = if (rep.succeeded) StatusNominal else StatusError,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        if (hasPendingConfirmation) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.confirmPendingAction() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Approve & Send", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = { viewModel.cancelPendingAction() },
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, HairlineBorder),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Cancel", color = TextPrimary, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Command ya sawal likhein...", color = TextMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = HairlineBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )
            IconButton(onClick = { viewModel.toggleListening(handsFree = false) }) {
                Icon(Icons.Default.Mic, contentDescription = "Voice Input", tint = SkyCyan)
            }
            IconButton(onClick = {
                if (inputText.isNotBlank()) {
                    viewModel.sendCommandOrChat(inputText)
                    inputText = ""
                }
            }) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = ElectricBlue)
            }
        }
    }
}
