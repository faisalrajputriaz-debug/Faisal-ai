package com.zariya.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zariya.assistant.R
import com.zariya.assistant.data.model.OrbState
import com.zariya.assistant.ui.ZariyaViewModel
import com.zariya.assistant.ui.components.JarvisOrbCanvas
import com.zariya.assistant.ui.theme.ElectricBlue
import com.zariya.assistant.ui.theme.HairlineBorder
import com.zariya.assistant.ui.theme.ObsidianBlack
import com.zariya.assistant.ui.theme.ObsidianElevated
import com.zariya.assistant.ui.theme.ObsidianSurface
import com.zariya.assistant.ui.theme.SkyCyan
import com.zariya.assistant.ui.theme.StatusError
import com.zariya.assistant.ui.theme.StatusNominal
import com.zariya.assistant.ui.theme.TextMuted
import com.zariya.assistant.ui.theme.TextPrimary
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JarvisLiveScreen(viewModel: ZariyaViewModel) {
    val orbState by viewModel.orbState.collectAsState()
    val rmsLevel by viewModel.voiceEngine.rmsLevel.collectAsState()
    val partialTranscript by viewModel.voiceEngine.partialTranscript.collectAsState()
    val handsFree by viewModel.handsFreeActive.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val voiceOutputEnabled by viewModel.voiceOutputEnabled.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val recentCommands by viewModel.recentCommands.collectAsState()
    val hasPendingConfirmation by viewModel.hasPendingConfirmation.collectAsState()
    val report by viewModel.latestTaskReport.collectAsState()
    var inputText by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        viewModel.refreshBackendStatus()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Status & Branding Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = viewModel.memory.assistantName,
                    color = TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${if (isOnline) "Online" else "Offline (Local Ready)"} · ${
                        if (orbState == OrbState.LISTENING) "Mic Listening" else "Mic Ready"
                    }",
                    color = if (isOnline) StatusNominal else SkyCyan,
                    fontSize = 12.sp
                )
            }
            OutlinedButton(
                onClick = { viewModel.toggleVoiceOutput() },
                border = BorderStroke(1.dp, if (voiceOutputEnabled) ElectricBlue else HairlineBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = if (voiceOutputEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = "Voice Output",
                    tint = if (voiceOutputEnabled) SkyCyan else TextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (voiceOutputEnabled) "Voice On" else "Muted",
                    color = TextPrimary,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Animated Female AI Portrait & Voice Orb Stage
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ObsidianSurface,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.45f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = R.drawable.faizan_female_avatar),
                    contentDescription = "FAIZAN AI Female Assistant",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(116.dp)
                        .clip(CircleShape)
                        .border(2.5.dp, if (orbState == OrbState.IDLE) ElectricBlue else SkyCyan, CircleShape)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when (orbState) {
                        OrbState.IDLE -> "Tap Speak or say: Hey AI · Hello AI · Faizan AI"
                        OrbState.LISTENING -> "Listening (Urdu, Roman Urdu, Hindi, English)"
                        OrbState.THINKING -> "Understanding intent & verifying permissions"
                        OrbState.SPEAKING -> "Speaking — tap orb to interrupt"
                    },
                    color = SkyCyan,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Central Animated Voice Button
                JarvisOrbCanvas(
                    state = orbState,
                    rmsLevel = rmsLevel,
                    onClick = {
                        if (orbState == OrbState.SPEAKING) {
                            viewModel.voiceEngine.interruptSpeech()
                        } else {
                            viewModel.toggleListening(handsFree = false)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 9-bar Live Voice Waveform
                Row(
                    modifier = Modifier.height(26.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val active = orbState == OrbState.LISTENING || orbState == OrbState.SPEAKING
                    for (i in 0 until 9) {
                        val factor = if (active) {
                            max(0.25f, abs(sin((rmsLevel * 6f) + i * 0.7f)))
                        } else {
                            0.18f
                        }
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height((6 + 20 * factor).dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (active) SkyCyan else ElectricBlue.copy(alpha = 0.55f))
                        )
                    }
                }

                if (partialTranscript.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\"$partialTranscript\"",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.toggleListening(handsFree = false) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (orbState == OrbState.LISTENING) "Stop Mic" else "Speak Command")
                    }

                    OutlinedButton(
                        onClick = { viewModel.voiceEngine.interruptSpeech() },
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, HairlineBorder),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Interrupt", color = TextPrimary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Foreground Wake Mode Toggle
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ObsidianSurface,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, HairlineBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Hands-Free Wake Mode", color = TextPrimary, fontWeight = FontWeight.Medium)
                    Text(
                        "Hey Siri · Hey AI · Hello AI · Faizan AI · Okay AI",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = handsFree,
                    onCheckedChange = { viewModel.toggleListening(handsFree = it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Action Shortcuts
        Text(
            text = "Quick Action Shortcuts",
            color = TextMuted,
            fontSize = 12.sp,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))

        val quickCommands = listOf(
            "WhatsApp kholo.",
            "Mujhe latest unread messages parh kar sunao.",
            "Turn on the flashlight",
            "Battery kitni hai?",
            "Meri screen par kya likha hai?",
            "Set alarm for 7:00 AM"
        )
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickCommands.forEach { cmd ->
                OutlinedButton(
                    onClick = { viewModel.sendCommandOrChat(cmd) },
                    border = BorderStroke(1.dp, HairlineBorder),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(cmd, color = TextPrimary, fontSize = 12.sp)
                }
            }
        }

        if (recentCommands.isNotEmpty()) {
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Recent Commands",
                color = TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                recentCommands.forEach { cmd ->
                    OutlinedButton(
                        onClick = { viewModel.sendCommandOrChat(cmd) },
                        border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(cmd, color = SkyCyan, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Live Conversation Preview + Clear Chat + Confirmation Buttons
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = ObsidianSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, HairlineBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Live Conversation", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    if (messages.isNotEmpty()) {
                        TextButton(onClick = { viewModel.clearConversation() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear Chat", tint = TextMuted, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Clear Chat", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }

                if (messages.isEmpty()) {
                    Text(
                        text = "No messages yet. Speak or type a command below.",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                } else {
                    messages.takeLast(4).forEach { msg ->
                        val isUser = msg.role == "user"
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = if (isUser) ObsidianElevated else ObsidianBlack,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (isUser) ElectricBlue.copy(alpha = 0.4f) else HairlineBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = if (isUser) "You" else viewModel.memory.assistantName,
                                    color = if (isUser) SkyCyan else ElectricBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = msg.text, color = TextPrimary, fontSize = 13.sp)
                            }
                        }
                    }
                }

                if (hasPendingConfirmation) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.confirmPendingAction() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Approve & Send", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = { viewModel.cancelPendingAction() },
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(1.dp, HairlineBorder),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Cancel", color = TextPrimary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chat Input Box + Send Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Command ya sawal likhein...", color = TextMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = HairlineBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )
            IconButton(onClick = { viewModel.toggleListening(handsFree = false) }) {
                Icon(Icons.Default.Mic, contentDescription = "Voice Input", tint = SkyCyan)
            }
            IconButton(onClick = {
                if (inputText.isNotBlank()) {
                    viewModel.sendCommandOrChat(inputText)
                    inputText = ""
                }
            }) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = ElectricBlue)
            }
        }

        report?.let { task ->
            Spacer(modifier = Modifier.height(14.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = ObsidianSurface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, HairlineBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (task.succeeded) "Task Succeeded" else "Task Incomplete",
                        color = if (task.succeeded) StatusNominal else StatusError,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Text("Action: ${task.identifiedAction} · ${task.executionSource}", color = SkyCyan, fontSize = 12.sp)
                    Text("Result: ${task.actionPerformed}", color = TextPrimary, fontSize = 12.sp)
                    task.failureReason?.let { reason ->
                        Text("Detail: $reason", color = StatusError, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
