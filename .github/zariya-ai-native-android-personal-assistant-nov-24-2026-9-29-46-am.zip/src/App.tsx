import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Battery,
  BatteryCharging,
  BookOpen,
  Download,
  Flashlight,
  Image as ImageIcon,
  MessageSquareText,
  Mic,
  MicOff,
  Radio,
  Send,
  Settings,
  Sparkles,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import AvatarVoiceMode from './components/AvatarVoiceMode';
import { AndroidStudioPanel } from './components/AndroidStudioPanel';
import { AutomationPanel } from './components/AutomationPanel';
import { DeviceLabPanel } from './components/DeviceLabPanel';
import { PermissionsPrivacyPanel } from './components/PermissionsPrivacyPanel';
import { SmwEmblem } from './components/SmwEmblem';
import FEMALE_AVATAR_ASSET from './assets/images/female_ai_avatar_1795494130654.jpg';
import PUNJABI_AVATAR_ASSET from './assets/images/punjabi_artist_avatar_1795406543964.jpg';
import {
  AssistantMemory,
  AutoReplyRule,
  CallConfig,
  CallSession,
  ChatEntry,
  DailyTask,
  DeviceHardwareState,
  OrbState,
  PermissionRecord,
  TaskExecutionReport,
  WhatsAppMessage,
} from './types/assistant';
import {
  isLikelyDeviceAction,
  parseLocalCommand,
  resolveKnownContacts,
  stripWakePrefix,
} from './utils/localCommandParser';
import {
  AuthenticatedProfile,
  getGreetingFirstName,
  googleSignIn,
  initAuth,
  logout,
} from './lib/googleAuth';

const INITIAL_PERMISSIONS: PermissionRecord[] = [
  {
    id: 'mic',
    title: 'Microphone (RECORD_AUDIO)',
    androidPermission: 'android.permission.RECORD_AUDIO',
    category: 'Runtime',
    reason: 'Captures voice commands only when you tap Speak or enable Hands-Free Live Mode.',
    granted: true,
  },
  {
    id: 'accessibility',
    title: 'Accessibility Service (Screen Reader & Control)',
    androidPermission: 'android.permission.BIND_ACCESSIBILITY_SERVICE',
    category: 'Special System Access',
    reason: 'Reads visible non-protected text, summarizes screens, scrolls, and clicks supported elements.',
    granted: true,
  },
  {
    id: 'notif_listener',
    title: 'Notification Listener (WhatsApp Reader & Reply)',
    androidPermission: 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE',
    category: 'Special System Access',
    reason: 'Reads authorized WhatsApp notifications and executes RemoteInput replies.',
    granted: true,
  },
  {
    id: 'mediaprojection',
    title: 'Screen Capture (MediaProjection)',
    androidPermission: 'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION',
    category: 'Special System Access',
    reason: 'Records the screen or captures a frame for AI analysis only after explicit consent.',
    granted: true,
  },
  {
    id: 'phone',
    title: 'Phone State & Answer Calls',
    androidPermission: 'android.permission.ANSWER_PHONE_CALLS',
    category: 'Runtime',
    reason: 'Enables voice-controlled call answering, rejecting, and ending via TelecomManager.',
    granted: true,
  },
  {
    id: 'camera',
    title: 'Camera & Flashlight',
    androidPermission: 'android.permission.CAMERA',
    category: 'Runtime',
    reason: 'Toggles the hardware torch via CameraManager and opens Camera.',
    granted: true,
  },
];

const DEFAULT_MEMORY: AssistantMemory = {
  assistantName: 'FAIZAN AI',
  wakePhrase: 'Faizan AI',
  wakeWordRequired: false,
  voiceGender: 'FEMALE',
  voicePersona: 'standard',
  preferredLanguage: 'auto',
  priorityContacts: ['Ali', 'Ammi', 'Office Manager'],
  templates: [
    'Assalamualaikum, main abhi kaam kar raha hoon. Main baad mein aapse baat karta hoon.',
    'Main abhi busy hoon, aapka message mil gaya hai. Main free hote hi reply karunga.',
    'Main abhi available nahi hoon. Zaroori baat ho to message chhor dein.',
  ],
  readWhatsAppAloud: true,
  recordMicWithScreen: false,
};

const STORAGE_KEY = 'faizan_ai_memory_v1';

const QUICK_PROMPTS = [
  'WhatsApp kholo.',
  'Mujhe latest unread messages parh kar sunao.',
  'Ali ko message karo ke main busy hoon.',
  'Meri screen par kya likha hai?',
];

function formatTime(): string {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

async function safeFetchJson<T = Record<string, unknown>>(
  url: string,
  init: RequestInit,
  timeoutMs = 25000,
): Promise<{ ok: boolean; status: number; data: T & { error?: string } }> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    const rawText = await res.text();
    let parsed: unknown = {};
    if (rawText) {
      try {
        parsed = JSON.parse(rawText);
      } catch {
        parsed = { error: res.ok ? 'Invalid response format from server.' : `Server error (${res.status}).` };
      }
    }
    const data =
      parsed && typeof parsed === 'object' ? (parsed as T & { error?: string }) : ({} as T & { error?: string });
    return { ok: res.ok, status: res.status, data };
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Request timed out. Please check your connection and try again.');
    }
    throw err;
  } finally {
    window.clearTimeout(timer);
  }
}

type WorkspaceTab = 'assistant' | 'device' | 'automation' | 'permissions' | 'android';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('assistant');
  const [orbState, setOrbState] = useState<OrbState>('IDLE');
  const [handsFreeMode, setHandsFreeMode] = useState(false);
  const [avatarModeOpen, setAvatarModeOpen] = useState(false);
  const [partialTranscript, setPartialTranscript] = useState('');
  const [input, setInput] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [backendOnline, setBackendOnline] = useState<boolean | null>(null);
  const [voiceOutputEnabled, setVoiceOutputEnabled] = useState(true);
  const [recentCommands, setRecentCommands] = useState<string[]>([]);
  const [inlineAvatarImgError, setInlineAvatarImgError] = useState(false);
  const [inlineBlinking, setInlineBlinking] = useState(false);
  const [authProfile, setAuthProfile] = useState<AuthenticatedProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [splashVisible, setSplashVisible] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [memory, setMemory] = useState<AssistantMemory>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return DEFAULT_MEMORY;
      const parsed = JSON.parse(saved) as Partial<AssistantMemory> | null;
      if (!parsed || typeof parsed !== 'object') return DEFAULT_MEMORY;
      const rawName = typeof parsed.assistantName === 'string' ? parsed.assistantName.trim() : '';
      const migratedName =
        rawName && rawName.toUpperCase() !== 'SMW AI' ? rawName : 'FAIZAN AI';
      const migratedGender = parsed.voiceGender || 'FEMALE';
      const migratedPersona =
        parsed.voicePersona || (migratedGender === 'FEMALE' ? 'standard' : 'punjabi_legend');
      return {
        ...DEFAULT_MEMORY,
        ...parsed,
        assistantName: migratedName,
        voiceGender: migratedGender,
        voicePersona: migratedPersona,
      };
    } catch {
      return DEFAULT_MEMORY;
    }
  });

  const [permissions, setPermissions] = useState<PermissionRecord[]>(INITIAL_PERMISSIONS);
  const [latestReport, setLatestReport] = useState<TaskExecutionReport | null>(null);
  const [messages, setMessages] = useState<ChatEntry[]>([]);

  const [hardware, setHardware] = useState<DeviceHardwareState>({
    flashlightOn: false,
    volumePercent: 65,
    mediaPlaying: false,
    mediaTrack: 'Ambient Focus Mix',
    screenScrollIndex: 0,
    activeScreenKey: 'whatsapp',
    batteryPercent: null,
    batteryCharging: false,
  });

  const [dailyTasks, setDailyTasks] = useState<DailyTask[]>([
    {
      id: 't-1',
      type: 'reminder',
      title: 'Send Q4 presentation deck to Ali',
      detail: '4:00 PM today',
      createdAt: formatTime(),
    },
  ]);

  const [whatsappMessages, setWhatsappMessages] = useState<WhatsAppMessage[]>([
    {
      id: 'wa-1',
      appSource: 'WhatsApp',
      sender: 'Ali',
      text: 'Salam bhai, client presentation 4 PM ko confirm hui hai. Urgent deck bhej dein.',
      timestamp: formatTime(),
      isUrgent: true,
      urgencyReason: 'Time-sensitive client presentation request.',
      aiDraftReply: 'Walaikum Assalam Ali, deck 15 minutes mein bhej raha hoon.',
      autoReplied: false,
    },
  ]);

  const [autoReplyRule, setAutoReplyRule] = useState<AutoReplyRule>({
    enabled: false,
    audience: 'SELECTED_CONTACTS_ONLY',
    activeTemplate: DEFAULT_MEMORY.templates[0],
    scheduleEnabled: false,
    startHour: 9,
    endHour: 18,
    cooldownMinutes: 30,
    askBeforeUnconfigured: true,
  });

  const [callConfig, setCallConfig] = useState<CallConfig>({
    enabled: true,
    announceCallerAloud: true,
    autoAnswerSelectedContacts: false,
    handsFreeMode: false,
    speakerphoneActive: false,
    busyNotice:
      'Hello, I am the owner’s AI assistant. The owner is currently busy and will contact you later.',
  });

  const [activeCall, setActiveCall] = useState<CallSession | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioUrlRef = useRef<string | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const speechRafRef = useRef<number | null>(null);
  const speechLevelRef = useRef<number>(0);
  const recognitionRef = useRef<unknown>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const inlineAvatarLayerRef = useRef<HTMLDivElement | null>(null);
  const inlineAuraRef = useRef<HTMLDivElement | null>(null);
  const inlineWaveBarRefs = useRef<Array<HTMLSpanElement | null>>([]);

  useEffect(() => {
    let active = true;
    const checkHealth = async () => {
      try {
        const res = await fetch('/api/health', { cache: 'no-store' });
        if (active) setBackendOnline(res.ok);
      } catch {
        if (active) setBackendOnline(false);
      }
    };
    void checkHealth();
    const interval = window.setInterval(() => void checkHealth(), 30000);
    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, orbState]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(memory));
    } catch {
      // Ignore storage restrictions
    }
  }, [memory]);

  useEffect(() => {
    const unsubscribe = initAuth(
      (profile) => {
        setAuthProfile(profile);
        setAuthError(null);
        setAuthLoading(false);
      },
      () => {
        setAuthProfile(null);
        setAuthLoading(false);
      },
    );
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => setSplashVisible(false), 650);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    interface BatteryManagerLike extends EventTarget {
      level: number;
      charging: boolean;
    }
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<BatteryManagerLike>;
    };
    if (typeof nav.getBattery !== 'function') return;

    let batteryRef: BatteryManagerLike | null = null;
    let active = true;

    const syncBattery = () => {
      if (!active || !batteryRef) return;
      setHardware((prev) => ({
        ...prev,
        batteryPercent: Math.round(batteryRef!.level * 100),
        batteryCharging: Boolean(batteryRef!.charging),
      }));
    };

    nav
      .getBattery()
      .then((battery) => {
        if (!active) return;
        batteryRef = battery;
        syncBattery();
        battery.addEventListener('levelchange', syncBattery);
        battery.addEventListener('chargingchange', syncBattery);
      })
      .catch(() => {
        // Battery Status API unavailable
      });

    return () => {
      active = false;
      if (batteryRef) {
        batteryRef.removeEventListener('levelchange', syncBattery);
        batteryRef.removeEventListener('chargingchange', syncBattery);
      }
    };
  }, []);

  const handleGoogleLogin = useCallback(async () => {
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      const profile = await googleSignIn();
      setAuthProfile(profile);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Unable to complete Google Sign-In.';
      setAuthError(message);
    } finally {
      setIsLoggingIn(false);
    }
  }, []);

  const handleGoogleLogout = useCallback(async () => {
    setAuthError(null);
    await logout();
    setAuthProfile(null);
  }, []);

  const greetingName = getGreetingFirstName(authProfile);

  const isGranted = useCallback(
    (id: string) => permissions.find((p) => p.id === id)?.granted ?? false,
    [permissions],
  );

  const stopSpeechMeter = useCallback(() => {
    if (speechRafRef.current !== null) {
      window.cancelAnimationFrame(speechRafRef.current);
      speechRafRef.current = null;
    }
    speechLevelRef.current = 0;
  }, []);

  const ensureAudioContext = useCallback((): AudioContext | null => {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;
    if (!audioContextRef.current) {
      audioContextRef.current = new AudioCtx();
    }
    if (audioContextRef.current.state === 'suspended') {
      void audioContextRef.current.resume().catch(() => {});
    }
    return audioContextRef.current;
  }, []);

  const interruptSpeech = useCallback(() => {
    stopSpeechMeter();
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setOrbState((prev) => (prev === 'SPEAKING' ? 'IDLE' : prev));
  }, [stopSpeechMeter]);

  useEffect(() => {
    return () => {
      stopSpeechMeter();
      if (audioUrlRef.current) {
        URL.revokeObjectURL(audioUrlRef.current);
        audioUrlRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        void audioContextRef.current.close().catch(() => {});
      }
    };
  }, [stopSpeechMeter]);

  const speakText = useCallback(
    async (text: string) => {
      if (!text.trim() || !voiceOutputEnabled) return;
      interruptSpeech();
      setOrbState('SPEAKING');
      const activePersona = memory.voicePersona || 'standard';
      const isLegend = activePersona === 'punjabi_legend' && memory.voiceGender !== 'FEMALE';

      try {
        const { ok, data } = await safeFetchJson<{ audioBase64?: string; mimeType?: string }>(
          '/api/ai/tts',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              text,
              gender: memory.voiceGender,
              persona: activePersona,
              language: memory.preferredLanguage,
            }),
          },
          22000,
        );
        if (ok && data.audioBase64) {
          const binary = window.atob(data.audioBase64);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
          }
          const wavBlob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
          const objectUrl = URL.createObjectURL(wavBlob);
          audioUrlRef.current = objectUrl;

          const audio = new Audio(objectUrl);
          audioRef.current = audio;

          const cleanupAudio = () => {
            stopSpeechMeter();
            if (audioUrlRef.current === objectUrl) {
              URL.revokeObjectURL(objectUrl);
              audioUrlRef.current = null;
            }
            if (audioRef.current === audio) {
              audioRef.current = null;
            }
            setOrbState('IDLE');
          };

          audio.onended = cleanupAudio;
          audio.onerror = cleanupAudio;

          const ctx = ensureAudioContext();
          if (ctx) {
            try {
              const source = ctx.createMediaElementSource(audio);
              const analyser = ctx.createAnalyser();
              analyser.fftSize = 256;

              if (isLegend) {
                // Deep, bass-rich vocal mastering chain for Punjabi Legend presence
                const bassShelf = ctx.createBiquadFilter();
                bassShelf.type = 'lowshelf';
                bassShelf.frequency.value = 135;
                bassShelf.gain.value = 4.2;

                const grainPresence = ctx.createBiquadFilter();
                grainPresence.type = 'peaking';
                grainPresence.frequency.value = 2600;
                grainPresence.Q.value = 1.1;
                grainPresence.gain.value = 1.6;

                const compressor = ctx.createDynamicsCompressor();
                compressor.threshold.value = -18;
                compressor.knee.value = 12;
                compressor.ratio.value = 3.2;
                compressor.attack.value = 0.008;
                compressor.release.value = 0.16;

                source.connect(bassShelf);
                bassShelf.connect(grainPresence);
                grainPresence.connect(compressor);
                compressor.connect(analyser);
              } else {
                source.connect(analyser);
              }
              analyser.connect(ctx.destination);
              analyserRef.current = analyser;

              const dataArray = new Uint8Array(analyser.frequencyBinCount);
              const tickMeter = () => {
                if (!audioRef.current || audioRef.current.paused || audioRef.current.ended) {
                  speechLevelRef.current = 0;
                  return;
                }
                analyser.getByteTimeDomainData(dataArray);
                let sumSq = 0;
                for (let i = 0; i < dataArray.length; i++) {
                  const normalized = (dataArray[i] - 128) / 128;
                  sumSq += normalized * normalized;
                }
                const rms = Math.sqrt(sumSq / dataArray.length);
                speechLevelRef.current = Math.min(1, Math.max(0, rms * 3.8));
                speechRafRef.current = window.requestAnimationFrame(tickMeter);
              };
              speechRafRef.current = window.requestAnimationFrame(tickMeter);
            } catch {
              const start = performance.now();
              const tickEnvelope = (now: number) => {
                if (!audioRef.current || audioRef.current.paused || audioRef.current.ended) {
                  speechLevelRef.current = 0;
                  return;
                }
                const elapsed = (now - start) * 0.001;
                speechLevelRef.current = 0.25 + 0.45 * Math.abs(Math.sin(elapsed * 11));
                speechRafRef.current = window.requestAnimationFrame(tickEnvelope);
              };
              speechRafRef.current = window.requestAnimationFrame(tickEnvelope);
            }
          }

          await audio.play();
          return;
        }
      } catch {
        // Fallback to browser SpeechSynthesis below
      }

      if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(text);
        const voices = window.speechSynthesis.getVoices();
        const preferLang =
          memory.preferredLanguage !== 'auto'
            ? memory.preferredLanguage
            : /[\u0A00-\u0A7F]/.test(text)
              ? 'pa-IN'
              : /[\u0600-\u06FF]/.test(text)
                ? 'ur-PK'
                : /[\u0900-\u097F]/.test(text)
                  ? 'hi-IN'
                  : 'en-IN';
        utter.lang = preferLang;

        if (voices.length > 0) {
          const wantMale = isLegend || memory.voiceGender === 'MALE';
          const scored = voices
            .map((v) => {
              let score = 0;
              const name = v.name.toLowerCase();
              const lang = v.lang.toLowerCase();
              if (lang.startsWith(preferLang.slice(0, 2).toLowerCase())) score += 4;
              if (lang.includes('-in') || lang.includes('-pk')) score += 2;
              if (wantMale && /(male|rishi|prabhat|madhur|david|daniel|alex|google.*uk.*male|guy)/i.test(name)) {
                score += 5;
              }
              if (!wantMale && /(female|lekha|swara|heera|samantha|zira|google.*female)/i.test(name)) {
                score += 5;
              }
              return { v, score };
            })
            .sort((a, b) => b.score - a.score);
          if (scored[0] && scored[0].score > 0) {
            utter.voice = scored[0].v;
          }
        }

        utter.pitch = isLegend ? 0.72 : memory.voiceGender === 'FEMALE' ? 1.1 : 0.88;
        utter.rate = isLegend ? 0.92 : memory.voiceGender === 'FEMALE' ? 1.12 : 1.02;

        let pulseBoost = 0.65;
        const start = performance.now();
        const tickSynth = (now: number) => {
          if (!window.speechSynthesis.speaking) {
            speechLevelRef.current = 0;
            speechRafRef.current = null;
            return;
          }
          const t = (now - start) * 0.001;
          pulseBoost = Math.max(0.22, pulseBoost * 0.93);
          speechLevelRef.current = Math.min(
            1,
            pulseBoost * (0.55 + 0.45 * Math.abs(Math.sin(t * 13.5))),
          );
          speechRafRef.current = window.requestAnimationFrame(tickSynth);
        };

        utter.onboundary = () => {
          pulseBoost = 0.88;
        };
        utter.onstart = () => {
          speechRafRef.current = window.requestAnimationFrame(tickSynth);
        };
        utter.onend = () => {
          stopSpeechMeter();
          setOrbState('IDLE');
        };
        utter.onerror = () => {
          stopSpeechMeter();
          setOrbState('IDLE');
        };
        window.speechSynthesis.speak(utter);
      } else {
        stopSpeechMeter();
        setOrbState('IDLE');
      }
    },
    [
      ensureAudioContext,
      interruptSpeech,
      memory.preferredLanguage,
      memory.voiceGender,
      memory.voicePersona,
      stopSpeechMeter,
      voiceOutputEnabled,
    ],
  );

  const executeParsedCommand = useCallback(
    (
      rawCommand: string,
      parsed: {
        intent: string;
        targetApp?: string;
        queryOrText?: string;
        targetContact?: string;
        requiredPermission: string;
        needsConfirmation: boolean;
        confirmationPrompt?: string;
        spokenReply: string;
      },
      confirmed: boolean,
      executionSource: 'Local Native Engine' | 'Gemini AI',
    ): { reply: string; report: TaskExecutionReport; pendingConfirm?: boolean } => {
      const intent = (parsed.intent || 'CONVERSATION').toUpperCase();
      const knownContacts = Array.from(
        new Set([
          ...memory.priorityContacts,
          ...whatsappMessages.map((m) => m.sender),
        ]),
      );

      let resolvedContact = parsed.targetContact?.trim() || '';
      if (
        resolvedContact &&
        ['REPLY_WHATSAPP', 'SEND_WHATSAPP_VOICE', 'CALL_CONTACT', 'SEND_SMS'].includes(intent)
      ) {
        const contactCheck = resolveKnownContacts(resolvedContact, knownContacts);
        if (contactCheck.status === 'ambiguous') {
          const clarifyMsg = `Multiple contacts match "${resolvedContact}": ${contactCheck.matches.join(', ')}. Please specify the exact contact name before I proceed.`;
          return {
            reply: clarifyMsg,
            report: {
              userRequest: rawCommand,
              identifiedAction: `${intent} (Ambiguous Contact)`,
              requiredPermission: parsed.requiredPermission || 'Contacts',
              actionPerformed: 'Blocked ambiguous contact selection',
              succeeded: false,
              failureReason: clarifyMsg,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }
        if (contactCheck.status === 'unique') {
          resolvedContact = contactCheck.matches[0];
        }
      }

      const highRiskIntent = [
        'REPLY_WHATSAPP',
        'AUTO_REPLY_RULE',
        'REJECT_CALL',
        'END_CALL',
        'TELL_CALLER_BUSY',
        'CALL_CONTACT',
        'SEND_SMS',
        'SEND_WHATSAPP_VOICE',
        'SHARE_FILE',
      ].includes(intent);

      if ((parsed.needsConfirmation || highRiskIntent) && !confirmed) {
        return {
          reply:
            parsed.confirmationPrompt ||
            parsed.spokenReply ||
            `Confirm executing ${intent.toLowerCase().replace(/_/g, ' ')}?`,
          pendingConfirm: true,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: parsed.requiredPermission,
            actionPerformed: 'Waiting for explicit user approval',
            succeeded: false,
            failureReason: 'Confirmation required before executing external or irreversible action.',
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (
        [
          'READ_SCREEN',
          'EXPLAIN_SCREEN',
          'SCROLL_DOWN',
          'SCROLL_UP',
          'NAVIGATE_BACK',
          'NAVIGATE_HOME',
          'CLOSE_APP',
          'CLICK_ELEMENT',
          'TYPE_TEXT',
        ].includes(intent) &&
        !isGranted('accessibility')
      ) {
        const msg =
          'Accessibility Service is disabled. Please enable it in Settings before I can read or control the screen.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'AccessibilityService',
            actionPerformed: 'Verified AccessibilityService permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (
        [
          'READ_WHATSAPP',
          'SHOW_WHATSAPP_MESSAGES',
          'OPEN_CONTACT_MESSAGE',
          'READ_CONTACT_MESSAGE',
          'READ_NOTIFICATIONS',
          'REPLY_WHATSAPP',
          'SEND_WHATSAPP_VOICE',
          'AUTO_REPLY_RULE',
        ].includes(intent) &&
        !isGranted('notif_listener')
      ) {
        const msg =
          'Notification Listener permission is not allowed. Enable it to read or reply to WhatsApp messages.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'NotificationListenerService',
            actionPerformed: 'Verified Notification Access',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (['FLASHLIGHT_ON', 'FLASHLIGHT_OFF', 'CAPTURE_PHOTO'].includes(intent) && !isGranted('camera')) {
        const msg = 'Camera permission is required to control the flashlight or capture photos.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'CAMERA',
            actionPerformed: 'Checked CAMERA permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (['ANSWER_CALL', 'REJECT_CALL', 'END_CALL', 'CALL_CONTACT'].includes(intent) && !isGranted('phone')) {
        const msg = 'Phone Call permission is disabled. Enable it in Permissions before placing or managing calls.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'ANSWER_PHONE_CALLS',
            actionPerformed: 'Checked Phone Call permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      switch (intent) {
        case 'WAKE_ACK':
          return {
            reply: greetingName
              ? `Haan ${greetingName}, boliye. Main sun rahi hoon.`
              : parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'WAKE_ACK',
              requiredPermission: 'Microphone (RECORD_AUDIO)',
              actionPerformed: 'Activated on wake word',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_APP': {
          const target = (parsed.targetApp || 'WhatsApp').toLowerCase();
          if (target.includes('whatsapp')) {
            setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          } else if (target.includes('setting')) {
            setHardware((h) => ({ ...h, activeScreenKey: 'settings' }));
          } else {
            setHardware((h) => ({ ...h, activeScreenKey: 'article' }));
          }
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: `OPEN_APP (${parsed.targetApp || 'App'})`,
              requiredPermission: 'Launcher Intent',
              actionPerformed: `Opened ${parsed.targetApp || 'target app'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'CLOSE_APP':
        case 'NAVIGATE_HOME':
          setHardware((h) => ({ ...h, screenScrollIndex: 0 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AccessibilityService',
              actionPerformed:
                intent === 'CLOSE_APP'
                  ? `Closed ${parsed.targetApp || 'app'} and returned Home`
                  : 'Navigated to Home screen',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_SETTINGS':
          setHardware((h) => ({ ...h, activeScreenKey: 'settings' }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'OPEN_SETTINGS',
              requiredPermission: 'Android Settings Intent',
              actionPerformed: 'Opened Android Settings',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_CAMERA':
        case 'CAPTURE_PHOTO':
        case 'OPEN_DIALER':
        case 'OPEN_GALLERY':
        case 'OPEN_CONTACTS':
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'Android Intent',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'WEB_SEARCH':
        case 'YOUTUBE_SEARCH':
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'Android Search Intent',
              actionPerformed: `Searched: ${parsed.queryOrText || rawCommand}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'CHECK_BATTERY': {
          const batteryReply =
            hardware.batteryPercent !== null
              ? `Battery level is ${hardware.batteryPercent}%${hardware.batteryCharging ? ' (Charging)' : ''}.`
              : 'Device battery telemetry is managed natively on Android via BatteryManager.';
          return {
            reply: `${parsed.spokenReply} ${batteryReply}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'CHECK_BATTERY',
              requiredPermission: 'BatteryManager',
              actionPerformed: batteryReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'ENABLE_DND':
        case 'DISABLE_DND': {
          const dndOn = intent === 'ENABLE_DND';
          setHardware((h) => ({ ...h, dndEnabled: dndOn }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'ACCESS_NOTIFICATION_POLICY',
              actionPerformed: `Set Do Not Disturb to ${dndOn ? 'ON' : 'OFF'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'READ_SCREEN':
        case 'EXPLAIN_SCREEN': {
          const latestWa = whatsappMessages[0];
          const screenText =
            hardware.activeScreenKey === 'whatsapp' && latestWa
              ? `WhatsApp chat with ${latestWa.sender}: "${latestWa.text}". Buttons visible: Reply, Voice Call, Video Call.`
              : hardware.activeScreenKey === 'settings'
                ? 'Android Settings screen: Bluetooth ready, Digital Assistant set to SMW AI.'
                : 'Chrome article: Android Accessibility and MediaProjection privacy boundaries.';
          return {
            reply: `${parsed.spokenReply} ${screenText}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AccessibilityService',
              actionPerformed: screenText,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SCROLL_DOWN':
          setHardware((h) => ({ ...h, screenScrollIndex: h.screenScrollIndex + 240 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SCROLL_DOWN',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Scrolled down 240px',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'SCROLL_UP':
          setHardware((h) => ({
            ...h,
            screenScrollIndex: Math.max(0, h.screenScrollIndex - 240),
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SCROLL_UP',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Scrolled up 240px',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'NAVIGATE_BACK':
          setHardware((h) => ({ ...h, activeScreenKey: 'settings', screenScrollIndex: 0 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'NAVIGATE_BACK',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Performed Android GLOBAL_ACTION_BACK',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'SHOW_WHATSAPP_MESSAGES': {
          setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          const list = whatsappMessages
            .slice(0, 3)
            .map((m) => `${m.sender}: "${m.text}"`)
            .join(' | ');
          const summary = list || 'No WhatsApp messages in stream.';
          return {
            reply: `${parsed.spokenReply} ${summary}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SHOW_WHATSAPP_MESSAGES',
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'OPEN_CONTACT_MESSAGE':
        case 'READ_CONTACT_MESSAGE': {
          const contactQuery = (resolvedContact || parsed.targetContact || '').toLowerCase();
          const matched = whatsappMessages.find((m) =>
            m.sender.toLowerCase().includes(contactQuery),
          );
          if (intent === 'OPEN_CONTACT_MESSAGE') {
            setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          }
          const summary = matched
            ? matched.repliedText
              ? `${matched.sender}: "${matched.text}". Sent reply: "${matched.repliedText}"`
              : `${matched.sender} ne bheja hai: "${matched.text}"`
            : `${resolvedContact || parsed.targetContact || 'Contact'} ka koi unread WhatsApp message nahi mila.`;
          return {
            reply: summary,
            report: {
              userRequest: rawCommand,
              identifiedAction: `${intent} (${resolvedContact || parsed.targetContact || 'Contact'})`,
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: Boolean(matched),
              failureReason: matched ? undefined : 'No message found for requested contact.',
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'READ_WHATSAPP':
        case 'READ_NOTIFICATIONS': {
          const latest = whatsappMessages[0];
          const summary =
            parsed.queryOrText === 'full' && latest
              ? `${latest.sender} ka poora message: "${latest.text}"`
              : latest
                ? `${latest.sender} sent (${latest.isUrgent ? 'Urgent' : 'Normal'}): "${latest.text}"`
                : 'No unread WhatsApp notifications.';
          return {
            reply: `${parsed.spokenReply} ${summary}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SEND_WHATSAPP_VOICE': {
          const contact = resolvedContact || parsed.targetContact || whatsappMessages[0]?.sender || 'Ali';
          setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          return {
            reply: `${contact} ki WhatsApp chat khol di hai taake aap voice message record karke bhej sakein.`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `SEND_WHATSAPP_VOICE (${contact})`,
              requiredPermission: 'NotificationListenerService + READ_CONTACTS',
              actionPerformed: `Opened WhatsApp chat for ${contact} voice message`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'REPLY_WHATSAPP': {
          const contact = resolvedContact || parsed.targetContact || whatsappMessages[0]?.sender || 'Ali';
          const replyText = parsed.queryOrText || autoReplyRule.activeTemplate;
          setWhatsappMessages((prev) => {
            const exists = prev.some((m) =>
              m.sender.toLowerCase().includes(contact.toLowerCase()),
            );
            if (!exists) {
              return [
                {
                  id: `wa-${Date.now()}`,
                  appSource: 'WhatsApp',
                  sender: contact,
                  text: 'Conversation started via SMW AI',
                  timestamp: formatTime(),
                  isUrgent: false,
                  autoReplied: true,
                  repliedText: replyText,
                },
                ...prev,
              ];
            }
            return prev.map((m) =>
              m.sender.toLowerCase().includes(contact.toLowerCase())
                ? { ...m, autoReplied: true, repliedText: replyText }
                : m,
            );
          });
          return {
            reply: `${contact} ko WhatsApp message bhej diya gaya hai: "${replyText}"`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `REPLY_WHATSAPP (${contact})`,
              requiredPermission: 'NotificationListenerService + RemoteInput',
              actionPerformed: `Sent WhatsApp message to ${contact}: "${replyText}"`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'CALL_CONTACT': {
          const contact = resolvedContact || parsed.targetContact || 'Contact';
          setActiveCall({
            id: `call-out-${Date.now()}`,
            callerName: contact,
            phoneNumber: 'Authorized Contact',
            status: 'ACTIVE',
          });
          return {
            reply: `${contact} ko call milayi ja rahi hai.`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `CALL_CONTACT (${contact})`,
              requiredPermission: 'ANSWER_PHONE_CALLS + Contacts',
              actionPerformed: `Initiated call to ${contact}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SEND_SMS': {
          const contact = resolvedContact || parsed.targetContact || 'Contact';
          const smsText = parsed.queryOrText || 'Please call me back.';
          return {
            reply: `${contact} ko SMS composer mein message tayyar karke bhej diya gaya hai: "${smsText}"`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `SEND_SMS (${contact})`,
              requiredPermission: 'SMS Intent + Contacts',
              actionPerformed: `Prepared SMS to ${contact}: "${smsText}"`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'FLASHLIGHT_ON':
        case 'FLASHLIGHT_OFF': {
          const on = intent === 'FLASHLIGHT_ON';
          setHardware((h) => ({ ...h, flashlightOn: on }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'CAMERA',
              actionPerformed: `Turned flashlight ${on ? 'ON' : 'OFF'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'VOLUME_UP':
        case 'VOLUME_DOWN': {
          const delta = intent === 'VOLUME_UP' ? 15 : -15;
          setHardware((h) => ({
            ...h,
            volumePercent: Math.max(0, Math.min(100, h.volumePercent + delta)),
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AudioManager',
              actionPerformed: `Adjusted volume (${delta > 0 ? '+15%' : '-15%'})`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'MEDIA_PLAY':
        case 'MEDIA_PAUSE':
        case 'MEDIA_NEXT': {
          setHardware((h) => ({
            ...h,
            mediaPlaying: intent !== 'MEDIA_PAUSE',
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AudioManager',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SET_ALARM':
        case 'SET_TIMER':
        case 'ADD_NOTE':
        case 'ADD_REMINDER': {
          const typeMap: Record<string, DailyTask['type']> = {
            SET_ALARM: 'alarm',
            SET_TIMER: 'timer',
            ADD_NOTE: 'note',
            ADD_REMINDER: 'reminder',
          };
          setDailyTasks((prev) => [
            {
              id: `task-${Date.now()}`,
              type: typeMap[intent] || 'note',
              title: parsed.queryOrText || rawCommand,
              detail: 'Created via SMW AI command',
              createdAt: formatTime(),
            },
            ...prev,
          ]);
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'SET_ALARM / Local Store',
              actionPerformed: `Saved ${typeMap[intent] || 'task'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'ANSWER_CALL':
        case 'REJECT_CALL':
        case 'END_CALL':
        case 'SPEAKERPHONE_ON':
        case 'TELL_CALLER_BUSY': {
          if (!activeCall && intent !== 'SPEAKERPHONE_ON') {
            return {
              reply: 'No active incoming call right now.',
              report: {
                userRequest: rawCommand,
                identifiedAction: intent,
                requiredPermission: 'ANSWER_PHONE_CALLS',
                actionPerformed: 'Checked active call state',
                succeeded: false,
                failureReason: 'No active call present.',
                executionSource,
                timestamp: formatTime(),
              },
            };
          }
          if (intent === 'ANSWER_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'ACTIVE' } : null));
          } else if (intent === 'REJECT_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'REJECTED' } : null));
          } else if (intent === 'END_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'ENDED' } : null));
          } else if (intent === 'SPEAKERPHONE_ON') {
            setCallConfig((cfg) => ({ ...cfg, speakerphoneActive: true }));
          } else if (intent === 'TELL_CALLER_BUSY') {
            setActiveCall((c) =>
              c ? { ...c, status: 'BUSY_NOTIFIED', aiDisclosureSent: callConfig.busyNotice } : null,
            );
          }
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'ANSWER_PHONE_CALLS',
              actionPerformed: `Executed ${intent}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        default:
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'None',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
      }
    },
    [
      activeCall,
      autoReplyRule.activeTemplate,
      callConfig.busyNotice,
      greetingName,
      hardware.activeScreenKey,
      hardware.batteryCharging,
      hardware.batteryPercent,
      isGranted,
      memory.priorityContacts,
      whatsappMessages,
    ],
  );

  const handleSendCommand = useCallback(
    async (text: string, confirmed = false) => {
      interruptSpeech();
      const latestPending = [...messages]
        .reverse()
        .find((m) => m.role === 'assistant' && m.pendingConfirmation)?.pendingConfirmation;

      if (!confirmed && latestPending) {
        const cleanLower = text.trim().toLowerCase().replace(/[.!?]+$/, '');
        if (/^(yes|yeah|yep|haan|han|ji|ok|okay|confirm|approved?|bhej\s*do|kar\s*do|send(?:\s*it)?|mila\s*do)$/i.test(cleanLower)) {
          setMessages((prev) => [
            ...prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
            {
              id: `u-${Date.now()}`,
              role: 'user',
              text,
              timestamp: formatTime(),
            },
          ]);
          await handleSendCommand(latestPending.rawCommand, true);
          return;
        }
        if (/^(no|nahi|cancel|abort|stop|mat\s*bhejo|rehne\s*do)$/i.test(cleanLower)) {
          setMessages((prev) => [
            ...prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
            {
              id: `u-${Date.now()}`,
              role: 'user',
              text,
              timestamp: formatTime(),
            },
            {
              id: `a-cancel-${Date.now()}`,
              role: 'assistant',
              text: 'Action cancelled. Kuch bhi nahi bheja gaya.',
              timestamp: formatTime(),
            },
          ]);
          void speakText('Action cancelled.');
          return;
        }
      }

      if (confirmed) {
        setMessages((prev) =>
          prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
        );
      } else {
        setRecentCommands((prev) => [text.trim(), ...prev.filter((c) => c !== text.trim())].slice(0, 6));
        setMessages((prev) => [
          ...prev,
          {
            id: `u-${Date.now()}`,
            role: 'user',
            text,
            timestamp: formatTime(),
          },
        ]);
      }

      const localMatch = parseLocalCommand(text, memory.wakePhrase);
      if (localMatch) {
        const result = executeParsedCommand(text, localMatch, confirmed, 'Local Native Engine');
        setLatestReport(result.report);
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: 'assistant',
            text: result.reply,
            timestamp: formatTime(),
            taskReport: result.report,
            pendingConfirmation: result.pendingConfirm
              ? { rawCommand: text, prompt: result.reply }
              : undefined,
          },
        ]);
        speakText(result.reply);
        return;
      }

      setOrbState('THINKING');
      const wantsDeviceAction = isLikelyDeviceAction(text, memory.wakePhrase);

      if (!wantsDeviceAction) {
        try {
          const { ok, status, data } = await safeFetchJson<{ reply?: string; modelUsed?: string }>(
            '/api/ai/chat',
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                message: text,
                assistantName: memory.assistantName,
                preferredLanguage: memory.preferredLanguage,
                persona: memory.voicePersona || 'punjabi_legend',
                userName: greetingName || '',
                history: messages.slice(-6).map((m) => ({ role: m.role, text: m.text })),
              }),
            },
          );

          if (!ok) {
            throw new Error(data.error || `AI chat server returned status ${status}.`);
          }

          const replyText = data.reply || 'I am ready to help.';
          const chatReport: TaskExecutionReport = {
            userRequest: text,
            identifiedAction: 'CONVERSATIONAL_CHAT',
            requiredPermission: 'None',
            actionPerformed: data.modelUsed
              ? `Conversational reply generated via ${data.modelUsed}`
              : 'Conversational reply generated via Gemini AI',
            succeeded: true,
            executionSource: 'Gemini AI',
            timestamp: formatTime(),
          };
          setLatestReport(chatReport);
          setMessages((prev) => [
            ...prev,
            {
              id: `a-${Date.now()}`,
              role: 'assistant',
              text: replyText,
              timestamp: formatTime(),
              taskReport: chatReport,
            },
          ]);
          speakText(replyText);
        } catch (err) {
          const errMsg = err instanceof Error ? err.message : 'Network error reaching AI chat backend.';
          const failReport: TaskExecutionReport = {
            userRequest: text,
            identifiedAction: 'CONVERSATIONAL_CHAT',
            requiredPermission: 'Server AI API',
            actionPerformed: 'Attempted conversational reply via /api/ai/chat',
            succeeded: false,
            failureReason: errMsg,
            executionSource: 'Gemini AI',
            timestamp: formatTime(),
          };
          setLatestReport(failReport);
          setMessages((prev) => [
            ...prev,
            {
              id: `err-${Date.now()}`,
              role: 'assistant',
              text: `${errMsg} — Native device commands (Open WhatsApp, Read Screen, Flashlight, Scroll, Calls, Alarms) work locally without Gemini.`,
              timestamp: formatTime(),
              taskReport: failReport,
            },
          ]);
          setOrbState('IDLE');
        }
        return;
      }

      try {
        const { ok, status, data } = await safeFetchJson<{
          intent: string;
          targetApp?: string;
          queryOrText?: string;
          targetContact?: string;
          requiredPermission: string;
          needsConfirmation: boolean;
          confirmationPrompt?: string;
          spokenReply: string;
        }>('/api/ai/command', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text,
            assistantName: memory.assistantName,
            preferredLanguage: memory.preferredLanguage,
            persona: memory.voicePersona || 'punjabi_legend',
            screenSummary: `Active screen: ${hardware.activeScreenKey}`,
            unreadNotificationsCount: whatsappMessages.length,
          }),
        });

        if (!ok) {
          throw new Error(data.error || `AI server returned status ${status}.`);
        }

        const result = executeParsedCommand(text, data, confirmed, 'Gemini AI');
        setLatestReport(result.report);
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: 'assistant',
            text: result.reply,
            timestamp: formatTime(),
            taskReport: result.report,
            pendingConfirmation: result.pendingConfirm
              ? { rawCommand: text, prompt: result.reply }
              : undefined,
          },
        ]);
        speakText(result.reply);
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : 'Network error reaching AI backend.';
        const failReport: TaskExecutionReport = {
          userRequest: text,
          identifiedAction: 'AI_COMMAND_PARSE',
          requiredPermission: 'Server AI API',
          actionPerformed: 'Attempted device-action parsing via Gemini AI',
          succeeded: false,
          failureReason: errMsg,
          executionSource: 'Gemini AI',
          timestamp: formatTime(),
        };
        setLatestReport(failReport);
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            role: 'assistant',
            text: `${errMsg} — Native device commands (Open WhatsApp, Read Screen, Flashlight, Scroll, Calls, Alarms) work locally without Gemini.`,
            timestamp: formatTime(),
            taskReport: failReport,
          },
        ]);
        setOrbState('IDLE');
      }
    },
    [
      executeParsedCommand,
      greetingName,
      hardware.activeScreenKey,
      interruptSpeech,
      memory.assistantName,
      memory.preferredLanguage,
      memory.voicePersona,
      memory.wakePhrase,
      messages,
      speakText,
      whatsappMessages.length,
    ],
  );

  const startVoiceRecognition = useCallback(
    (continuous: boolean) => {
      if (!isGranted('mic')) {
        setMessages((prev) => [
          ...prev,
          {
            id: `mic-err-${Date.now()}`,
            role: 'assistant',
            text: 'Microphone permission is currently denied. Allow it in Settings to use voice commands.',
            timestamp: formatTime(),
          },
        ]);
        return;
      }

      const SpeechRec =
        (window as unknown as { SpeechRecognition?: new () => unknown; webkitSpeechRecognition?: new () => unknown })
          .SpeechRecognition ||
        (window as unknown as { webkitSpeechRecognition?: new () => unknown })
          .webkitSpeechRecognition;

      if (!SpeechRec) {
        setMessages((prev) => [
          ...prev,
          {
            id: `sr-na-${Date.now()}`,
            role: 'assistant',
            text: 'Browser SpeechRecognition is not supported in this browser tab. Use the text message input.',
            timestamp: formatTime(),
          },
        ]);
        return;
      }

      interruptSpeech();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const rec = new (SpeechRec as any)();
      rec.continuous = continuous;
      rec.interimResults = true;
      rec.lang =
        memory.preferredLanguage === 'pa-IN'
          ? 'pa-IN'
          : memory.preferredLanguage === 'hi-IN'
            ? 'hi-IN'
            : memory.preferredLanguage === 'ur-PK'
              ? 'ur-PK'
              : memory.preferredLanguage === 'en-US'
                ? 'en-US'
                : 'en-IN';

      rec.onstart = () => setOrbState('LISTENING');
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      rec.onresult = (event: any) => {
        const last = event.results[event.results.length - 1];
        const transcript = last[0]?.transcript?.trim() || '';
        setPartialTranscript(transcript);
        if (last.isFinal && transcript) {
          setPartialTranscript('');
          if (memory.wakeWordRequired && continuous) {
            const { wakeWord } = stripWakePrefix(transcript, memory.wakePhrase);
            if (!wakeWord) return;
          }
          if (!continuous) {
            rec.stop();
          }
          void handleSendCommand(transcript);
        }
      };
      rec.onerror = () => {
        setOrbState('IDLE');
        setPartialTranscript('');
      };
      rec.onend = () => {
        setOrbState((curr) => (curr === 'LISTENING' ? 'IDLE' : curr));
        setPartialTranscript('');
      };

      recognitionRef.current = rec;
      rec.start();
    },
    [
      handleSendCommand,
      interruptSpeech,
      isGranted,
      memory.preferredLanguage,
      memory.wakePhrase,
      memory.wakeWordRequired,
    ],
  );

  const stopVoiceRecognition = useCallback(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const rec = recognitionRef.current as any;
    if (rec) {
      rec.stop();
      recognitionRef.current = null;
    }
    setOrbState('IDLE');
    setPartialTranscript('');
  }, []);

  const handleToggleListen = () => {
    if (orbState === 'LISTENING') {
      setHandsFreeMode(false);
      stopVoiceRecognition();
    } else {
      startVoiceRecognition(false);
    }
  };

  const handleToggleHandsFree = (enabled: boolean) => {
    setHandsFreeMode(enabled);
    if (enabled) {
      startVoiceRecognition(true);
    } else {
      stopVoiceRecognition();
    }
  };

  const togglePermission = (id: string) => {
    setPermissions((prev) =>
      prev.map((p) => (p.id === id ? { ...p, granted: !p.granted } : p)),
    );
  };

  const grantPermission = (id: string) => {
    setPermissions((prev) =>
      prev.map((p) => (p.id === id ? { ...p, granted: true } : p)),
    );
  };

  const handleSubmitText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const text = input.trim();
    setInput('');
    void handleSendCommand(text);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const allowedImageTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];
    if (!allowedImageTypes.includes(file.type.toLowerCase()) || file.size > 4 * 1024 * 1024) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-img-val-${Date.now()}`,
          role: 'assistant',
          text: 'Only PNG, JPEG, WebP, or GIF images up to 4 MB are allowed.',
          timestamp: formatTime(),
        },
      ]);
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!dataUrl) return;
      setMessages((prev) => [
        ...prev,
        {
          id: `u-img-${Date.now()}`,
          role: 'user',
          text: `Uploaded image: ${file.name}`,
          timestamp: formatTime(),
        },
      ]);
      setOrbState('THINKING');
      try {
        const { ok, data } = await safeFetchJson<{ summary?: string }>(
          '/api/ai/analyze-screen',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: dataUrl,
              mimeType: file.type || 'image/jpeg',
              prompt: 'Describe and analyze this image concisely.',
            }),
          },
          30000,
        );
        if (!ok) throw new Error(data.error || 'Image analysis failed.');
        const summary = data.summary || 'Analysis completed.';
        setMessages((prev) => [
          ...prev,
          {
            id: `a-img-${Date.now()}`,
            role: 'assistant',
            text: summary,
            timestamp: formatTime(),
          },
        ]);
        speakText(summary);
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unable to analyze image.';
        setMessages((prev) => [
          ...prev,
          {
            id: `err-img-${Date.now()}`,
            role: 'assistant',
            text: msg,
            timestamp: formatTime(),
          },
        ]);
        setOrbState('IDLE');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleMicPress = () => {
    ensureAudioContext();
    if (orbState === 'SPEAKING') {
      interruptSpeech();
      return;
    }
    if (!isGranted('mic')) {
      grantPermission('mic');
    }
    handleToggleListen();
  };

  const handleToggleVoiceOutput = useCallback(() => {
    setVoiceOutputEnabled((prev) => {
      const next = !prev;
      if (!next) {
        interruptSpeech();
      }
      return next;
    });
  }, [interruptSpeech]);

  const handleClearChat = useCallback(() => {
    interruptSpeech();
    setMessages([]);
    setLatestReport(null);
  }, [interruptSpeech]);

  const handleCancelConfirmation = useCallback(() => {
    setMessages((prev) => [
      ...prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
      {
        id: `a-cancel-btn-${Date.now()}`,
        role: 'assistant',
        text: 'Action cancelled. Kuch bhi nahi bheja gaya.',
        timestamp: formatTime(),
      },
    ]);
    void speakText('Action cancelled.');
  }, [speakText]);

  const handleOpenAvatarMode = () => {
    ensureAudioContext();
    setAvatarModeOpen(true);
    if (messages.length === 0) {
      const greetText = greetingName
        ? `Assalamualaikum ${greetingName}! Main ${memory.assistantName} hoon. Boliye, main aapki kya madad kar sakti hoon?`
        : `Assalamualaikum! Main ${memory.assistantName} hoon. Boliye, main aapki kya madad kar sakti hoon?`;
      void speakText(greetText);
    }
  };

  const handleSpeakGreeting = () => {
    ensureAudioContext();
    const greetText = greetingName
      ? `Assalamualaikum ${greetingName}! Main ${memory.assistantName} hoon. Boliye, main aapki kya madad kar sakti hoon?`
      : `Assalamualaikum! Main ${memory.assistantName} hoon. Aap Urdu, Roman Urdu, Hindi, ya English mein hukam dein.`;
    void speakText(greetText);
  };

  const handleRunScreenReader = (mode: 'read' | 'explain' | 'click-reply') => {
    const cmd =
      mode === 'read'
        ? 'Read my screen'
        : mode === 'explain'
          ? 'Explain screen'
          : 'Ali ko reply bhej do';
    void handleSendCommand(cmd);
  };

  const handleAnalyzeCapturedImage = async (base64: string) => {
    const { ok, data } = await safeFetchJson<{
      summary?: string;
      elements?: string[];
      suggestedAction?: string;
    }>(
      '/api/ai/analyze-screen',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: 'image/jpeg',
          prompt: 'Summarize what is visible on this captured screen and highlight actionable items.',
        }),
      },
      30000,
    );
    if (!ok) {
      return {
        summary: data.error || 'Unable to analyze captured screen frame.',
        elements: [],
      };
    }
    const summary = data.summary || 'Screen captured and analyzed.';
    void speakText(summary);
    return {
      summary,
      elements: Array.isArray(data.elements) ? data.elements : [],
      suggestedAction: data.suggestedAction,
    };
  };

  const handleSimulateIncomingWhatsApp = async (sender: string, text: string) => {
    let isUrgent = false;
    let urgencyReason = '';
    let aiDraftReply = autoReplyRule.activeTemplate;

    try {
      const { ok, data } = await safeFetchJson<{
        isUrgent?: boolean;
        reason?: string;
        suggestedReply?: string;
      }>('/api/ai/whatsapp-reply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sender, message: text }),
      });
      if (ok) {
        isUrgent = Boolean(data.isUrgent);
        urgencyReason = data.reason || '';
        if (data.suggestedReply) aiDraftReply = data.suggestedReply;
      }
    } catch {
      // keep safe defaults
    }

    const newMsg: WhatsAppMessage = {
      id: `wa-${Date.now()}`,
      appSource: 'WhatsApp',
      sender,
      text,
      timestamp: formatTime(),
      isUrgent,
      urgencyReason,
      aiDraftReply,
      autoReplied: autoReplyRule.enabled,
      repliedText: autoReplyRule.enabled ? autoReplyRule.activeTemplate : undefined,
    };
    setWhatsappMessages((prev) => [newMsg, ...prev]);
    if (memory.readWhatsAppAloud) {
      const announceText = `${greetingName || 'Faisal'}, ${sender} ka message aaya hai.`;
      setMessages((prev) => [
        ...prev,
        {
          id: `wa-alert-${Date.now()}`,
          role: 'assistant',
          text: `${announceText} Say "Complete message parho" to hear the full message or reply by voice.`,
          timestamp: formatTime(),
        },
      ]);
      void speakText(announceText);
    }
  };

  const handleReplyWhatsApp = (id: string, replyText: string) => {
    if (!replyText.trim()) return;
    setWhatsappMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, autoReplied: true, repliedText: replyText.trim() } : m)),
    );
    void speakText('WhatsApp reply sent.');
  };

  const handleSimulateCall = (callerName: string | null, phoneNumber: string) => {
    const newCall: CallSession = {
      id: `call-${Date.now()}`,
      callerName,
      phoneNumber,
      status: 'RINGING',
    };
    setActiveCall(newCall);
    if (callConfig.announceCallerAloud) {
      void speakText(`Incoming call from ${callerName || phoneNumber}.`);
    }
  };

  const handleCallAction = (action: 'ANSWER' | 'REJECT' | 'END' | 'SPEAKER' | 'BUSY_NOTICE') => {
    if (action === 'SPEAKER') {
      setCallConfig((c) => ({ ...c, speakerphoneActive: !c.speakerphoneActive }));
      return;
    }
    if (!activeCall) return;
    if (action === 'ANSWER') {
      setActiveCall((c) => (c ? { ...c, status: 'ACTIVE' } : null));
      void speakText('Call answered.');
    } else if (action === 'REJECT') {
      setActiveCall((c) => (c ? { ...c, status: 'REJECTED' } : null));
    } else if (action === 'END') {
      setActiveCall((c) => (c ? { ...c, status: 'ENDED' } : null));
    } else if (action === 'BUSY_NOTICE') {
      setActiveCall((c) =>
        c ? { ...c, status: 'BUSY_NOTIFIED', aiDisclosureSent: callConfig.busyNotice } : null,
      );
      void speakText('AI busy notice sent.');
    }
  };

  useEffect(() => {
    let blinkTimeout: number | undefined;
    let openTimeout: number | undefined;
    const scheduleBlink = () => {
      const delay = 2600 + Math.random() * 2400;
      blinkTimeout = window.setTimeout(() => {
        setInlineBlinking(true);
        openTimeout = window.setTimeout(() => {
          setInlineBlinking(false);
          scheduleBlink();
        }, 125);
      }, delay);
    };
    scheduleBlink();
    return () => {
      if (blinkTimeout) window.clearTimeout(blinkTimeout);
      if (openTimeout) window.clearTimeout(openTimeout);
    };
  }, []);

  useEffect(() => {
    if (activeTab !== 'assistant') return;
    let rafId = 0;
    const startTime = performance.now();
    let smoothed = 0;

    const animateStage = (now: number) => {
      const elapsed = (now - startTime) * 0.001;
      const targetLevel =
        orbState === 'SPEAKING'
          ? Math.max(0.08, speechLevelRef.current)
          : orbState === 'LISTENING'
            ? 0.24 + 0.16 * Math.abs(Math.sin(elapsed * 5.8))
            : orbState === 'THINKING'
              ? 0.14 + 0.08 * Math.sin(elapsed * 4.2)
              : 0;
      smoothed += (targetLevel - smoothed) * 0.24;

      if (inlineAvatarLayerRef.current) {
        const breatheY =
          orbState === 'SPEAKING'
            ? Math.sin(elapsed * 2.4) * -2.2 - smoothed * 1.6
            : Math.sin(elapsed * 1.4) * -1.4;
        const scale = orbState === 'SPEAKING' ? 1 + smoothed * 0.018 : 1;
        inlineAvatarLayerRef.current.style.transform = `translate3d(0, ${breatheY.toFixed(2)}px, 0) scale(${scale.toFixed(4)})`;
      }

      if (inlineAuraRef.current) {
        const auraOpacity =
          orbState === 'IDLE' ? 0.34 : Math.min(0.95, 0.45 + smoothed * 0.55);
        inlineAuraRef.current.style.opacity = auraOpacity.toFixed(3);
      }

      inlineWaveBarRefs.current.forEach((bar, idx) => {
        if (!bar) return;
        const centerDist = Math.abs(idx - 5.5) / 5.5;
        const arch = 1 - centerDist * 0.52;
        const h =
          orbState === 'SPEAKING' || orbState === 'LISTENING'
            ? Math.max(5, Math.min(34, 6 + smoothed * 28 * arch * (0.65 + 0.45 * Math.sin(elapsed * 10 + idx * 0.85))))
            : orbState === 'THINKING'
              ? 7 + 5 * Math.sin(elapsed * 5 + idx * 0.6)
              : 5 + 3 * arch;
        bar.style.height = `${h.toFixed(1)}px`;
        bar.style.opacity =
          orbState === 'SPEAKING' || orbState === 'LISTENING'
            ? '1'
            : orbState === 'THINKING'
              ? '0.78'
              : '0.42';
      });

      rafId = window.requestAnimationFrame(animateStage);
    };

    rafId = window.requestAnimationFrame(animateStage);
    return () => window.cancelAnimationFrame(rafId);
  }, [activeTab, orbState]);

  const isFemalePersona = memory.voiceGender === 'FEMALE' || memory.voicePersona === 'standard';
  const mainAvatarSrc = isFemalePersona ? FEMALE_AVATAR_ASSET : PUNJABI_AVATAR_ASSET;
  const quickActionItems = [
    {
      id: 'whatsapp',
      label: 'WhatsApp Kholo',
      icon: MessageSquareText,
      command: 'WhatsApp kholo.',
    },
    {
      id: 'read-msg',
      label: 'Messages Parho',
      icon: Volume2,
      command: 'Mujhe latest unread messages parh kar sunao.',
    },
    {
      id: 'flashlight',
      label: hardware.flashlightOn ? 'Torch Off' : 'Flashlight On',
      icon: Flashlight,
      command: hardware.flashlightOn ? 'Turn off the flashlight' : 'Turn on the flashlight',
    },
    {
      id: 'battery',
      label: 'Battery Status',
      icon: Battery,
      command: 'Battery kitni hai?',
    },
    {
      id: 'screen',
      label: 'Read Screen',
      icon: BookOpen,
      command: 'Meri screen par kya likha hai?',
    },
    {
      id: 'alarm',
      label: 'Set Alarm 7 AM',
      icon: Settings,
      command: 'Set alarm for 7:00 AM',
    },
  ] as const;

  const micStatusText = !isGranted('mic')
    ? 'Mic Denied'
    : orbState === 'LISTENING'
      ? 'Mic Listening'
      : 'Mic Ready';

  return (
    <div className="min-h-screen w-full bg-[#02050D] text-white lg:flex lg:justify-center lg:px-6 lg:py-4">
      <div className="relative flex min-h-screen w-full flex-col overflow-hidden bg-gradient-to-b from-[#040917] via-[#030713] to-[#02050D] lg:min-h-[calc(100vh-2rem)] lg:max-w-7xl lg:rounded-[30px] lg:border lg:border-blue-500/20 lg:shadow-[0_0_90px_rgba(0,119,255,0.2)]">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[420px] bg-[radial-gradient(circle_at_35%_30%,rgba(14,116,255,0.22),transparent_70%)]" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[200px] bg-[radial-gradient(ellipse_at_50%_100%,rgba(0,140,255,0.24),transparent_72%)]" />

        {/* Tap-to-dismiss Splash Overlay */}
        {splashVisible && (
          <div
            onClick={() => setSplashVisible(false)}
            className="absolute inset-0 z-50 flex cursor-pointer flex-col items-center justify-center bg-[#02050D] px-6 text-center transition-opacity duration-300"
          >
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_42%,rgba(30,136,255,0.28),transparent_65%)]" />
            <div className="relative h-44 w-44 overflow-hidden rounded-3xl border border-[#1E88FF]/60 bg-[#02050D] shadow-[0_0_50px_rgba(30,136,255,0.45)]">
              <img
                src={mainAvatarSrc}
                alt="FAIZAN AI Official Female Assistant"
                className="h-full w-full select-none object-cover object-top"
              />
            </div>
            <h2 className="mt-5 font-display text-2xl font-extrabold italic tracking-wide text-white">
              FAIZAN <span className="text-[#1E88FF]">AI</span>
            </h2>
            <p className="mt-1 text-xs font-medium tracking-wide text-sky-300">
              Android Voice Control &amp; Automation Assistant
            </p>
            <div className="mt-5 h-1 w-28 overflow-hidden rounded-full bg-slate-800">
              <div className="h-full w-1/2 animate-pulse rounded-full bg-gradient-to-r from-[#1677FF] to-[#38BDF8]" />
            </div>
          </div>
        )}

        {/* Strict 3-Zone Header Bar */}
        <header className="relative z-10 flex flex-wrap items-center justify-between gap-3 border-b border-blue-500/15 px-4 pt-3.5 pb-3 lg:flex-nowrap lg:px-8">
          <div className="flex items-center gap-3">
            <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-full bg-[#02050D] ring-2 ring-[#1D8BFF] shadow-[0_0_18px_rgba(29,139,255,0.7)]">
              <img
                src={mainAvatarSrc}
                alt="FAIZAN AI"
                className="pointer-events-none h-full w-full select-none object-cover object-top"
              />
            </div>
            <div className="flex flex-col">
              <h1 className="whitespace-nowrap font-display text-xl font-extrabold italic leading-none tracking-wide text-white sm:text-2xl">
                FAIZAN <span className="text-[#1E88FF]">AI</span>
              </h1>
              <span className="mt-1 whitespace-nowrap text-[11px] font-medium text-slate-300">
                Voice &amp; Android Automation
              </span>
            </div>
          </div>

          <nav
            aria-label="FAIZAN AI Workspaces"
            className="order-3 flex w-full items-center gap-1.5 overflow-x-auto pt-1 lg:order-2 lg:w-auto lg:justify-center lg:pt-0"
          >
            {(
              [
                { id: 'assistant', label: 'Assistant' },
                { id: 'device', label: 'Device Lab' },
                { id: 'automation', label: 'WhatsApp & Calls' },
                { id: 'permissions', label: 'Permissions' },
                { id: 'android', label: 'Android Studio' },
              ] as const
            ).map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`min-h-[40px] shrink-0 whitespace-nowrap rounded-xl border px-3.5 py-1.5 text-xs font-medium transition-colors ${
                    active
                      ? 'border-[#38BDF8]/70 bg-[#1677FF]/25 text-white shadow-[0_0_14px_rgba(30,136,255,0.28)]'
                      : 'border-slate-800/80 bg-[#071022]/75 text-slate-300 hover:border-blue-400/40 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </nav>

          <div className="order-2 flex items-center gap-2.5 lg:order-3">
            {hardware.batteryPercent !== null && (
              <span className="hidden items-center gap-1.5 text-xs font-mono tabular-nums text-slate-300 sm:inline-flex">
                {hardware.batteryCharging ? (
                  <BatteryCharging className="h-4 w-4 text-emerald-400" />
                ) : (
                  <Battery className="h-4 w-4 text-sky-400" />
                )}
                {hardware.batteryPercent}%
              </span>
            )}
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              aria-label="Settings & Permissions"
              className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-full border border-blue-400/25 bg-[#0C152B]/90 text-white shadow-[0_0_14px_rgba(29,139,255,0.2)] transition-colors hover:border-blue-400/60 hover:bg-[#13203F]"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </header>

        {/* Real-Time Status Strip (unboxed telemetry with dot separators) */}
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 border-b border-slate-900/90 px-4 py-2 text-xs lg:px-8">
          <div className="flex flex-wrap items-center gap-2 text-slate-300">
            <span
              className={
                backendOnline === true
                  ? 'font-medium text-emerald-400'
                  : backendOnline === false
                    ? 'font-medium text-amber-400'
                    : 'font-medium text-sky-300'
              }
            >
              {backendOnline === true
                ? 'Assistant Online'
                : backendOnline === false
                  ? 'Offline (Local Commands Active)'
                  : 'Checking Connection'}
            </span>
            <span className="text-slate-600">·</span>
            <span
              className={
                !isGranted('mic')
                  ? 'font-medium text-rose-400'
                  : orbState === 'LISTENING'
                    ? 'font-medium text-[#38BDF8]'
                    : 'text-slate-300'
              }
            >
              {micStatusText}
            </span>
            <span className="hidden text-slate-600 sm:inline">·</span>
            <span className="hidden text-slate-400 sm:inline">
              Wake Words: Hey AI · Hello AI · Hey Siri · Faizan AI · Okay AI
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-400">
              {isFemalePersona ? 'Female AI Voice' : 'Punjabi Legend Voice'}
            </span>
          </div>
        </div>

        {/* Responsive Body */}
        {activeTab === 'assistant' ? (
        <main className="relative z-10 grid flex-1 grid-cols-1 gap-5 px-4 pt-3 pb-4 lg:grid-cols-12 lg:gap-7 lg:px-8 lg:py-5">
          {/* Left Stage: Animated Female AI Avatar + Central Mic Dock + Quick Actions */}
          <div className="flex flex-col gap-4 lg:col-span-5">
            {/* Animated Female AI Avatar Portrait */}
            <section className="relative w-full overflow-hidden rounded-[24px] border border-[#1E88FF]/30 bg-[#02050D] shadow-[0_0_40px_rgba(14,116,255,0.22)]">
              <div
                ref={inlineAuraRef}
                className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(30,136,255,0.34),transparent_72%)] transition-opacity duration-200"
              />
              <div
                ref={inlineAvatarLayerRef}
                className="relative h-[230px] w-full transition-transform duration-150 sm:h-[260px] lg:h-[275px]"
              >
                {!inlineAvatarImgError ? (
                  <img
                    src={mainAvatarSrc}
                    alt={`${memory.assistantName} Animated Avatar`}
                    onError={() => setInlineAvatarImgError(true)}
                    className="pointer-events-none h-full w-full select-none object-cover object-top"
                  />
                ) : (
                  <SmwEmblem
                    alt="FAIZAN AI"
                    className="pointer-events-none h-full w-full select-none object-contain"
                  />
                )}
                {inlineBlinking && !inlineAvatarImgError && (
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-[34%] top-[33%] h-3.5 rounded-full bg-[#1a1822]/65 blur-[2px]"
                  />
                )}
              </div>

              <div
                role={!authProfile && !authLoading ? 'button' : undefined}
                tabIndex={!authProfile && !authLoading ? 0 : undefined}
                onClick={!authProfile && !authLoading ? () => void handleGoogleLogin() : undefined}
                onKeyDown={
                  !authProfile && !authLoading
                    ? (e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          void handleGoogleLogin();
                        }
                      }
                    : undefined
                }
                className={`absolute right-3 top-3 flex max-w-[168px] flex-col rounded-2xl border border-[#1E88FF]/70 bg-[#040C20]/90 px-3 py-2 text-left shadow-[0_0_20px_rgba(30,136,255,0.4)] backdrop-blur-sm ${
                  !authProfile && !authLoading ? 'cursor-pointer hover:border-[#38BDF8]' : ''
                }`}
              >
                <p className="font-display text-xs font-bold leading-tight text-white">
                  {greetingName ? `Salam ${greetingName}` : 'Assalamualaikum'}
                </p>
                <p className="mt-0.5 text-[11px] leading-tight text-sky-200/90">
                  {orbState === 'SPEAKING'
                    ? 'Speaking response...'
                    : orbState === 'LISTENING'
                      ? 'Listening to you...'
                      : 'Ready for your command'}
                </p>
              </div>

              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-gradient-to-t from-[#02050D] via-[#02050D]/80 to-transparent px-3 pt-6 pb-2.5">
                <button
                  type="button"
                  onClick={handleSpeakGreeting}
                  aria-label="Hear voice greeting"
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[#38BDF8]/50 bg-[#040C20]/90 px-3 py-1.5 text-xs font-medium text-sky-200 transition-colors hover:border-[#38BDF8] hover:text-white"
                >
                  <Volume2 className="h-3.5 w-3.5 text-[#38BDF8]" />
                  <span>Voice Greet</span>
                </button>
                <button
                  type="button"
                  onClick={handleOpenAvatarMode}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[#38BDF8]/55 bg-[#0A1E47]/95 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:border-[#38BDF8] hover:bg-[#102B63]"
                >
                  <Sparkles className="h-3.5 w-3.5 text-[#38BDF8]" />
                  <span>Full Avatar Mode</span>
                </button>
              </div>
            </section>

            {/* Central Animated Voice Button + 12-bar Waveform + Voice Controls */}
            <section className="flex flex-col items-center rounded-[22px] border border-blue-400/20 bg-[#071022]/80 px-4 py-4">
              <div className="flex w-full items-center justify-center gap-4">
                <div className="flex h-9 items-center gap-1.5" aria-hidden="true">
                  {[0, 1, 2, 3, 4, 5].map((idx) => (
                    <span
                      key={`wl-${idx}`}
                      ref={(el) => {
                        inlineWaveBarRefs.current[idx] = el;
                      }}
                      className="h-2 w-[3.5px] rounded-full bg-gradient-to-t from-[#0066FF] to-[#38BDF8] transition-[height,opacity] duration-75"
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleMicPress}
                  aria-label={
                    orbState === 'LISTENING'
                      ? 'Stop listening'
                      : orbState === 'SPEAKING'
                        ? 'Stop speaking'
                        : 'Tap to Speak'
                  }
                  className={`relative flex h-[74px] w-[74px] shrink-0 items-center justify-center rounded-full border-2 border-[#38BDF8] bg-gradient-to-b from-[#0C2D6B] to-[#051438] text-white transition-transform active:scale-95 ${
                    orbState === 'LISTENING'
                      ? 'animate-pulse shadow-[0_0_40px_rgba(56,189,248,0.95),inset_0_0_20px_rgba(56,189,248,0.6)]'
                      : orbState === 'SPEAKING'
                        ? 'shadow-[0_0_34px_rgba(30,136,255,0.9),inset_0_0_18px_rgba(56,189,248,0.5)]'
                        : 'shadow-[0_0_26px_rgba(0,149,255,0.75),inset_0_0_14px_rgba(56,189,248,0.35)]'
                  }`}
                >
                  {orbState === 'LISTENING' ? (
                    <MicOff className="h-7 w-7" />
                  ) : (
                    <Mic className="h-7 w-7" />
                  )}
                </button>

                <div className="flex h-9 items-center gap-1.5" aria-hidden="true">
                  {[6, 7, 8, 9, 10, 11].map((idx) => (
                    <span
                      key={`wr-${idx}`}
                      ref={(el) => {
                        inlineWaveBarRefs.current[idx] = el;
                      }}
                      className="h-2 w-[3.5px] rounded-full bg-gradient-to-t from-[#0066FF] to-[#38BDF8] transition-[height,opacity] duration-75"
                    />
                  ))}
                </div>
              </div>

              <p className="mt-2.5 min-h-[20px] text-center text-xs font-medium text-sky-200">
                {orbState === 'LISTENING'
                  ? partialTranscript
                    ? `"${partialTranscript}"`
                    : 'Listening (Urdu · Roman Urdu · Hindi · English)...'
                  : orbState === 'THINKING'
                    ? 'Thinking & checking permissions...'
                    : orbState === 'SPEAKING'
                      ? 'Speaking — tap mic to interrupt'
                      : 'Tap microphone to speak or type below'}
              </p>

              <div className="mt-3 grid w-full grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={handleToggleVoiceOutput}
                  className={`flex min-h-[44px] items-center justify-center gap-2 rounded-xl border px-3 py-2 text-xs font-medium transition-colors ${
                    voiceOutputEnabled
                      ? 'border-[#38BDF8]/60 bg-[#0D2554]/80 text-white'
                      : 'border-slate-700 bg-[#060E20] text-slate-300'
                  }`}
                >
                  {voiceOutputEnabled ? (
                    <Volume2 className="h-4 w-4 text-[#38BDF8]" />
                  ) : (
                    <VolumeX className="h-4 w-4 text-slate-400" />
                  )}
                  <span>{voiceOutputEnabled ? 'Voice On' : 'Voice Muted'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleToggleHandsFree(!handsFreeMode)}
                  className={`flex min-h-[44px] items-center justify-center gap-2 rounded-xl border px-3 py-2 text-xs font-medium transition-colors ${
                    handsFreeMode
                      ? 'border-emerald-400/60 bg-emerald-950/50 text-emerald-200'
                      : 'border-slate-700 bg-[#060E20] text-slate-200 hover:border-[#1E88FF]/50'
                  }`}
                >
                  <Radio className="h-4 w-4" />
                  <span>{handsFreeMode ? 'Wake Active' : 'Hands-Free Wake'}</span>
                </button>
              </div>
            </section>

            {/* Quick Action Shortcuts */}
            <section className="rounded-[22px] border border-blue-400/15 bg-[#071022]/75 p-3.5">
              <h2 className="mb-2.5 text-xs font-semibold tracking-wide text-slate-300">
                Quick Action Shortcuts
              </h2>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-2">
                {quickActionItems.map((action) => {
                  const IconComponent = action.icon;
                  return (
                    <button
                      key={action.id}
                      type="button"
                      onClick={() => void handleSendCommand(action.command)}
                      className="flex min-h-[44px] items-center gap-2 rounded-xl border border-slate-800 bg-[#040B1A] px-3 py-2 text-left text-xs font-medium text-slate-200 transition-colors hover:border-[#1E88FF]/70 hover:text-white"
                    >
                      <IconComponent className="h-4 w-4 shrink-0 text-[#38BDF8]" />
                      <span className="truncate">{action.label}</span>
                    </button>
                  );
                })}
              </div>
            </section>
          </div>

          {/* Right Column: Live Conversation + Recent Commands + Composer */}
          <div className="flex flex-col justify-between gap-3.5 lg:col-span-7">
            <section className="flex flex-1 flex-col justify-between rounded-[24px] border border-blue-400/20 bg-[#0A1326]/90 px-4 py-4 shadow-[0_0_28px_rgba(14,116,255,0.14)] backdrop-blur-md">
              {/* Conversation Header Bar */}
              <div className="mb-3 flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                <div className="flex items-center gap-2">
                  <h2 className="font-display text-sm font-bold text-white">
                    Live Conversation
                  </h2>
                  <span className="font-mono text-xs tabular-nums text-slate-400">
                    · {messages.length}
                  </span>
                </div>
                {messages.length > 0 && (
                  <button
                    type="button"
                    onClick={handleClearChat}
                    className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-700/80 bg-[#050C1B] px-2.5 py-1 text-xs font-medium text-slate-300 transition-colors hover:border-rose-400/60 hover:text-rose-200"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Clear Chat</span>
                  </button>
                )}
              </div>

              {messages.length === 0 ? (
                <div className="flex flex-1 flex-col justify-between gap-4 py-2">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3.5">
                      <div className="h-16 w-16 shrink-0 overflow-hidden rounded-2xl border border-[#1E88FF]/45 bg-[#02050D] shadow-[0_0_16px_rgba(30,136,255,0.28)]">
                        <img
                          src={mainAvatarSrc}
                          alt="FAIZAN AI"
                          className="pointer-events-none h-full w-full select-none object-cover object-top"
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="font-display text-lg font-bold tracking-tight text-white">
                          Welcome to <span className="text-[#1E88FF]">{memory.assistantName}</span>
                        </h3>
                        <p className="mt-1 text-[13px] leading-snug text-slate-300">
                          Say &ldquo;Hey AI&rdquo;, &ldquo;Faizan AI&rdquo;, or tap a voice command below. Supports Urdu, Roman Urdu, Hindi, and English.
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {QUICK_PROMPTS.map((q) => (
                        <button
                          key={q}
                          type="button"
                          onClick={() => void handleSendCommand(q)}
                          className="min-h-[40px] rounded-xl border border-slate-700/75 bg-[#060E20] px-3 py-2 text-left text-xs text-slate-200 transition-colors hover:border-[#1E88FF] hover:text-white"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>

                  {!authLoading && !authProfile && (
                    <div className="flex flex-wrap items-center justify-between gap-2 border-t border-blue-400/15 pt-3">
                      <span className="text-xs text-slate-300">
                        Sign in to personalize voice greetings
                      </span>
                      <button
                        type="button"
                        disabled={isLoggingIn}
                        onClick={() => void handleGoogleLogin()}
                        className="gsi-material-button shrink-0"
                      >
                        <div className="gsi-material-button-state" />
                        <div className="gsi-material-button-content-wrapper">
                          <div className="gsi-material-button-icon">
                            <svg
                              version="1.1"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 48 48"
                              className="block h-full w-full"
                            >
                              <path
                                fill="#EA4335"
                                d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                              />
                              <path
                                fill="#4285F4"
                                d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                              />
                              <path
                                fill="#FBBC05"
                                d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                              />
                              <path
                                fill="#34A853"
                                d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                              />
                              <path fill="none" d="M0 0h48v48H0z" />
                            </svg>
                          </div>
                          <span className="gsi-material-button-contents">
                            {isLoggingIn ? 'Signing in...' : 'Sign in with Google'}
                          </span>
                        </div>
                      </button>
                      {authError && (
                        <p className="w-full text-[11px] text-rose-400">{authError}</p>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div
                  ref={chatScrollRef}
                  className="max-h-[340px] flex-1 space-y-2.5 overflow-y-auto pr-1 lg:max-h-[450px]"
                >
                  {messages.map((msg) => {
                    const isUser = msg.role === 'user';
                    return (
                      <div
                        key={msg.id}
                        className={`rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed ${
                          isUser
                            ? 'ml-6 border border-blue-500/35 bg-[#112040]/90 text-white'
                            : 'mr-4 border border-slate-700/60 bg-[#070E1E]/95 text-slate-100'
                        }`}
                      >
                        {!isUser && (
                          <div className="mb-1.5 flex items-center gap-2">
                            <div className="h-5 w-5 overflow-hidden rounded-full ring-1 ring-[#1E88FF]">
                              <img
                                src={mainAvatarSrc}
                                alt={memory.assistantName}
                                className="h-full w-full object-cover object-top"
                              />
                            </div>
                            <span className="text-[11px] font-semibold tracking-wide text-[#38BDF8]">
                              {memory.assistantName}
                            </span>
                            <span className="text-[10px] text-slate-500">· {msg.timestamp}</span>
                          </div>
                        )}
                        <p className="break-words">{msg.text}</p>
                        {msg.pendingConfirmation && (
                          <div className="mt-2.5 flex flex-wrap items-center gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                void handleSendCommand(msg.pendingConfirmation!.rawCommand, true)
                              }
                              className="min-h-[38px] rounded-xl bg-[#1677FF] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#2585FF]"
                            >
                              Approve &amp; Send
                            </button>
                            <button
                              type="button"
                              onClick={handleCancelConfirmation}
                              className="min-h-[38px] rounded-xl border border-slate-700 bg-[#050C1B] px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:border-slate-500 hover:text-white"
                            >
                              Cancel
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {orbState === 'THINKING' && (
                    <div className="mr-4 flex items-center gap-2.5 rounded-2xl border border-blue-500/30 bg-[#070E1E]/95 px-3.5 py-2.5 text-xs text-sky-300">
                      <div className="h-5 w-5 animate-pulse overflow-hidden rounded-full ring-1 ring-[#1E88FF]">
                        <img
                          src={mainAvatarSrc}
                          alt={memory.assistantName}
                          className="h-full w-full object-cover object-top"
                        />
                      </div>
                      <span>{memory.assistantName} is thinking...</span>
                    </div>
                  )}
                </div>
              )}

              {/* Recent Commands Strip */}
              {recentCommands.length > 0 && (
                <div className="mt-3 border-t border-slate-800/80 pt-2.5">
                  <p className="mb-1.5 text-[11px] font-medium text-slate-400">
                    Recent Commands
                  </p>
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    {recentCommands.map((cmd) => (
                      <button
                        key={cmd}
                        type="button"
                        onClick={() => void handleSendCommand(cmd)}
                        className="min-h-[34px] shrink-0 whitespace-nowrap rounded-lg border border-slate-800 bg-[#050B18] px-2.5 py-1 text-xs text-slate-300 transition-colors hover:border-[#1E88FF]/60 hover:text-white"
                      >
                        {cmd}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Message Composer */}
              <form
                onSubmit={handleSubmitText}
                className="mt-3 flex items-center gap-2 rounded-full border border-blue-400/25 bg-[#0D1629]/95 p-1.5 shadow-[0_8px_28px_rgba(0,0,0,0.45)]"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  aria-label="Upload image"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#192338] text-slate-200 transition-colors hover:bg-[#23314D]"
                >
                  <ImageIcon className="h-[18px] w-[18px]" />
                </button>

                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Command ya sawal likhein (Urdu, Hindi, English)..."
                  className="min-w-0 flex-1 bg-transparent px-1 text-[14px] text-white placeholder:text-slate-400 focus:outline-none"
                />

                <button
                  type="submit"
                  aria-label="Send message"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#1677FF] text-white shadow-[0_0_16px_rgba(22,119,255,0.55)] transition-colors hover:bg-[#2684FF]"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </section>

            {latestReport && (
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800/80 bg-[#071022]/75 px-3.5 py-2 text-xs text-slate-300">
                <span className="truncate">
                  <span
                    className={
                      latestReport.succeeded
                        ? 'font-semibold text-emerald-400'
                        : 'font-semibold text-amber-400'
                    }
                  >
                    {latestReport.succeeded ? 'Executed' : 'Pending'}
                  </span>{' '}
                  · {latestReport.identifiedAction} · {latestReport.actionPerformed}
                </span>
                <span className="font-mono text-sky-400">{latestReport.executionSource}</span>
              </div>
            )}
          </div>
        </main>
        ) : (
        <main className="relative z-10 flex-1 overflow-y-auto px-4 pt-2 pb-6 lg:px-8 lg:py-4">
          {activeTab === 'device' && (
            <DeviceLabPanel
              hardware={hardware}
              accessibilityGranted={isGranted('accessibility')}
              mediaProjectionGranted={isGranted('mediaprojection')}
              cameraGranted={isGranted('camera')}
              micGranted={isGranted('mic')}
              dailyTasks={dailyTasks}
              onUpdateHardware={(patch) => setHardware((prev) => ({ ...prev, ...patch }))}
              onAddDailyTask={(task) =>
                setDailyTasks((prev) => [
                  { ...task, id: `task-${Date.now()}`, createdAt: formatTime() },
                  ...prev,
                ])
              }
              onRunScreenReader={handleRunScreenReader}
              onAnalyzeCapturedImage={handleAnalyzeCapturedImage}
              onGrantPermission={grantPermission}
            />
          )}
          {activeTab === 'automation' && (
            <AutomationPanel
              whatsappMessages={whatsappMessages}
              autoReplyRule={autoReplyRule}
              priorityContacts={memory.priorityContacts}
              templates={memory.templates}
              callConfig={callConfig}
              activeCall={activeCall}
              notificationPermissionGranted={isGranted('notif_listener')}
              callPermissionGranted={isGranted('phone')}
              onUpdateAutoReply={(patch) => setAutoReplyRule((prev) => ({ ...prev, ...patch }))}
              onAddTemplate={(tpl) =>
                setMemory((prev) => ({ ...prev, templates: [tpl, ...prev.templates] }))
              }
              onReplyWhatsApp={handleReplyWhatsApp}
              onSimulateIncomingWhatsApp={handleSimulateIncomingWhatsApp}
              onReadMessageAloud={(txt) => void speakText(txt)}
              onUpdateCallConfig={(patch) => setCallConfig((prev) => ({ ...prev, ...patch }))}
              onSimulateCall={handleSimulateCall}
              onCallAction={handleCallAction}
              onGrantPermission={grantPermission}
            />
          )}
          {activeTab === 'permissions' && (
            <PermissionsPrivacyPanel
              permissions={permissions}
              memory={memory}
              onTogglePermission={togglePermission}
              onUpdateMemory={(patch) => setMemory((prev) => ({ ...prev, ...patch }))}
              onClearMemory={() => {
                setMemory(DEFAULT_MEMORY);
                try {
                  localStorage.removeItem(STORAGE_KEY);
                } catch {
                  // Ignore storage restrictions
                }
              }}
            />
          )}
          {activeTab === 'android' && <AndroidStudioPanel />}
        </main>
        )}

        {/* Footer */}
        <footer className="relative z-10 px-4 pt-1 pb-4 text-center">
          <div className="mx-auto mb-3 h-2 w-[88%] rounded-b-full border-b-2 border-[#1E88FF]/75 shadow-[0_4px_16px_rgba(30,136,255,0.65)]" />
          <div className="flex flex-wrap items-center justify-center gap-3 text-[12px] font-medium text-slate-200">
            <span>
              <span className="font-bold text-white">FAIZAN</span>{' '}
              <span className="font-bold text-[#1E88FF]">AI</span> · Android Voice Assistant
            </span>
            <button
              type="button"
              onClick={() => setActiveTab('android')}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-full border border-[#38BDF8]/60 bg-gradient-to-r from-[#1677FF] to-[#0284C7] px-4 py-2 text-xs font-semibold text-white shadow-[0_8px_24px_rgba(22,119,255,0.45)] transition-transform hover:scale-[1.02] hover:brightness-110 active:scale-95"
            >
              <Download className="h-3.5 w-3.5" />
              Export Android Studio Project
            </button>
          </div>
        </footer>

        {/* Settings Drawer */}
        {settingsOpen && (
          <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/75 p-4 backdrop-blur-sm sm:items-center">
            <div className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-2xl border border-blue-400/25 bg-[#0A1326] p-5 text-sm text-slate-100 shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="h-7 w-7 overflow-hidden rounded-full ring-1 ring-[#1E88FF]">
                    <img
                      src={mainAvatarSrc}
                      alt="FAIZAN AI"
                      className="h-full w-full object-cover object-top"
                    />
                  </div>
                  <h2 className="font-display text-base font-bold text-white">
                    FAIZAN <span className="text-[#1E88FF]">AI</span> Settings
                  </h2>
                </div>
                <button
                  type="button"
                  onClick={() => setSettingsOpen(false)}
                  aria-label="Close settings"
                  className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full text-slate-400 hover:bg-slate-800 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-4 space-y-4">
                {/* Google Profile */}
                <div className="rounded-xl border border-slate-800 bg-[#050A15] p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium text-slate-400">Google Profile</span>
                    {authProfile && (
                      <button
                        type="button"
                        onClick={() => void handleGoogleLogout()}
                        className="text-xs font-medium text-rose-400 hover:text-rose-300"
                      >
                        Sign Out
                      </button>
                    )}
                  </div>
                  {authProfile ? (
                    <div className="mt-2.5 flex items-center justify-between gap-3">
                      <div className="flex min-w-0 items-center gap-2.5">
                        {authProfile.photoURL ? (
                          <img
                            src={authProfile.photoURL}
                            alt={authProfile.displayName || 'User'}
                            referrerPolicy="no-referrer"
                            className="h-9 w-9 shrink-0 rounded-full border border-blue-400/40 object-cover"
                          />
                        ) : (
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#1677FF] text-xs font-bold text-white">
                            {(greetingName || 'U').charAt(0).toUpperCase()}
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="truncate text-xs font-semibold text-white">
                            {authProfile.displayName || greetingName}
                          </p>
                          <p className="truncate text-[11px] text-slate-400">
                            {authProfile.email}
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        disabled={isLoggingIn}
                        onClick={() => void handleGoogleLogin()}
                        className="shrink-0 rounded-lg border border-slate-700 px-2.5 py-1 text-[11px] font-medium text-slate-200 hover:border-blue-400"
                      >
                        Switch
                      </button>
                    </div>
                  ) : (
                    <div className="mt-2.5 flex flex-col items-start gap-2">
                      <p className="text-xs text-slate-300">
                        Sign in with Google so the assistant greets you by name.
                      </p>
                      <button
                        type="button"
                        disabled={isLoggingIn}
                        onClick={() => void handleGoogleLogin()}
                        className="gsi-material-button"
                      >
                        <span className="gsi-material-button-contents">
                          {isLoggingIn ? 'Signing in...' : 'Sign in with Google'}
                        </span>
                      </button>
                    </div>
                  )}
                  {authError && (
                    <p className="mt-2 text-[11px] text-rose-400">{authError}</p>
                  )}
                </div>

                {/* Battery Status */}
                <div className="rounded-xl border border-slate-800 bg-[#050A15] p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {hardware.batteryCharging ? (
                        <BatteryCharging className="h-4 w-4 text-emerald-400" />
                      ) : (
                        <Battery className="h-4 w-4 text-[#38BDF8]" />
                      )}
                      <span className="text-xs font-medium text-slate-300">Battery Status</span>
                    </div>
                    <span className="text-xs font-medium text-slate-300">
                      {hardware.batteryPercent === null
                        ? 'Unavailable'
                        : hardware.batteryCharging
                          ? 'Charging'
                          : 'On Battery'}
                    </span>
                  </div>
                  <div className="mt-2.5 flex items-center justify-between gap-3">
                    <div className="grid flex-1 grid-cols-5 gap-1">
                      {[20, 40, 60, 80, 100].map((threshold) => {
                        const activeCell =
                          hardware.batteryPercent !== null &&
                          hardware.batteryPercent >= threshold - 15;
                        return (
                          <span
                            key={threshold}
                            className={`h-2 rounded-full transition-colors ${
                              activeCell
                                ? hardware.batteryCharging
                                  ? 'bg-emerald-400'
                                  : (hardware.batteryPercent ?? 0) <= 20
                                    ? 'bg-rose-500'
                                    : 'bg-[#1E88FF]'
                                : 'bg-slate-800'
                            }`}
                          />
                        );
                      })}
                    </div>
                    <span className="min-w-[42px] text-right font-mono text-xs font-semibold tabular-nums text-white">
                      {hardware.batteryPercent !== null ? `${hardware.batteryPercent}%` : '--'}
                    </span>
                  </div>
                </div>

                {/* Voice Gender & Style */}
                <div>
                  <label className="block text-xs font-medium text-slate-400">Assistant Voice</label>
                  <div className="mt-1.5 grid grid-cols-2 gap-2">
                    {(['FEMALE', 'MALE'] as const).map((g) => (
                      <button
                        key={g}
                        type="button"
                        onClick={() =>
                          setMemory((m) => ({
                            ...m,
                            voiceGender: g,
                            voicePersona: g === 'FEMALE' ? 'standard' : 'punjabi_legend',
                          }))
                        }
                        className={`min-h-[44px] rounded-xl border px-3 py-2 text-xs font-medium ${
                          memory.voiceGender === g
                            ? 'border-[#1E88FF] bg-[#1677FF]/20 text-white'
                            : 'border-slate-800 bg-[#050A15] text-slate-400'
                        }`}
                      >
                        {g === 'FEMALE' ? 'Female (Fast & Clear)' : 'Male (Punjabi Legend)'}
                      </button>
                    ))}
                  </div>
                  <p className="mt-1.5 text-[11px] text-slate-400">
                    Wake words: Hey Siri · Hey AI · Hello AI · Faizan AI · Okay AI
                  </p>
                </div>

                {/* Language */}
                <div>
                  <label className="block text-xs font-medium text-slate-400">Language</label>
                  <select
                    value={memory.preferredLanguage}
                    onChange={(e) =>
                      setMemory((m) => ({
                        ...m,
                        preferredLanguage: e.target.value as AssistantMemory['preferredLanguage'],
                      }))
                    }
                    className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-800 bg-[#050A15] px-3 py-2 text-xs text-white focus:border-[#1E88FF] focus:outline-none"
                  >
                    <option value="auto">Auto (Urdu · Roman Urdu · Hindi · English · Punjabi)</option>
                    <option value="ur-PK">Urdu</option>
                    <option value="hi-IN">Hindi</option>
                    <option value="en-US">English</option>
                    <option value="pa-IN">Punjabi</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-300">Voice Output (Spoken Replies)</span>
                  <button
                    type="button"
                    onClick={handleToggleVoiceOutput}
                    className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium ${
                      voiceOutputEnabled ? 'bg-[#1677FF] text-white' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {voiceOutputEnabled ? 'On' : 'Muted'}
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-300">Hands-Free Wake Listening</span>
                  <button
                    type="button"
                    onClick={() => handleToggleHandsFree(!handsFreeMode)}
                    className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium ${
                      handsFreeMode ? 'bg-[#1677FF] text-white' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {handsFreeMode ? 'On' : 'Off'}
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-300">Microphone Permission</span>
                  <button
                    type="button"
                    onClick={() => togglePermission('mic')}
                    className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium ${
                      isGranted('mic')
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {isGranted('mic') ? 'Allowed' : 'Denied'}
                  </button>
                </div>

                {messages.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      handleClearChat();
                      setSettingsOpen(false);
                    }}
                    className="min-h-[44px] w-full rounded-xl border border-slate-700 bg-[#050A15] py-2 text-xs font-medium text-slate-200 hover:border-slate-500"
                  >
                    Clear Conversation
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    interruptSpeech();
                    if (orbState === 'LISTENING') stopVoiceRecognition();
                    setMessages([]);
                    setRecentCommands([]);
                    setDailyTasks([]);
                    setWhatsappMessages([]);
                    setLatestReport(null);
                    setMemory(DEFAULT_MEMORY);
                    try {
                      localStorage.removeItem(STORAGE_KEY);
                    } catch {
                      // Ignore storage restrictions
                    }
                    if (authProfile) {
                      void handleGoogleLogout();
                    }
                    setSettingsOpen(false);
                  }}
                  className="min-h-[44px] w-full rounded-xl border border-rose-500/40 bg-rose-950/30 py-2 text-xs font-medium text-rose-200 hover:border-rose-400/70 hover:bg-rose-950/50"
                >
                  Delete Local Data &amp; Sign Out
                </button>
              </div>
            </div>
          </div>
        )}

        <AvatarVoiceMode
          open={avatarModeOpen}
          onClose={() => {
            setAvatarModeOpen(false);
            if (orbState === 'LISTENING') {
              setHandsFreeMode(false);
              stopVoiceRecognition();
            }
          }}
          orbState={orbState}
          handsFreeMode={handsFreeMode}
          voiceOutputEnabled={voiceOutputEnabled}
          onToggleVoiceOutput={handleToggleVoiceOutput}
          onToggleHandsFree={handleToggleHandsFree}
          onMicPress={handleMicPress}
          onSendMessage={(msg) => void handleSendCommand(msg)}
          partialTranscript={partialTranscript}
          messages={messages}
          speechLevelRef={speechLevelRef}
          greetingName={greetingName}
          voiceGender={memory.voiceGender}
          voicePersona={memory.voicePersona}
          assistantName={memory.assistantName}
        />
      </div>
    </div>
  );
}
