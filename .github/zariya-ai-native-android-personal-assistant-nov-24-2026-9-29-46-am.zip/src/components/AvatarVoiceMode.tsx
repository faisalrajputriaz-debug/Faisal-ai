import { MutableRefObject, useEffect, useRef, useState } from 'react';
import { Keyboard, Mic, MicOff, Radio, Send, Volume2, VolumeX, X } from 'lucide-react';
import { ChatEntry, OrbState, VoiceGender, VoicePersona } from '../types/assistant';
import { SmwEmblem } from './SmwEmblem';
import FEMALE_AVATAR_ASSET from '../assets/images/female_ai_avatar_1795494130654.jpg';
import PUNJABI_AVATAR_ASSET from '../assets/images/punjabi_artist_avatar_1795406543964.jpg';

interface AvatarVoiceModeProps {
  open: boolean;
  onClose: () => void;
  orbState: OrbState;
  handsFreeMode: boolean;
  voiceOutputEnabled: boolean;
  onToggleVoiceOutput: () => void;
  onToggleHandsFree: (enabled: boolean) => void;
  onMicPress: () => void;
  onSendMessage: (text: string) => void;
  partialTranscript: string;
  messages: ChatEntry[];
  speechLevelRef: MutableRefObject<number>;
  greetingName: string | null;
  voiceGender?: VoiceGender;
  voicePersona?: VoicePersona;
  assistantName?: string;
}

export default function AvatarVoiceMode({
  open,
  onClose,
  orbState,
  handsFreeMode,
  voiceOutputEnabled,
  onToggleVoiceOutput,
  onToggleHandsFree,
  onMicPress,
  onSendMessage,
  partialTranscript,
  messages,
  speechLevelRef,
  greetingName,
  voiceGender = 'FEMALE',
  voicePersona = 'standard',
  assistantName = 'FAIZAN AI',
}: AvatarVoiceModeProps) {
  const [photoUnavailable, setPhotoUnavailable] = useState(false);
  const [stageView, setStageView] = useState<'avatar' | 'identity'>('avatar');
  const [showTextComposer, setShowTextComposer] = useState(false);
  const [draftText, setDraftText] = useState('');
  const [isBlinking, setIsBlinking] = useState(false);

  const isFemaleMode = voiceGender === 'FEMALE' || voicePersona === 'standard';
  const avatarSrc = isFemaleMode ? FEMALE_AVATAR_ASSET : PUNJABI_AVATAR_ASSET;

  const stageRef = useRef<HTMLDivElement | null>(null);
  const headLayerRef = useRef<HTMLDivElement | null>(null);
  const mouthCavityRef = useRef<HTMLDivElement | null>(null);
  const svgMouthPathRef = useRef<SVGEllipseElement | null>(null);
  const chinMotionRef = useRef<HTMLDivElement | null>(null);
  const auraGlowRef = useRef<HTMLDivElement | null>(null);
  const barRefs = useRef<Array<HTMLSpanElement | null>>([]);

  useEffect(() => {
    setPhotoUnavailable(false);
  }, [avatarSrc]);

  useEffect(() => {
    if (!open) return;
    let blinkTimeout: number | undefined;
    let openTimeout: number | undefined;
    let doubleBlinkTimeout: number | undefined;

    const scheduleNextBlink = () => {
      const delay = 2400 + Math.random() * 2500;
      blinkTimeout = window.setTimeout(() => {
        setIsBlinking(true);
        openTimeout = window.setTimeout(() => {
          setIsBlinking(false);
          if (Math.random() < 0.22) {
            doubleBlinkTimeout = window.setTimeout(() => {
              setIsBlinking(true);
              openTimeout = window.setTimeout(() => {
                setIsBlinking(false);
                scheduleNextBlink();
              }, 110);
            }, 135);
          } else {
            scheduleNextBlink();
          }
        }, 120);
      }, delay);
    };

    scheduleNextBlink();
    return () => {
      if (blinkTimeout) window.clearTimeout(blinkTimeout);
      if (openTimeout) window.clearTimeout(openTimeout);
      if (doubleBlinkTimeout) window.clearTimeout(doubleBlinkTimeout);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    let rafId = 0;
    let smoothedLevel = 0;

    const renderFrame = (now: number) => {
      const t = now * 0.001;
      const targetLevel =
        orbState === 'SPEAKING'
          ? speechLevelRef.current
          : orbState === 'LISTENING'
            ? 0.16 + 0.09 * Math.sin(t * 7.2)
            : 0;

      const coeff = targetLevel > smoothedLevel ? 0.42 : 0.2;
      smoothedLevel += (targetLevel - smoothedLevel) * coeff;

      if (headLayerRef.current) {
        const idleBreathY = Math.sin(t * 1.45) * 2.4;
        const idleSwayDeg = Math.sin(t * 0.85) * 0.42;
        const speakingNodY =
          orbState === 'SPEAKING'
            ? Math.sin(t * 5.2) * (2.0 + smoothedLevel * 5.2)
            : 0;
        const speakingTiltDeg =
          orbState === 'SPEAKING'
            ? Math.sin(t * 2.9) * (0.85 + smoothedLevel * 2.0)
            : orbState === 'LISTENING'
              ? -1.0
              : 0;
        const scale =
          orbState === 'LISTENING'
            ? 1.022
            : orbState === 'SPEAKING'
              ? 1.01 + smoothedLevel * 0.018
              : 1.0 + Math.sin(t * 1.45) * 0.004;

        headLayerRef.current.style.transform = `translate3d(0, ${(idleBreathY + speakingNodY).toFixed(2)}px, 0) rotate(${(idleSwayDeg + speakingTiltDeg).toFixed(2)}deg) scale(${scale.toFixed(4)})`;
      }

      const mouthAmount =
        orbState === 'SPEAKING'
          ? Math.min(1, Math.max(0, smoothedLevel * 1.45))
          : 0;

      if (mouthCavityRef.current) {
        const scaleY = 0.14 + mouthAmount * 1.3;
        const scaleX = 0.82 + mouthAmount * 0.25;
        mouthCavityRef.current.style.opacity =
          orbState === 'SPEAKING' ? (0.18 + mouthAmount * 0.72).toFixed(2) : '0';
        mouthCavityRef.current.style.transform = `scale(${scaleX.toFixed(3)}, ${scaleY.toFixed(3)})`;
      }

      if (svgMouthPathRef.current) {
        const ry = 1.6 + mouthAmount * 7.0;
        const rx = 9 + mouthAmount * 3.0;
        svgMouthPathRef.current.setAttribute('ry', ry.toFixed(2));
        svgMouthPathRef.current.setAttribute('rx', rx.toFixed(2));
      }

      if (chinMotionRef.current) {
        const dropPx = mouthAmount * 4.0;
        chinMotionRef.current.style.transform = `translate3d(0, ${dropPx.toFixed(2)}px, 0)`;
      }

      if (stageRef.current) {
        const gestureX =
          orbState === 'SPEAKING'
            ? Math.sin(t * 2.4) * (1.4 + smoothedLevel * 3.8)
            : Math.sin(t * 0.7) * 0.9;
        const gestureY =
          orbState === 'SPEAKING'
            ? -smoothedLevel * 3.2 + Math.cos(t * 3.4) * 1.4
            : 0;
        stageRef.current.style.transform = `translate3d(${gestureX.toFixed(2)}px, ${gestureY.toFixed(2)}px, 0)`;
      }

      if (auraGlowRef.current) {
        const glowScale = 0.96 + smoothedLevel * 0.18 + Math.sin(t * 1.8) * 0.02;
        const glowOpacity =
          orbState === 'SPEAKING'
            ? 0.45 + smoothedLevel * 0.45
            : orbState === 'LISTENING'
              ? 0.58
              : 0.24;
        auraGlowRef.current.style.transform = `scale(${glowScale.toFixed(3)})`;
        auraGlowRef.current.style.opacity = glowOpacity.toFixed(2);
      }

      for (let i = 0; i < barRefs.current.length; i++) {
        const el = barRefs.current[i];
        if (!el) continue;
        const harmonic = 0.55 + 0.45 * Math.abs(Math.sin(t * 8.5 + i * 0.85));
        const activeAmp =
          orbState === 'SPEAKING'
            ? 0.24 + smoothedLevel * harmonic * 0.95
            : orbState === 'LISTENING'
              ? 0.28 + harmonic * 0.45
              : orbState === 'THINKING'
                ? 0.18 + 0.24 * Math.abs(Math.sin(t * 4.5 + i * 0.5))
                : 0.14;
        el.style.transform = `scaleY(${Math.min(1.15, activeAmp).toFixed(3)})`;
      }

      rafId = window.requestAnimationFrame(renderFrame);
    };

    rafId = window.requestAnimationFrame(renderFrame);
    return () => window.cancelAnimationFrame(rafId);
  }, [open, orbState, speechLevelRef]);

  if (!open) return null;

  const latestReply = [...messages].reverse().find((m) => m.role === 'assistant');
  const latestUser = [...messages].reverse().find((m) => m.role === 'user');

  const handleSubmitDraft = (e: React.FormEvent) => {
    e.preventDefault();
    if (!draftText.trim()) return;
    const text = draftText.trim();
    setDraftText('');
    onSendMessage(text);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Avatar Voice Mode"
      className="fixed inset-0 z-50 flex flex-col overflow-hidden bg-[#02050D] text-white"
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_28%,rgba(29,122,252,0.22),rgba(2,5,13,0.96)_68%)]" />
      <div
        ref={auraGlowRef}
        className="pointer-events-none absolute left-1/2 top-[24%] h-[360px] w-[360px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(29,122,252,0.34),transparent_70%)] blur-2xl"
      />

      <header className="relative z-20 flex items-center justify-between gap-3 px-4 pt-4 pb-2 sm:px-6">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5">
            <h2 className="whitespace-nowrap font-display text-lg font-bold tracking-tight text-white">
              {assistantName}
            </h2>
            <span className="text-xs text-slate-500">·</span>
            <span className="truncate text-xs font-medium text-sky-300">
              {orbState === 'SPEAKING'
                ? 'Speaking'
                : orbState === 'LISTENING'
                  ? 'Listening'
                  : orbState === 'THINKING'
                    ? 'Thinking'
                    : greetingName
                      ? `Ready for ${greetingName}`
                      : 'Voice Stage Ready'}
            </span>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <button
            type="button"
            onClick={onToggleVoiceOutput}
            aria-label={voiceOutputEnabled ? 'Mute AI voice' : 'Unmute AI voice'}
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full border border-slate-700/80 bg-[#0A1326]/90 text-slate-200 transition-colors hover:border-blue-400/60 hover:text-white"
          >
            {voiceOutputEnabled ? (
              <Volume2 className="h-4 w-4 text-sky-400" />
            ) : (
              <VolumeX className="h-4 w-4 text-slate-400" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setStageView((v) => (v === 'avatar' ? 'identity' : 'avatar'))}
            aria-label="Switch avatar visual"
            className="hidden min-h-[44px] items-center whitespace-nowrap rounded-full border border-slate-700/80 bg-[#0A1326]/90 px-3 text-xs font-medium text-slate-200 transition-colors hover:border-blue-400/50 hover:text-white sm:flex"
          >
            {stageView === 'avatar' ? 'Emblem' : 'Voice Avatar'}
          </button>

          <button
            type="button"
            onClick={() => onToggleHandsFree(!handsFreeMode)}
            aria-label="Toggle continuous conversation"
            className={`flex min-h-[44px] items-center gap-1.5 whitespace-nowrap rounded-full border px-3.5 text-xs font-medium transition-colors ${
              handsFreeMode
                ? 'border-[#38BDF8] bg-[#1677FF]/25 text-white'
                : 'border-slate-700/80 bg-[#0A1326]/90 text-slate-300 hover:border-blue-400/50'
            }`}
          >
            <Radio className="h-3.5 w-3.5 text-[#38BDF8]" />
            <span>{handsFreeMode ? 'Wake Live' : 'Hands-Free'}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            aria-label="Exit Avatar Voice Mode"
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full border border-slate-700/80 bg-[#0A1326]/90 text-slate-200 transition-colors hover:border-blue-400/60 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </header>

      <div className="relative z-10 flex flex-1 items-center justify-center overflow-hidden px-2">
        <div
          ref={stageRef}
          className="relative flex h-full w-full max-w-[520px] items-center justify-center"
        >
          <div
            ref={headLayerRef}
            className="relative aspect-[3/4] h-full max-h-[76vh] w-auto overflow-hidden rounded-3xl border border-blue-500/20"
          >
            {stageView === 'identity' ? (
              <div className="flex h-full w-full items-center justify-center bg-[#02050D] p-3">
                <SmwEmblem alt={`${assistantName} Emblem`} className="h-full w-full select-none object-contain" />
              </div>
            ) : !photoUnavailable ? (
              <>
                <img
                  src={avatarSrc}
                  alt={`${assistantName} Voice Avatar`}
                  referrerPolicy="no-referrer"
                  onError={() => setPhotoUnavailable(true)}
                  className="pointer-events-none h-full w-full select-none object-cover object-top"
                />
                {isFemaleMode ? (
                  <>
                    <div
                      aria-hidden="true"
                      className={`pointer-events-none absolute left-[43.2%] top-[24.2%] h-[2.0%] w-[5.8%] origin-top rounded-full bg-[#B48464]/95 shadow-[inset_0_-2px_2px_rgba(32,16,10,0.65)] transition-transform duration-75 ${
                        isBlinking ? 'scale-y-100 opacity-95' : 'scale-y-0 opacity-0'
                      }`}
                    />
                    <div
                      aria-hidden="true"
                      className={`pointer-events-none absolute left-[52.2%] top-[24.2%] h-[2.0%] w-[5.8%] origin-top rounded-full bg-[#B48464]/95 shadow-[inset_0_-2px_2px_rgba(32,16,10,0.65)] transition-transform duration-75 ${
                        isBlinking ? 'scale-y-100 opacity-95' : 'scale-y-0 opacity-0'
                      }`}
                    />
                    <div
                      ref={mouthCavityRef}
                      aria-hidden="true"
                      className="pointer-events-none absolute left-[47.6%] top-[33.6%] h-[1.8%] w-[6.0%] rounded-[50%] bg-gradient-to-b from-[#2A0E0B] via-[#3A1410] to-[#1A0706] opacity-0 shadow-[0_0_6px_rgba(0,0,0,0.75)]"
                    />
                    <div
                      ref={chinMotionRef}
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-x-[44.5%] top-[34.6%] h-[5.5%] rounded-b-full bg-gradient-to-b from-transparent to-black/15"
                    />
                  </>
                ) : (
                  <>
                    <div
                      aria-hidden="true"
                      className={`pointer-events-none absolute left-[41.9%] top-[24.8%] h-[2.3%] w-[6.5%] origin-top rounded-full bg-[#8D6145]/95 shadow-[inset_0_-2px_2px_rgba(24,12,7,0.75)] transition-transform duration-75 ${
                        isBlinking ? 'scale-y-100 opacity-95' : 'scale-y-0 opacity-0'
                      }`}
                    />
                    <div
                      aria-hidden="true"
                      className={`pointer-events-none absolute left-[52.5%] top-[24.8%] h-[2.3%] w-[6.5%] origin-top rounded-full bg-[#8D6145]/95 shadow-[inset_0_-2px_2px_rgba(24,12,7,0.75)] transition-transform duration-75 ${
                        isBlinking ? 'scale-y-100 opacity-95' : 'scale-y-0 opacity-0'
                      }`}
                    />
                    <div
                      ref={mouthCavityRef}
                      aria-hidden="true"
                      className="pointer-events-none absolute left-[47.4%] top-[35.0%] h-[2.0%] w-[6.4%] rounded-[50%] bg-gradient-to-b from-[#170907] via-[#2A0E0B] to-[#0D0505] opacity-0 shadow-[0_0_6px_rgba(0,0,0,0.85)]"
                    />
                    <div
                      ref={chinMotionRef}
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-x-[43.5%] top-[35.8%] h-[6.5%] rounded-b-full bg-gradient-to-b from-transparent to-black/20"
                    />
                  </>
                )}
              </>
            ) : (
              <div className="relative flex h-full w-full items-center justify-center bg-gradient-to-b from-[#071530] via-[#040B1B] to-[#02050D]">
                <svg viewBox="0 0 300 400" className="h-full w-full" aria-label={`${assistantName} Avatar`}>
                  <defs>
                    <radialGradient id="stageRim" cx="50%" cy="34%" r="55%">
                      <stop offset="0%" stopColor="#1E88FF" stopOpacity="0.45" />
                      <stop offset="65%" stopColor="#081C44" stopOpacity="0.2" />
                      <stop offset="100%" stopColor="#02050D" stopOpacity="0" />
                    </radialGradient>
                  </defs>
                  <rect width="300" height="400" fill="#030917" />
                  <circle cx="150" cy="145" r="135" fill="url(#stageRim)" />
                  <ellipse cx="150" cy="160" rx="50" ry="64" fill="#B88260" />
                  <ellipse
                    ref={svgMouthPathRef}
                    cx="150"
                    cy="195"
                    rx="9"
                    ry="1.8"
                    fill="#2A0E0B"
                  />
                </svg>
              </div>
            )}

            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_40%,transparent_54%,rgba(2,5,13,0.92)_96%)]" />
          </div>
        </div>
      </div>

      <div className="relative z-20 bg-gradient-to-t from-[#02050D] via-[#02050D]/95 to-transparent px-4 pt-3 pb-5 sm:px-6">
        <div className="mx-auto max-w-lg space-y-3">
          <div className="min-h-[54px] rounded-2xl border border-blue-400/20 bg-[#071022]/85 px-4 py-2.5 text-center backdrop-blur-md">
            {partialTranscript ? (
              <p className="text-sm font-medium text-sky-200">&ldquo;{partialTranscript}&rdquo;</p>
            ) : latestReply ? (
              <p className="line-clamp-3 text-sm leading-relaxed text-slate-100">
                {latestReply.text}
              </p>
            ) : (
              <p className="text-sm text-slate-300">
                {greetingName
                  ? `Assalamualaikum ${greetingName} — tap the mic and speak in Urdu, Roman Urdu, Hindi, or English.`
                  : 'Tap the mic and speak naturally in Urdu, Roman Urdu, Hindi, or English.'}
              </p>
            )}
            {latestUser && !partialTranscript && (
              <p className="mt-1 truncate text-[11px] text-slate-400">
                You: {latestUser.text}
              </p>
            )}
          </div>

          {showTextComposer && (
            <form
              onSubmit={handleSubmitDraft}
              className="flex items-center gap-2 rounded-full border border-blue-400/25 bg-[#0B152A]/95 p-1.5"
            >
              <input
                type="text"
                value={draftText}
                onChange={(e) => setDraftText(e.target.value)}
                placeholder="Type in Urdu, Roman Urdu, Hindi, or English..."
                className="min-w-0 flex-1 bg-transparent px-3 text-sm text-white placeholder:text-slate-400 focus:outline-none"
              />
              <button
                type="submit"
                aria-label="Send message"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full bg-[#1677FF] text-white hover:bg-[#2684FF]"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          )}

          <div className="flex items-center justify-center gap-4 pt-1">
            <button
              type="button"
              onClick={() => setShowTextComposer((v) => !v)}
              aria-label="Toggle keyboard input"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full border border-slate-700/80 bg-[#0A1326] text-slate-200 hover:border-blue-400/60 hover:text-white"
            >
              <Keyboard className="h-4 w-4" />
            </button>

            <div className="flex items-center gap-1" aria-hidden="true">
              {[0, 1, 2, 3, 4].map((idx) => (
                <span
                  key={`al-${idx}`}
                  ref={(el) => {
                    barRefs.current[idx] = el;
                  }}
                  className="h-7 w-[3px] origin-center rounded-full bg-gradient-to-t from-[#0066FF] to-[#38BDF8]"
                />
              ))}
            </div>

            <button
              type="button"
              onClick={onMicPress}
              aria-label={
                orbState === 'SPEAKING'
                  ? 'Interrupt speech'
                  : orbState === 'LISTENING'
                    ? 'Stop listening'
                    : 'Tap to speak'
              }
              className={`flex h-[68px] w-[68px] shrink-0 items-center justify-center rounded-full border-2 border-[#38BDF8] bg-gradient-to-b from-[#0C2D6B] to-[#051438] text-white transition-transform active:scale-95 ${
                orbState === 'LISTENING'
                  ? 'shadow-[0_0_36px_rgba(56,189,248,0.95)]'
                  : orbState === 'SPEAKING'
                    ? 'shadow-[0_0_36px_rgba(30,136,255,0.95)]'
                    : 'shadow-[0_0_24px_rgba(0,149,255,0.75)]'
              }`}
            >
              {orbState === 'LISTENING' ? (
                <MicOff className="h-7 w-7" />
              ) : (
                <Mic className="h-7 w-7" />
              )}
            </button>

            <div className="flex items-center gap-1" aria-hidden="true">
              {[5, 6, 7, 8, 9].map((idx) => (
                <span
                  key={`ar-${idx}`}
                  ref={(el) => {
                    barRefs.current[idx] = el;
                  }}
                  className="h-7 w-[3px] origin-center rounded-full bg-gradient-to-t from-[#0066FF] to-[#38BDF8]"
                />
              ))}
            </div>

            <div className="w-[44px]" aria-hidden="true" />
          </div>
        </div>
      </div>
    </div>
  );
}
