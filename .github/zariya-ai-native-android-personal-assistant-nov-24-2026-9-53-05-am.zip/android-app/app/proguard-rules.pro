# Kotlin Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.SerializationKt
-keep,includedescriptorclasses class com.zariya.assistant.data.model.**$$serializer { *; }
-keepclassmembers class com.zariya.assistant.data.model.** {
    *** Companion;
}
-keepclasseswithmembers class com.zariya.assistant.data.model.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Retrofit
-keepattributes Signature, Exceptions
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }
