package com.zariya.assistant

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zariya.assistant.recording.ScreenRecorderService
import com.zariya.assistant.ui.ZariyaViewModel
import com.zariya.assistant.ui.screens.AssistantChatScreen
import com.zariya.assistant.ui.screens.JarvisLiveScreen
import com.zariya.assistant.ui.theme.ObsidianBlack
import com.zariya.assistant.ui.theme.ZariyaTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ZariyaTheme {
                val vm: ZariyaViewModel = viewModel()
                var chatOpen by remember { mutableStateOf(false) }
                var startMicAfterGrant by remember { mutableStateOf(false) }
                var pendingProjectionMode by remember { mutableStateOf("RECORD") }
                val projectionTrigger by vm.pendingMediaProjectionRequest.collectAsState()

                val permissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { granted ->
                    vm.refreshPermissions()
                    if (granted && startMicAfterGrant) {
                        startMicAfterGrant = false
                        vm.toggleListening(handsFree = false)
                    } else {
                        startMicAfterGrant = false
                    }
                }

                val mediaProjectionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                        if (pendingProjectionMode == "SNAPSHOT") {
                            ScreenRecorderService.captureFrame(this, result.resultCode, result.data!!)
                        } else {
                            ScreenRecorderService.startRecording(
                                context = this,
                                resultCode = result.resultCode,
                                data = result.data!!,
                                withMic = vm.memory.recordMicWithScreen
                            )
                        }
                    }
                }

                fun launchMediaProjection(mode: String) {
                    pendingProjectionMode = mode
                    val mgr = getSystemService(MediaProjectionManager::class.java)
                    mediaProjectionLauncher.launch(mgr.createScreenCaptureIntent())
                }

                LaunchedEffect(projectionTrigger) {
                    projectionTrigger?.let { mode ->
                        vm.clearMediaProjectionTrigger()
                        launchMediaProjection(mode)
                    }
                }

                fun handleMicAction() {
                    val hasMic = ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!hasMic) {
                        startMicAfterGrant = true
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        return
                    }
                    if (vm.voiceEngine.isSpeaking.value) {
                        vm.voiceEngine.interruptSpeech()
                    } else {
                        vm.toggleListening(handsFree = false)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ObsidianBlack)
                ) {
                    if (chatOpen) {
                        AssistantChatScreen(
                            viewModel = vm,
                            onClose = { chatOpen = false }
                        )
                    } else {
                        JarvisLiveScreen(
                            viewModel = vm,
                            onMicClick = { handleMicAction() },
                            onOpenChat = { chatOpen = true }
                        )
                    }
                }
            }
        }
    }
}
