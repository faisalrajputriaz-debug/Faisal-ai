package com.zariya.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.zariya.assistant.data.local.EncryptedMemoryStore
import com.zariya.assistant.data.remote.ZariyaBackendClient

class ZariyaApplication : Application() {

    lateinit var memoryStore: EncryptedMemoryStore
        private set

    lateinit var backendClient: ZariyaBackendClient
        private set

    override fun onCreate() {
        super.onCreate()
        memoryStore = EncryptedMemoryStore(this)
        backendClient = ZariyaBackendClient(BuildConfig.BACKEND_BASE_URL)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_LIVE_VOICE,
                    "Jarvis Live Voice Mode",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Visible indicator while hands-free voice listening is active."
                },
                NotificationChannel(
                    CHANNEL_SCREEN_RECORDING,
                    "Screen Recording & Capture",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Active MediaProjection screen recording indicator."
                },
                NotificationChannel(
                    CHANNEL_CALL_ASSISTANT,
                    "Call Screening & Announcements",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Caller ID announcements and call-handling prompts."
                },
                NotificationChannel(
                    CHANNEL_WHATSAPP_AUTOMATION,
                    "WhatsApp Assistant Alerts",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Urgent message summaries and reply confirmation requests."
                }
            )
            channels.forEach(manager::createNotificationChannel)
        }
    }

    companion object {
        const val CHANNEL_LIVE_VOICE = "zariya_live_voice"
        const val CHANNEL_SCREEN_RECORDING = "zariya_screen_recording"
        const val CHANNEL_CALL_ASSISTANT = "zariya_call_assistant"
        const val CHANNEL_WHATSAPP_AUTOMATION = "zariya_whatsapp_automation"
    }
}
