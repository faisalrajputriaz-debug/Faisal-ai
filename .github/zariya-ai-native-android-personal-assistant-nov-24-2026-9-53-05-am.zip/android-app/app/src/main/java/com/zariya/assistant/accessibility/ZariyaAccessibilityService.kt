package com.zariya.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.zariya.assistant.data.model.ScreenSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Real Android AccessibilityService for screen reading and supported navigation.
 * Strictly skips password fields and protected authentication inputs; never bypasses app locks.
 */
class ZariyaAccessibilityService : AccessibilityService() {

    private var lastSelectedText: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
        captureCurrentScreen()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            val txt = event.text?.joinToString(" ")?.trim()
            if (!txt.isNullOrEmpty()) {
                lastSelectedText = txt
            }
        }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            captureCurrentScreen()
        }
    }

    override fun onInterrupt() {
        // Respect system interruption
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        _isConnected.value = false
        super.onDestroy()
    }

    fun captureCurrentScreen(): ScreenSnapshot? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString() ?: "unknown"
        val visibleTexts = mutableListOf<String>()
        val headings = mutableListOf<String>()
        val buttons = mutableListOf<String>()
        val editableFields = mutableListOf<String>()

        traverseNode(root, visibleTexts, headings, buttons, editableFields)

        val snapshot = ScreenSnapshot(
            packageName = pkg,
            appTitle = pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() },
            visibleTexts = visibleTexts.distinct().take(60),
            headings = headings.distinct().take(15),
            buttons = buttons.distinct().take(25),
            editableFields = editableFields.distinct().take(15),
            selectedText = lastSelectedText
        )
        _latestSnapshot.value = snapshot
        return snapshot
    }

    private fun traverseNode(
        node: AccessibilityNodeInfo?,
        visibleTexts: MutableList<String>,
        headings: MutableList<String>,
        buttons: MutableList<String>,
        editableFields: MutableList<String>
    ) {
        if (node == null) return
        // Security boundary: never read password or masked sensitive inputs
        if (node.isPassword) return

        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val label = text.ifEmpty { desc }

        if (label.isNotEmpty()) {
            visibleTexts.add(label)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && node.isHeading) {
                headings.add(label)
            }
            if (node.isClickable || node.className?.toString()?.contains("Button") == true) {
                buttons.add(label)
            }
        }

        if (node.isEditable) {
            val hint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                node.hintText?.toString()?.trim().orEmpty()
            } else ""
            editableFields.add(hint.ifEmpty { label.ifEmpty { "Text Input" } })
        }

        for (i in 0 until node.childCount) {
            traverseNode(node.getChild(i), visibleTexts, headings, buttons, editableFields)
        }
    }

    fun performBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun performHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        return findScrollableAndPerform(root, AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    fun scrollBackward(): Boolean {
        val root = rootInActiveWindow ?: return false
        return findScrollableAndPerform(root, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun clickNodeByLabel(targetLabel: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(targetLabel)
        for (node in matches) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable && !current.isPassword) {
                    return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                current = current.parent
            }
        }
        return false
    }

    fun fillFocusedOrFirstEditable(textToType: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = findEditableNode(root) ?: return false
        if (target.isPassword) return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findScrollableAndPerform(node: AccessibilityNodeInfo, action: Int): Boolean {
        if (node.isScrollable) {
            if (node.performAction(action)) return true
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (findScrollableAndPerform(child, action)) return true
        }
        return false
    }

    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && !node.isPassword) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findEditableNode(child)
            if (found != null) return found
        }
        return null
    }

    companion object {
        @Volatile
        var instance: ZariyaAccessibilityService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected

        private val _latestSnapshot = MutableStateFlow<ScreenSnapshot?>(null)
        val latestSnapshot: StateFlow<ScreenSnapshot?> = _latestSnapshot
    }
}
