package com.zariya.assistant.calls

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat

/**
 * Authorized Telecom & AudioManager call control helper.
 * Respects Android restrictions:
 * - Answering/ending calls requires ANSWER_PHONE_CALLS (API 26+/28+).
 * - Third-party apps cannot inject TTS audio directly into the cellular carrier voice uplink
 *   without system/VoIP carrier privileges; when SMS or call-screen response is supported,
 *   the assistant always identifies itself as an AI assistant.
 */
class CallControlHelper(private val context: Context) {

    private val telecomManager: TelecomManager? =
        context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager

    private val audioManager: AudioManager? =
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    fun hasAnswerCallPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun acceptRingingCall(): Result<String> {
        if (!hasAnswerCallPermission()) {
            return Result.failure(SecurityException("ANSWER_PHONE_CALLS permission is not granted."))
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                telecomManager?.acceptRingingCall()
                Result.success("Call answered via Android TelecomManager.")
            } else {
                Result.failure(UnsupportedOperationException("Accepting calls programmatically requires Android 8.0+."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    @SuppressLint("MissingPermission")
    fun endOrRejectCall(): Result<String> {
        if (!hasAnswerCallPermission()) {
            return Result.failure(SecurityException("ANSWER_PHONE_CALLS permission is not granted."))
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val ended = telecomManager?.endCall() ?: false
                if (ended) {
                    Result.success("Call ended/rejected via TelecomManager.")
                } else {
                    Result.failure(IllegalStateException("No active or ringing call to end."))
                }
            } else {
                Result.failure(UnsupportedOperationException("Ending calls via TelecomManager requires Android 9.0+."))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun setSpeakerphone(enabled: Boolean): Result<String> {
        val audio = audioManager ?: return Result.failure(IllegalStateException("AudioManager unavailable."))
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (enabled) {
                    val speaker = audio.availableCommunicationDevices.firstOrNull {
                        it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                    }
                    if (speaker != null) {
                        audio.setCommunicationDevice(speaker)
                    }
                } else {
                    audio.clearCommunicationDevice()
                }
            } else {
                @Suppress("DEPRECATION")
                audio.isSpeakerphoneOn = enabled
            }
            Result.success(if (enabled) "Speakerphone enabled." else "Speakerphone disabled.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun openBusyMessageComposer(phoneNumber: String, aiDisclosureNotice: String): Result<String> {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phoneNumber)}")).apply {
                putExtra("sms_body", aiDisclosureNotice)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("Opened authorized SMS composer with AI assistant busy notice.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
