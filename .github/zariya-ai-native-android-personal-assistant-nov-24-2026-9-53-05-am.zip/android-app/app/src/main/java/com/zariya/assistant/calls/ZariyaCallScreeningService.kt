package com.zariya.assistant.calls

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import androidx.core.content.ContextCompat
import com.zariya.assistant.ZariyaApplication
import com.zariya.assistant.data.model.CallScreeningEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

/**
 * Native Android CallScreeningService (requires user to grant ROLE_CALL_SCREENING).
 * Detects incoming calls, resolves contact name if READ_CONTACTS is granted,
 * emits caller events for aloud announcement, and never records/transcribes call audio.
 */
class ZariyaCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            callDetails.callDirection != Call.Details.DIRECTION_INCOMING
        ) {
            respondToCall(callDetails, CallResponse.Builder().build())
            return
        }

        val rawHandle = callDetails.handle?.schemeSpecificPart ?: "Unknown Number"
        val callerName = resolveContactName(rawHandle)
        val app = applicationContext as? ZariyaApplication
        val config = app?.memoryStore?.callAssistantConfig

        val event = CallScreeningEvent(
            id = UUID.randomUUID().toString(),
            phoneNumber = rawHandle,
            callerName = callerName,
            timestampMs = System.currentTimeMillis(),
            disposition = if (config?.enabled == true) "Screened & Announced" else "Passed Through"
        )
        _latestIncomingCall.value = event
        _callHistory.value = (listOf(event) + _callHistory.value).take(25)

        // Allow the call through cleanly so the user or TelecomManager controls answer/reject
        respondToCall(
            callDetails,
            CallResponse.Builder()
                .setDisallowCall(false)
                .setRejectCall(false)
                .setSilenceCall(false)
                .setSkipCallLog(false)
                .setSkipNotification(false)
                .build()
        )
    }

    private fun resolveContactName(phoneNumber: String): String? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(phoneNumber)
        )
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null,
                null,
                null
            )
            if (cursor != null && cursor.moveToFirst()) {
                cursor.getString(0)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            cursor?.close()
        }
    }

    companion object {
        private val _latestIncomingCall = MutableStateFlow<CallScreeningEvent?>(null)
        val latestIncomingCall: StateFlow<CallScreeningEvent?> = _latestIncomingCall

        private val _callHistory = MutableStateFlow<List<CallScreeningEvent>>(emptyList())
        val callHistory: StateFlow<List<CallScreeningEvent>> = _callHistory

        fun clearLatestCall() {
            _latestIncomingCall.value = null
        }
    }
}
