package com.zariya.assistant.control

import android.Manifest
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat

/**
 * Permission-respecting native Android device control layer.
 * Never bypasses lock screens, biometric prompts, payment flows, or protected system UI.
 */
class DeviceControlManager(private val context: Context) {

    fun openAppByName(appQuery: String): Result<String> {
        val pm = context.packageManager
        val q = appQuery.trim().lowercase()

        val known = mapOf(
            "whatsapp" to "com.whatsapp",
            "whatsapp business" to "com.whatsapp.w4b",
            "facebook" to "com.facebook.katana",
            "tiktok" to "com.zhiliaoapp.musically",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps"
        )
        known[q]?.let { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let { intent ->
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return Result.success("Opened $appQuery.")
            }
        }

        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        val match = apps.firstOrNull { resolve ->
            val label = resolve.loadLabel(pm).toString().lowercase()
            label.contains(q) || resolve.activityInfo.packageName.lowercase().contains(q)
        } ?: return Result.failure(IllegalArgumentException("App \"$appQuery\" is not installed."))

        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return Result.failure(IllegalStateException("App cannot be launched."))
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return Result.success("Opened ${match.loadLabel(pm)}.")
    }

    fun openWhatsAppChat(phoneNumber: String, prefillText: String = ""): Result<String> {
        return try {
            val cleanNumber = phoneNumber.replace(Regex("[^0-9]"), "")
            val uri = if (prefillText.isNotBlank()) {
                Uri.parse("https://api.whatsapp.com/send?phone=$cleanNumber&text=${Uri.encode(prefillText)}")
            } else {
                Uri.parse("https://api.whatsapp.com/send?phone=$cleanNumber")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            Result.success("Opened WhatsApp chat for $phoneNumber.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun searchYouTube(query: String): Result<String> {
        return try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                val web = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(web)
            }
            Result.success("Searched YouTube for \"$query\".")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun searchWeb(query: String): Result<String> {
        return try {
            val url = "https://www.google.com/search?q=${Uri.encode(query)}"
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Result.success("Opened internet search for \"$query\".")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun setFlashlight(enabled: Boolean): Result<String> {
        val hasCamera = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasCamera) {
            return Result.failure(SecurityException("CAMERA permission is required to toggle the flashlight."))
        }
        return try {
            val camManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = camManager.cameraIdList.firstOrNull { id ->
                val chars = camManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return Result.failure(IllegalStateException("No camera flash hardware detected."))
            camManager.setTorchMode(cameraId, enabled)
            Result.success(if (enabled) "Flashlight turned on." else "Flashlight turned off.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun adjustVolume(direction: String): Result<String> {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (direction.lowercase()) {
            "up", "increase" -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                Result.success("Increased media volume.")
            }
            "down", "decrease" -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                Result.success("Decreased media volume.")
            }
            "mute" -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                Result.success("Muted media volume.")
            }
            else -> Result.failure(IllegalArgumentException("Unsupported volume action: $direction"))
        }
    }

    fun setDoNotDisturb(enabled: Boolean): Result<String> {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            val settingsIntent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(settingsIntent)
            return Result.failure(SecurityException("Do Not Disturb access not granted. Opened Notification Policy settings."))
        }
        nm.setInterruptionFilter(
            if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return Result.success(if (enabled) "Do Not Disturb enabled." else "Do Not Disturb disabled.")
    }

    fun getBatteryStatus(): Pair<Int, Boolean> {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = if (pct in 0..100) pct else {
            val rawLevel = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            if (rawLevel >= 0 && scale > 0) (rawLevel * 100) / scale else -1
        }
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return Pair(level, charging)
    }

    fun controlMediaPlayback(action: String): Result<String> {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val keyCode = when (action.lowercase()) {
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "play", "resume" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return Result.success("Dispatched media control: $action.")
    }

    fun setAlarm(hour: Int, minute: Int, label: String): Result<String> {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
                putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("Opened Clock app to set alarm for %02d:%02d.".format(hour, minute))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun setTimer(seconds: Int, label: String): Result<String> {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceAtLeast(1))
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success("Opened Clock app to start $seconds second timer.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun openSystemSettings(): Result<String> {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return Result.success("Opened Android Settings.")
    }

    fun openCamera(captureMode: Boolean = false): Result<String> {
        val action = if (captureMode) MediaStore.ACTION_IMAGE_CAPTURE else MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA
        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return Result.success(if (captureMode) "Opened Camera capture mode." else "Opened Camera app.")
    }

    fun openGallery(): Result<String> {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            Result.success("Opened Photos / Gallery.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun openContacts(): Result<String> {
        val intent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            Result.success("Opened Android Contacts.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun openDialer(phoneNumber: String = ""): Result<String> {
        val uri = if (phoneNumber.isNotBlank()) Uri.parse("tel:${Uri.encode(phoneNumber)}") else Uri.parse("tel:")
        context.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return Result.success("Opened Phone Dialer.")
    }

    fun placePhoneCall(phoneNumber: String): Result<String> {
        val hasCallPerm = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
        val uri = Uri.parse("tel:${Uri.encode(phoneNumber)}")
        return if (hasCallPerm) {
            context.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Result.success("Calling $phoneNumber via Android Phone.")
        } else {
            context.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Result.success("Opened dialer for $phoneNumber (grant CALL_PHONE to dial directly).")
        }
    }

    fun sendSmsIntent(phoneNumber: String, messageBody: String): Result<String> {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phoneNumber)}")).apply {
            putExtra("sms_body", messageBody)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            Result.success("Opened SMS composer for $phoneNumber.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun copyToClipboard(label: String, text: String): Result<String> {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        return Result.success("Copied text to Android clipboard.")
    }

    fun shareText(text: String): Result<String> {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
        }
        val chooser = Intent.createChooser(sendIntent, "Share via").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
        return Result.success("Opened Android Share sheet.")
    }
}
