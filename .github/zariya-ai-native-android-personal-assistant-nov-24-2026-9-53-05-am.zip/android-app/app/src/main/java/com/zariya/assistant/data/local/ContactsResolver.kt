package com.zariya.assistant.data.local

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class ResolvedContact(
    val id: String,
    val displayName: String,
    val phoneNumber: String
)

sealed interface ContactLookupResult {
    data class Unique(val contact: ResolvedContact) : ContactLookupResult
    data class Ambiguous(val candidates: List<ResolvedContact>) : ContactLookupResult
    data object NotFound : ContactLookupResult
    data object PermissionDenied : ContactLookupResult
}

/**
 * Permission-respecting Android Contacts lookup with strict ambiguity handling.
 * Never resolves to an uncertain contact when multiple contacts share a name.
 */
class ContactsResolver(private val context: Context) {

    fun hasContactsPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    fun findByName(rawQuery: String): ContactLookupResult {
        if (!hasContactsPermission()) {
            return ContactLookupResult.PermissionDenied
        }
        val query = rawQuery.trim().lowercase()
        if (query.isEmpty()) return ContactLookupResult.NotFound

        val matches = LinkedHashMap<String, ResolvedContact>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        val selection = "LOWER(${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME}) LIKE ?"
        val args = arrayOf("%$query%")

        runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                args,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val id = if (idIdx >= 0) cursor.getString(idIdx).orEmpty() else ""
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx)?.trim().orEmpty() else ""
                    val rawNum = if (numIdx >= 0) cursor.getString(numIdx)?.trim().orEmpty() else ""
                    val normalizedNum = rawNum.replace(Regex("[^+0-9]"), "")
                    if (name.isNotEmpty() && normalizedNum.isNotEmpty() && !matches.containsKey(name.lowercase())) {
                        matches[name.lowercase()] = ResolvedContact(
                            id = id,
                            displayName = name,
                            phoneNumber = normalizedNum
                        )
                    }
                }
            }
        }

        val list = matches.values.toList()
        if (list.isEmpty()) return ContactLookupResult.NotFound

        val exactMatches = list.filter { it.displayName.equals(rawQuery.trim(), ignoreCase = true) }
        if (exactMatches.size == 1) {
            return ContactLookupResult.Unique(exactMatches.first())
        }
        return if (list.size == 1) {
            ContactLookupResult.Unique(list.first())
        } else {
            ContactLookupResult.Ambiguous(list.take(4))
        }
    }
}
