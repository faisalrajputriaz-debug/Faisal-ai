package com.zariya.assistant.data.model

import kotlinx.serialization.Serializable

enum class VoiceGender { FEMALE, MALE }

enum class VoicePersona(val apiValue: String, val label: String) {
    PUNJABI_LEGEND("punjabi_legend", "Punjabi Legend (Deep)"),
    STANDARD("standard", "Standard Assistant")
}

enum class AssistantLanguage(val code: String, val label: String) {
    AUTO("auto", "Auto (Punjabi / Urdu / Hindi / English)"),
    PUNJABI("pa-IN", "Punjabi"),
    ENGLISH("en-US", "English"),
    ROMAN_URDU("ur-PK", "Roman Urdu"),
    URDU("ur-PK", "Urdu"),
    HINDI("hi-IN", "Hindi")
}

enum class OrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

@Serializable
data class ChatMessage(
    val id: String,
    val role: String, // "user" | "assistant" | "system"
    val text: String,
    val timestampMs: Long = System.currentTimeMillis(),
    val taskReport: TaskExecutionReport? = null
)

@Serializable
data class TaskExecutionReport(
    val userRequest: String,
    val identifiedAction: String,
    val requiredPermission: String,
    val actionPerformed: String,
    val succeeded: Boolean,
    val failureReason: String? = null,
    val executionSource: String = "Local Native Engine",
    val timestampMs: Long = System.currentTimeMillis()
)

@Serializable
data class ScreenNodeInfo(
    val packageName: String,
    val className: String,
    val text: String,
    val contentDescription: String,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean,
    val isHeading: Boolean
)

@Serializable
data class ScreenSnapshot(
    val packageName: String,
    val appTitle: String,
    val visibleTexts: List<String>,
    val headings: List<String>,
    val buttons: List<String>,
    val editableFields: List<String>,
    val selectedText: String? = null,
    val capturedAtMs: Long = System.currentTimeMillis()
)

@Serializable
data class WhatsAppNotificationItem(
    val key: String,
    val packageName: String,
    val senderName: String,
    val messageText: String,
    val timestampMs: Long,
    val isUrgent: Boolean = false,
    val hasReplyAction: Boolean = false,
    val autoReplied: Boolean = false,
    val aiDraftReply: String? = null
)

enum class AutoReplyAudience {
    SELECTED_CONTACTS_ONLY,
    PRIORITY_CONTACTS_ONLY,
    EVERYONE_EXPLICIT
}

@Serializable
data class AutoReplyRule(
    val enabled: Boolean = false,
    val audience: AutoReplyAudience = AutoReplyAudience.SELECTED_CONTACTS_ONLY,
    val activeTemplate: String = "Assalamualaikum, main abhi kaam kar raha hoon. Main baad mein aapse baat karta hoon.",
    val scheduleEnabled: Boolean = false,
    val startHour: Int = 9,
    val endHour: Int = 18,
    val cooldownMinutes: Int = 30,
    val askBeforeUnconfigured: Boolean = true
)

@Serializable
data class CallAssistantConfig(
    val enabled: Boolean = true,
    val announceCallerAloud: Boolean = true,
    val autoAnswerSelectedContacts: Boolean = false,
    val handsFreeMode: Boolean = false,
    val defaultBusyNotice: String = "Hello, I am the owner's AI assistant. The owner is currently busy and will contact you later."
)

@Serializable
data class CallScreeningEvent(
    val id: String,
    val phoneNumber: String,
    val callerName: String?,
    val timestampMs: Long,
    val disposition: String
)

@Serializable
data class DailyTaskItem(
    val id: String,
    val type: String, // "note" | "reminder" | "alarm" | "timer"
    val title: String,
    val detail: String,
    val createdAtMs: Long = System.currentTimeMillis()
)

data class PermissionItemState(
    val id: String,
    val title: String,
    val androidPermission: String,
    val reason: String,
    val isGranted: Boolean,
    val isSpecialSystemAccess: Boolean = false
)

@Serializable
data class CommandIntentResponse(
    val intent: String,
    val targetApp: String? = null,
    val queryOrText: String? = null,
    val targetContact: String? = null,
    val requiredPermission: String = "None",
    val needsConfirmation: Boolean = false,
    val confirmationPrompt: String? = null,
    val spokenReply: String,
    val detectedLanguage: String = "en"
)
