package com.zariya.assistant.orchestrator

import android.content.Context
import com.zariya.assistant.ZariyaApplication
import com.zariya.assistant.accessibility.ZariyaAccessibilityService
import com.zariya.assistant.calls.CallControlHelper
import com.zariya.assistant.calls.ZariyaCallScreeningService
import com.zariya.assistant.control.DeviceControlManager
import com.zariya.assistant.data.local.ContactLookupResult
import com.zariya.assistant.data.local.ContactsResolver
import com.zariya.assistant.data.model.CommandIntentResponse
import com.zariya.assistant.data.model.DailyTaskItem
import com.zariya.assistant.data.model.TaskExecutionReport
import com.zariya.assistant.data.remote.ChatRequestDto
import com.zariya.assistant.data.remote.CommandRequestDto
import com.zariya.assistant.data.remote.ScreenAnalyzeRequestDto
import com.zariya.assistant.notifications.ZariyaNotificationListenerService
import com.zariya.assistant.recording.ScreenRecorderService
import java.util.UUID

/**
 * 6-Step Jarvis Command Execution Pipeline for SMW AI:
 * 1. Understand request locally via LocalCommandMatcher (or Gemini AI backend for open-ended queries)
 * 2. Identify target app/action & resolve contacts safely
 * 3. Check required Android permissions & service bindings
 * 4. Request confirmation if sensitive/unconfigured or contact ambiguous
 * 5. Execute native Android capability
 * 6. Return truthful TaskExecutionReport
 */
class JarvisCommandOrchestrator(
    private val context: Context,
    private val deviceControl: DeviceControlManager,
    private val callControl: CallControlHelper,
    private val onRequestMediaProjectionStart: () -> Unit,
    private val onRequestMediaProjectionSnapshot: () -> Unit,
    private val onSpeakResponse: (String) -> Unit
) {
    private val contactsResolver = ContactsResolver(context)

    suspend fun processCommand(
        rawCommand: String,
        confirmedSensitiveAction: Boolean = false
    ): Pair<String, TaskExecutionReport> {
        val app = context.applicationContext as ZariyaApplication
        val accessibility = ZariyaAccessibilityService.instance
        val screenSnap = accessibility?.captureCurrentScreen()
        val unreadCount = ZariyaNotificationListenerService.messages.value.size
        val customWake = app.memoryStore.wakePhrase

        // 1. Try deterministic on-device local command matcher first
        val localMatch = LocalCommandMatcher.match(rawCommand, customWake)
        val source: String
        val parsed: CommandIntentResponse

        if (localMatch != null) {
            source = "Local Native Engine"
            parsed = localMatch
        } else if (!LocalCommandMatcher.isLikelyDeviceAction(rawCommand, customWake)) {
            val (_, cleanedText) = LocalCommandMatcher.stripWakePrefix(rawCommand, customWake)
            val promptToSend = cleanedText.ifEmpty { rawCommand }
            source = "Gemini AI"
            val chatResult = runCatching {
                app.backendClient.api.chat(
                    ChatRequestDto(
                        message = promptToSend,
                        assistantName = app.memoryStore.assistantName,
                        preferredLanguage = app.memoryStore.preferredLanguage.code,
                        persona = app.memoryStore.voicePersona.apiValue
                    )
                )
            }
            return chatResult.fold(
                onSuccess = { chatRes ->
                    onSpeakResponse(chatRes.reply)
                    Pair(
                        chatRes.reply,
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "CONVERSATIONAL_CHAT",
                            requiredPermission = "INTERNET (Gemini Chat)",
                            actionPerformed = chatRes.modelUsed?.let { "Conversational reply via $it" }
                                ?: "Conversational reply via Gemini AI",
                            succeeded = true,
                            executionSource = source
                        )
                    )
                },
                onFailure = { err ->
                    val errorText = err.message ?: "AI chat server unavailable"
                    onSpeakResponse("AI server is currently busy. Native device commands still work offline.")
                    Pair(
                        errorText,
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "CONVERSATIONAL_CHAT",
                            requiredPermission = "INTERNET",
                            actionPerformed = "Attempted conversational reply via /api/ai/chat",
                            succeeded = false,
                            failureReason = errorText,
                            executionSource = source
                        )
                    )
                }
            )
        } else {
            source = "Gemini AI"
            parsed = runCatching {
                app.backendClient.api.parseCommand(
                    CommandRequestDto(
                        text = rawCommand,
                        assistantName = app.memoryStore.assistantName,
                        preferredLanguage = app.memoryStore.preferredLanguage.code,
                        persona = app.memoryStore.voicePersona.apiValue,
                        screenSummary = screenSnap?.visibleTexts?.take(12)?.joinToString(" | "),
                        unreadNotificationsCount = unreadCount
                    )
                )
            }.getOrElse { err ->
                val errorText = err.message ?: "AI server unavailable"
                onSpeakResponse("AI server is currently busy. Native device commands still work offline.")
                return Pair(
                    errorText,
                    TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "AI_COMMAND_PARSE",
                        requiredPermission = "INTERNET",
                        actionPerformed = "Attempted device-action parsing via Gemini AI",
                        succeeded = false,
                        failureReason = errorText,
                        executionSource = source
                    )
                )
            }
        }

        // 2. Smart contact ambiguity check BEFORE confirmation or execution
        val contactRequiredIntents = setOf("REPLY_WHATSAPP", "SEND_WHATSAPP_VOICE", "CALL_CONTACT", "SEND_SMS")
        if (parsed.intent.uppercase() in contactRequiredIntents && !parsed.targetContact.isNullOrBlank()) {
            when (val lookup = contactsResolver.findByName(parsed.targetContact)) {
                is ContactLookupResult.Ambiguous -> {
                    val names = lookup.candidates.joinToString(", ") { it.displayName }
                    val clarify = "Multiple contacts match \"${parsed.targetContact}\": $names. Please specify the full contact name."
                    onSpeakResponse(clarify)
                    return Pair(
                        clarify,
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "${parsed.intent} (Disambiguation Required)",
                            requiredPermission = "READ_CONTACTS",
                            actionPerformed = "Blocked ambiguous contact execution ($names)",
                            succeeded = false,
                            failureReason = clarify,
                            executionSource = source
                        )
                    )
                }
                else -> Unit
            }
        }

        if (parsed.needsConfirmation && !confirmedSensitiveAction) {
            val prompt = parsed.confirmationPrompt ?: parsed.spokenReply
            onSpeakResponse(prompt)
            return Pair(
                prompt,
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = parsed.requiredPermission,
                    actionPerformed = "Awaiting explicit user confirmation",
                    succeeded = false,
                    failureReason = "Confirmation required before executing ${parsed.intent}.",
                    executionSource = source
                )
            )
        }

        val report = executeParsedIntent(app, parsed, rawCommand, source)
        val finalReply = if (report.succeeded) {
            if (report.actionPerformed.isNotBlank() && parsed.intent.uppercase() in setOf(
                    "READ_WHATSAPP",
                    "SHOW_WHATSAPP_MESSAGES",
                    "READ_CONTACT_MESSAGE",
                    "READ_NOTIFICATIONS",
                    "CHECK_BATTERY"
                )
            ) {
                "${parsed.spokenReply} ${report.actionPerformed}"
            } else {
                parsed.spokenReply
            }
        } else {
            report.failureReason ?: "Action could not be completed."
        }
        onSpeakResponse(finalReply)
        return Pair(finalReply, report)
    }

    private suspend fun executeParsedIntent(
        app: ZariyaApplication,
        parsed: CommandIntentResponse,
        rawCommand: String,
        source: String
    ): TaskExecutionReport {
        val accessibility = ZariyaAccessibilityService.instance
        val notifListener = ZariyaNotificationListenerService.instance

        return when (parsed.intent.uppercase()) {
            "WAKE_ACK" -> {
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "WAKE_ACK",
                    requiredPermission = "RECORD_AUDIO",
                    actionPerformed = parsed.spokenReply,
                    succeeded = true,
                    executionSource = source
                )
            }

            "OPEN_APP" -> {
                val target = parsed.targetApp ?: "WhatsApp"
                val res = deviceControl.openAppByName(target)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_APP ($target)",
                    requiredPermission = "QUERY_ALL_PACKAGES / LAUNCHER_QUERY",
                    actionPerformed = res.getOrElse { "Attempted to open $target" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "CLOSE_APP" -> {
                val ok = accessibility?.performHome() == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "CLOSE_APP (${parsed.targetApp ?: "App"})",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Returned to Home screen (Android prevents third-party apps from force-killing other apps)." else "AccessibilityService required to navigate away.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable SMW AI Accessibility Service to perform Home navigation." else null,
                    executionSource = source
                )
            }

            "YOUTUBE_SEARCH" -> {
                val query = parsed.queryOrText ?: ""
                val res = deviceControl.searchYouTube(query)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "YOUTUBE_SEARCH",
                    requiredPermission = "None (Android Intent)",
                    actionPerformed = res.getOrElse { "Failed YouTube search" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "WEB_SEARCH" -> {
                val query = parsed.queryOrText ?: ""
                val res = deviceControl.searchWeb(query)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "WEB_SEARCH",
                    requiredPermission = "None (Browser Intent)",
                    actionPerformed = res.getOrElse { "Failed web search" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "READ_SCREEN", "EXPLAIN_SCREEN", "ANALYZE_SCREEN" -> {
                if (accessibility == null) {
                    return TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = parsed.intent,
                        requiredPermission = "AccessibilityService (BIND_ACCESSIBILITY_SERVICE)",
                        actionPerformed = "Checked AccessibilityService binding",
                        succeeded = false,
                        failureReason = "Accessibility Service is disabled. Enable SMW AI Screen Reader in Android Settings.",
                        executionSource = source
                    )
                }
                val snap = accessibility.captureCurrentScreen()
                if (snap == null || snap.visibleTexts.isEmpty()) {
                    onRequestMediaProjectionSnapshot()
                    return TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = parsed.intent,
                        requiredPermission = "MediaProjection / AccessibilityService",
                        actionPerformed = "Requested screen frame capture authorization",
                        succeeded = false,
                        failureReason = "No accessible text nodes found; authorize MediaProjection to analyze pixels.",
                        executionSource = source
                    )
                }
                val analysis = runCatching {
                    app.backendClient.api.analyzeScreen(
                        ScreenAnalyzeRequestDto(
                            accessibilitySummary = "App: ${snap.appTitle}\nHeadings: ${snap.headings.joinToString(", ")}\nButtons: ${snap.buttons.joinToString(", ")}\nText: ${snap.visibleTexts.joinToString(" | ")}",
                            prompt = rawCommand
                        )
                    )
                }
                val summary = analysis.getOrNull()?.summary ?: snap.visibleTexts.take(10).joinToString(". ")
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "AccessibilityService",
                    actionPerformed = summary,
                    succeeded = true,
                    executionSource = source
                )
            }

            "SCROLL_DOWN" -> {
                val ok = accessibility?.scrollForward() == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SCROLL_DOWN",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Scrolled down current view." else "Scroll failed.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService or view is not scrollable." else null,
                    executionSource = source
                )
            }

            "SCROLL_UP" -> {
                val ok = accessibility?.scrollBackward() == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SCROLL_UP",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Scrolled up current view." else "Scroll failed.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService or view is not scrollable." else null,
                    executionSource = source
                )
            }

            "NAVIGATE_BACK" -> {
                val ok = accessibility?.performBack() == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "NAVIGATE_BACK",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Performed Android Back action." else "Back action failed.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService to navigate back." else null,
                    executionSource = source
                )
            }

            "NAVIGATE_HOME" -> {
                val ok = accessibility?.performHome() == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "NAVIGATE_HOME",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Returned to Android Home screen." else "Home action failed.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService to go Home." else null,
                    executionSource = source
                )
            }

            "CLICK_ELEMENT" -> {
                val label = parsed.queryOrText.orEmpty()
                val ok = accessibility?.clickNodeByLabel(label) == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "CLICK_ELEMENT ($label)",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Clicked \"$label\"." else "Could not find clickable \"$label\".",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService or element not visible." else null,
                    executionSource = source
                )
            }

            "TYPE_TEXT" -> {
                val textToFill = parsed.queryOrText.orEmpty()
                val ok = accessibility?.fillFocusedOrFirstEditable(textToFill) == true
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "TYPE_TEXT",
                    requiredPermission = "AccessibilityService",
                    actionPerformed = if (ok) "Typed text into active field." else "No editable field found.",
                    succeeded = ok,
                    failureReason = if (!ok) "Enable AccessibilityService or focus an editable field." else null,
                    executionSource = source
                )
            }

            "READ_WHATSAPP", "SHOW_WHATSAPP_MESSAGES", "READ_NOTIFICATIONS" -> {
                if (!ZariyaNotificationListenerService.isConnected.value) {
                    return TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = parsed.intent,
                        requiredPermission = "NotificationListenerService",
                        actionPerformed = "Checked Notification Access",
                        succeeded = false,
                        failureReason = "Notification Listener permission is not enabled in Android Settings.",
                        executionSource = source
                    )
                }
                if (parsed.intent.uppercase() == "SHOW_WHATSAPP_MESSAGES") {
                    deviceControl.openAppByName("WhatsApp")
                }
                val msgs = ZariyaNotificationListenerService.messages.value
                val summary = if (msgs.isEmpty()) {
                    "No recent authorized WhatsApp notifications captured yet."
                } else {
                    msgs.take(3).joinToString(" | ") { "${it.senderName}: ${it.messageText}" }
                }
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "NotificationListenerService",
                    actionPerformed = summary,
                    succeeded = true,
                    executionSource = source
                )
            }

            "READ_CONTACT_MESSAGE", "OPEN_CONTACT_MESSAGE" -> {
                val target = parsed.targetContact.orEmpty()
                val msgs = ZariyaNotificationListenerService.messages.value
                val match = msgs.firstOrNull { it.senderName.contains(target, ignoreCase = true) }
                if (parsed.intent.uppercase() == "OPEN_CONTACT_MESSAGE") {
                    when (val lookup = contactsResolver.findByName(target)) {
                        is ContactLookupResult.Unique -> deviceControl.openWhatsAppChat(lookup.contact.phoneNumber)
                        else -> deviceControl.openAppByName("WhatsApp")
                    }
                }
                val summary = match?.let { "${it.senderName} sent: ${it.messageText}" }
                    ?: "No recent WhatsApp notification found from $target."
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "${parsed.intent} ($target)",
                    requiredPermission = "NotificationListenerService",
                    actionPerformed = summary,
                    succeeded = match != null || parsed.intent.uppercase() == "OPEN_CONTACT_MESSAGE",
                    failureReason = if (match == null && parsed.intent.uppercase() == "READ_CONTACT_MESSAGE") summary else null,
                    executionSource = source
                )
            }

            "REPLY_WHATSAPP" -> {
                val target = parsed.targetContact.orEmpty()
                val replyText = parsed.queryOrText.orEmpty()
                val match = ZariyaNotificationListenerService.messages.value.firstOrNull {
                    target.isEmpty() || it.senderName.contains(target, ignoreCase = true)
                }
                if (notifListener != null && match != null && match.hasReplyAction) {
                    val sent = notifListener.sendReply(match.key, replyText)
                    return TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "REPLY_WHATSAPP (${match.senderName})",
                        requiredPermission = "NotificationListenerService",
                        actionPerformed = if (sent) "Replied to ${match.senderName}: \"$replyText\"" else "Failed sending RemoteInput.",
                        succeeded = sent,
                        failureReason = if (!sent) "PendingIntent reply action rejected by OS." else null,
                        executionSource = source
                    )
                }
                when (val lookup = contactsResolver.findByName(target)) {
                    is ContactLookupResult.Unique -> {
                        val openRes = deviceControl.openWhatsAppChat(lookup.contact.phoneNumber, replyText)
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "SEND_WHATSAPP (${lookup.contact.displayName})",
                            requiredPermission = "READ_CONTACTS + WhatsApp Intent",
                            actionPerformed = openRes.getOrElse { "Failed opening WhatsApp chat" },
                            succeeded = openRes.isSuccess,
                            failureReason = openRes.exceptionOrNull()?.message,
                            executionSource = source
                        )
                    }
                    is ContactLookupResult.PermissionDenied -> {
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "REPLY_WHATSAPP ($target)",
                            requiredPermission = "READ_CONTACTS / NotificationListenerService",
                            actionPerformed = "Checked contacts and active notifications",
                            succeeded = false,
                            failureReason = "Grant Contacts or Notification Listener permission to send to $target.",
                            executionSource = source
                        )
                    }
                    else -> {
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "REPLY_WHATSAPP ($target)",
                            requiredPermission = "NotificationListenerService / READ_CONTACTS",
                            actionPerformed = "Looked up $target",
                            succeeded = false,
                            failureReason = "Could not find $target in active WhatsApp notifications or Contacts.",
                            executionSource = source
                        )
                    }
                }
            }

            "SEND_WHATSAPP_VOICE" -> {
                val target = parsed.targetContact.orEmpty()
                when (val lookup = contactsResolver.findByName(target)) {
                    is ContactLookupResult.Unique -> {
                        val openRes = deviceControl.openWhatsAppChat(lookup.contact.phoneNumber)
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "SEND_WHATSAPP_VOICE (${lookup.contact.displayName})",
                            requiredPermission = "READ_CONTACTS + WhatsApp Intent",
                            actionPerformed = if (openRes.isSuccess) "Opened WhatsApp chat for ${lookup.contact.displayName}. Tap and hold WhatsApp mic to record your voice note." else "Could not open WhatsApp.",
                            succeeded = openRes.isSuccess,
                            failureReason = openRes.exceptionOrNull()?.message,
                            executionSource = source
                        )
                    }
                    is ContactLookupResult.PermissionDenied -> TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "SEND_WHATSAPP_VOICE",
                        requiredPermission = "READ_CONTACTS",
                        actionPerformed = "Checked Contacts permission",
                        succeeded = false,
                        failureReason = "Grant READ_CONTACTS permission so SMW AI can open $target's WhatsApp chat.",
                        executionSource = source
                    )
                    else -> {
                        deviceControl.openAppByName("WhatsApp")
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "SEND_WHATSAPP_VOICE ($target)",
                            requiredPermission = "READ_CONTACTS",
                            actionPerformed = "Opened WhatsApp (contact \"$target\" not found in phone book).",
                            succeeded = true,
                            executionSource = source
                        )
                    }
                }
            }

            "CALL_CONTACT" -> {
                val target = parsed.targetContact.orEmpty()
                when (val lookup = contactsResolver.findByName(target)) {
                    is ContactLookupResult.Unique -> {
                        val res = deviceControl.placePhoneCall(lookup.contact.phoneNumber)
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "CALL_CONTACT (${lookup.contact.displayName})",
                            requiredPermission = "READ_CONTACTS + CALL_PHONE",
                            actionPerformed = res.getOrElse { "Failed placing call" },
                            succeeded = res.isSuccess,
                            failureReason = res.exceptionOrNull()?.message,
                            executionSource = source
                        )
                    }
                    is ContactLookupResult.PermissionDenied -> TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "CALL_CONTACT ($target)",
                        requiredPermission = "READ_CONTACTS",
                        actionPerformed = "Checked Contacts permission",
                        succeeded = false,
                        failureReason = "Grant READ_CONTACTS permission to call $target.",
                        executionSource = source
                    )
                    else -> TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "CALL_CONTACT ($target)",
                        requiredPermission = "READ_CONTACTS",
                        actionPerformed = "Searched Contacts for $target",
                        succeeded = false,
                        failureReason = "No contact matching \"$target\" found.",
                        executionSource = source
                    )
                }
            }

            "SEND_SMS" -> {
                val target = parsed.targetContact.orEmpty()
                val body = parsed.queryOrText.orEmpty()
                when (val lookup = contactsResolver.findByName(target)) {
                    is ContactLookupResult.Unique -> {
                        val res = deviceControl.sendSmsIntent(lookup.contact.phoneNumber, body)
                        TaskExecutionReport(
                            userRequest = rawCommand,
                            identifiedAction = "SEND_SMS (${lookup.contact.displayName})",
                            requiredPermission = "READ_CONTACTS + SMS Intent",
                            actionPerformed = res.getOrElse { "Failed opening SMS composer" },
                            succeeded = res.isSuccess,
                            failureReason = res.exceptionOrNull()?.message,
                            executionSource = source
                        )
                    }
                    is ContactLookupResult.PermissionDenied -> TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "SEND_SMS ($target)",
                        requiredPermission = "READ_CONTACTS",
                        actionPerformed = "Checked Contacts permission",
                        succeeded = false,
                        failureReason = "Grant READ_CONTACTS permission to address SMS to $target.",
                        executionSource = source
                    )
                    else -> TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "SEND_SMS ($target)",
                        requiredPermission = "READ_CONTACTS",
                        actionPerformed = "Searched Contacts for $target",
                        succeeded = false,
                        failureReason = "No contact matching \"$target\" found.",
                        executionSource = source
                    )
                }
            }

            "AUTO_REPLY_RULE" -> {
                app.memoryStore.autoReplyRule = app.memoryStore.autoReplyRule.copy(enabled = true)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "AUTO_REPLY_RULE",
                    requiredPermission = "NotificationListenerService",
                    actionPerformed = "Enabled WhatsApp automatic busy reply rule.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "START_RECORDING" -> {
                onRequestMediaProjectionStart()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "START_RECORDING",
                    requiredPermission = "MediaProjection + FOREGROUND_SERVICE_MEDIA_PROJECTION",
                    actionPerformed = "Prompted Android screen-capture consent dialog",
                    succeeded = true,
                    executionSource = source
                )
            }

            "PAUSE_RECORDING" -> {
                ScreenRecorderService.sendControl(context, ScreenRecorderService.ACTION_PAUSE)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "PAUSE_RECORDING",
                    requiredPermission = "MediaProjection",
                    actionPerformed = "Paused active screen recording.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "RESUME_RECORDING" -> {
                ScreenRecorderService.sendControl(context, ScreenRecorderService.ACTION_RESUME)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "RESUME_RECORDING",
                    requiredPermission = "MediaProjection",
                    actionPerformed = "Resumed screen recording.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "STOP_RECORDING" -> {
                ScreenRecorderService.sendControl(context, ScreenRecorderService.ACTION_STOP)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "STOP_RECORDING",
                    requiredPermission = "MediaProjection",
                    actionPerformed = "Stopped active screen recording and saved output.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "CAPTURE_SCREENSHOT" -> {
                onRequestMediaProjectionSnapshot()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "CAPTURE_SCREENSHOT",
                    requiredPermission = "MediaProjection",
                    actionPerformed = "Prompted MediaProjection frame capture for AI Vision.",
                    succeeded = true,
                    executionSource = source
                )
            }

            "ANSWER_CALL" -> {
                val res = callControl.acceptRingingCall()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "ANSWER_CALL",
                    requiredPermission = "ANSWER_PHONE_CALLS",
                    actionPerformed = res.getOrElse { "Attempted to answer call" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "REJECT_CALL", "END_CALL" -> {
                val res = callControl.endOrRejectCall()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "ANSWER_PHONE_CALLS",
                    actionPerformed = res.getOrElse { "Attempted to reject/end call" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "SPEAKERPHONE_ON" -> {
                val res = callControl.setSpeakerphone(true)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SPEAKERPHONE_ON",
                    requiredPermission = "MODIFY_AUDIO_SETTINGS",
                    actionPerformed = res.getOrElse { "Failed speakerphone toggle" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "TELL_CALLER_BUSY" -> {
                val latestNumber = ZariyaCallScreeningService.latestIncomingCall.value?.phoneNumber.orEmpty()
                if (latestNumber.isEmpty()) {
                    TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "TELL_CALLER_BUSY",
                        requiredPermission = "CallScreeningService",
                        actionPerformed = "Checked recent screened caller number",
                        succeeded = false,
                        failureReason = "No recent incoming caller number available.",
                        executionSource = source
                    )
                } else {
                    val res = callControl.openBusyMessageComposer(
                        latestNumber,
                        app.memoryStore.callAssistantConfig.defaultBusyNotice
                    )
                    TaskExecutionReport(
                        userRequest = rawCommand,
                        identifiedAction = "TELL_CALLER_BUSY",
                        requiredPermission = "Telecom / SMS Intent",
                        actionPerformed = res.getOrElse { "Failed opening SMS busy notice" },
                        succeeded = res.isSuccess,
                        failureReason = res.exceptionOrNull()?.message,
                        executionSource = source
                    )
                }
            }

            "CHECK_BATTERY" -> {
                val (pct, charging) = deviceControl.getBatteryStatus()
                val text = if (pct >= 0) {
                    "Battery level is $pct%${if (charging) " (Charging)" else ""}."
                } else {
                    "Unable to read battery level on this device."
                }
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "CHECK_BATTERY",
                    requiredPermission = "BatteryManager",
                    actionPerformed = text,
                    succeeded = pct >= 0,
                    executionSource = source
                )
            }

            "ENABLE_DND", "DISABLE_DND" -> {
                val on = parsed.intent.uppercase() == "ENABLE_DND"
                val res = deviceControl.setDoNotDisturb(on)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "ACCESS_NOTIFICATION_POLICY",
                    actionPerformed = res.getOrElse { "Do Not Disturb access needed" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "FLASHLIGHT_ON", "FLASHLIGHT_OFF" -> {
                val on = parsed.intent.uppercase() == "FLASHLIGHT_ON"
                val res = deviceControl.setFlashlight(on)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "CAMERA",
                    actionPerformed = res.getOrElse { "Failed flashlight toggle" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "VOLUME_UP", "VOLUME_DOWN", "VOLUME_MUTE" -> {
                val dir = when (parsed.intent.uppercase()) {
                    "VOLUME_UP" -> "up"
                    "VOLUME_DOWN" -> "down"
                    else -> "mute"
                }
                val res = deviceControl.adjustVolume(dir)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "AudioManager",
                    actionPerformed = res.getOrElse { "Failed volume adjustment" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "MEDIA_PLAY", "MEDIA_PAUSE", "MEDIA_NEXT" -> {
                val act = parsed.intent.substringAfter("MEDIA_").lowercase()
                val res = deviceControl.controlMediaPlayback(act)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "AudioManager",
                    actionPerformed = res.getOrElse { "Failed media control" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "SET_ALARM" -> {
                val res = deviceControl.setAlarm(7, 0, parsed.queryOrText ?: "SMW AI Alarm")
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SET_ALARM",
                    requiredPermission = "SET_ALARM",
                    actionPerformed = res.getOrElse { "Failed to open alarm" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "SET_TIMER" -> {
                val res = deviceControl.setTimer(300, parsed.queryOrText ?: "SMW AI Timer")
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SET_TIMER",
                    requiredPermission = "SET_ALARM",
                    actionPerformed = res.getOrElse { "Failed to start timer" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "ADD_NOTE", "ADD_REMINDER" -> {
                val item = DailyTaskItem(
                    id = UUID.randomUUID().toString(),
                    type = if (parsed.intent.uppercase() == "ADD_NOTE") "note" else "reminder",
                    title = parsed.queryOrText ?: rawCommand,
                    detail = "Saved via voice command"
                )
                app.memoryStore.addDailyTask(item)
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "EncryptedSharedPreferences (Local)",
                    actionPerformed = "Saved ${item.type}: ${item.title}",
                    succeeded = true,
                    executionSource = source
                )
            }

            "OPEN_SETTINGS" -> {
                val res = deviceControl.openSystemSettings()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_SETTINGS",
                    requiredPermission = "None",
                    actionPerformed = res.getOrDefault("Opened Settings"),
                    succeeded = res.isSuccess,
                    executionSource = source
                )
            }

            "OPEN_CAMERA", "CAPTURE_PHOTO" -> {
                val res = deviceControl.openCamera(parsed.intent.uppercase() == "CAPTURE_PHOTO")
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = "Camera Intent",
                    actionPerformed = res.getOrDefault("Opened Camera"),
                    succeeded = res.isSuccess,
                    executionSource = source
                )
            }

            "OPEN_GALLERY" -> {
                val res = deviceControl.openGallery()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_GALLERY",
                    requiredPermission = "Media Intent",
                    actionPerformed = res.getOrElse { "Failed opening Gallery" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "OPEN_CONTACTS" -> {
                val res = deviceControl.openContacts()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_CONTACTS",
                    requiredPermission = "Contacts Intent",
                    actionPerformed = res.getOrElse { "Failed opening Contacts" },
                    succeeded = res.isSuccess,
                    failureReason = res.exceptionOrNull()?.message,
                    executionSource = source
                )
            }

            "SHARE_FILE" -> {
                val res = deviceControl.shareText("Shared from SMW AI Assistant")
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "SHARE_FILE",
                    requiredPermission = "Android Share Sheet",
                    actionPerformed = res.getOrElse { "Failed opening share sheet" },
                    succeeded = res.isSuccess,
                    executionSource = source
                )
            }

            "OPEN_DIALER" -> {
                val res = deviceControl.openDialer()
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = "OPEN_DIALER",
                    requiredPermission = "None",
                    actionPerformed = res.getOrDefault("Opened Dialer"),
                    succeeded = res.isSuccess,
                    executionSource = source
                )
            }

            else -> {
                TaskExecutionReport(
                    userRequest = rawCommand,
                    identifiedAction = parsed.intent,
                    requiredPermission = parsed.requiredPermission,
                    actionPerformed = parsed.spokenReply,
                    succeeded = true,
                    executionSource = source
                )
            }
        }
    }
}
