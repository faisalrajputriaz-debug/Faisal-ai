package com.zariya.assistant.orchestrator

import com.zariya.assistant.data.model.CommandIntentResponse
import java.util.Locale

/**
 * Deterministic on-device multilingual command matcher for SMW AI.
 * Executes Punjabi, Urdu, Roman Urdu, Hindi, and English Android commands locally in <2ms
 * without requiring an external Gemini API round-trip.
 */
object LocalCommandMatcher {

    val SUPPORTED_WAKE_WORDS = listOf(
        "hey siri",
        "hey ai",
        "hello ai",
        "faizan ai",
        "okay ai",
        "ok ai",
        "smw ai",
        "hey assistant"
    )

    fun stripWakePrefix(rawText: String, customWakePhrase: String = ""): Pair<String?, String> {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return Pair(null, "")
        val candidates = (listOf(customWakePhrase.trim()).filter { it.isNotEmpty() } + SUPPORTED_WAKE_WORDS)
            .distinctBy { it.lowercase(Locale.ROOT) }
            .sortedByDescending { it.length }

        val lower = trimmed.lowercase(Locale.ROOT)
        for (wake in candidates) {
            val wakeLower = wake.lowercase(Locale.ROOT)
            val pattern = Regex("^(?:${Regex.escape(wakeLower)})[\\s,.:!?-]+(.*)$", RegexOption.IGNORE_CASE)
            val match = pattern.find(trimmed)
            if (match != null) {
                return Pair(wake, match.groupValues[1].trim())
            }
            if (lower == wakeLower) {
                return Pair(wake, "")
            }
        }
        return Pair(null, trimmed)
    }

    private fun detectLanguage(text: String): String {
        if (Regex("[\\u0600-\\u06FF]").containsMatchIn(text)) return "ur"
        if (Regex("[\\u0900-\\u097F]").containsMatchIn(text)) return "hi"
        if (Regex("[\\u0A00-\\u0A7F]").containsMatchIn(text)) return "pa"
        val romanPattern = Regex(
            "\\b(kholo|karo|parho|batao|bata|likho|band|shuru|jalao|uthao|barhao|kam|neeche|upar|peeche|mera|meri|mujhe|main|hoon|haan|hai|kya|ki|aur|abhi|kaun|kis|kisi|bhej|bhejo|dein|do|lo|lagao|sunao|dikhao|bolo|haan|haal|mausam|kitni)\\b",
            RegexOption.IGNORE_CASE
        )
        return if (romanPattern.containsMatchIn(text)) "roman-ur" else "en"
    }

    private fun reply(lang: String, en: String, romanUr: String): String =
        if (lang == "en") en else romanUr

    fun match(rawInput: String, customWakePhrase: String = ""): CommandIntentResponse? {
        val (wakeHit, stripped) = stripWakePrefix(rawInput, customWakePhrase)
        val text = stripped.trim().trimEnd('.', '?', '!')
        if (text.isEmpty()) {
            if (wakeHit != null) {
                return CommandIntentResponse(
                    intent = "WAKE_ACK",
                    requiredPermission = "RECORD_AUDIO",
                    needsConfirmation = false,
                    spokenReply = "Haan Faisal, boliye. Main sun rahi hoon."
                )
            }
            return null
        }

        val lower = text.lowercase(Locale.ROOT)
        val lang = detectLanguage(text)

        // 1. Auto-reply rule
        if (Regex("\\b(jis\\s*kisi|everyone|sab\\s*ko|auto\\s*reply|busy\\s*mode)\\b").containsMatchIn(lower) &&
            (lower.contains("message") || lower.contains("whatsapp") || lower.contains("busy") || lower.contains("kaam"))
        ) {
            return CommandIntentResponse(
                intent = "AUTO_REPLY_RULE",
                targetApp = "WhatsApp",
                queryOrText = text,
                requiredPermission = "NotificationListenerService",
                needsConfirmation = true,
                confirmationPrompt = reply(
                    lang,
                    "Enable automatic WhatsApp busy replies for incoming messages? Please confirm.",
                    "Kya main incoming WhatsApp messages par automatic busy reply on kar doon? Confirm karein."
                ),
                spokenReply = reply(lang, "WhatsApp auto-reply rule activated.", "WhatsApp auto-reply rule activate kar diya hai."),
                detectedLanguage = lang
            )
        }

        // 2. Specific contact WhatsApp message read / open / reply read
        val contactOpenMsg = Regex("^([a-zA-Z\\u0600-\\u06FF\\s]{2,28}?)\\s+ka\\s+(?:message|msg|reply)\\s+(?:open\\s+karo|kholo)$", RegexOption.IGNORE_CASE).find(text)
        if (contactOpenMsg != null) {
            val contact = contactOpenMsg.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "OPEN_CONTACT_MESSAGE",
                targetApp = "WhatsApp",
                targetContact = contact,
                requiredPermission = "NotificationListenerService + READ_CONTACTS",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening $contact's WhatsApp message.", "$contact ka WhatsApp message open kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        val contactWhatSent = Regex("^([a-zA-Z\\u0600-\\u06FF\\s]{2,28}?)\\s+(?:ne\\s+kya\\s+message\\s+bheja\\s+hai|ka\\s+(?:reply|message)\\s+(?:parh\\s+kar\\s+sunao|parho|batao|sunao))$", RegexOption.IGNORE_CASE).find(text)
        if (contactWhatSent != null) {
            val contact = contactWhatSent.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "READ_CONTACT_MESSAGE",
                targetApp = "WhatsApp",
                targetContact = contact,
                requiredPermission = "NotificationListenerService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Reading $contact's latest message.", "$contact ka message parh kar suna rahi hoon."),
                detectedLanguage = lang
            )
        }

        // 3. WhatsApp voice message to contact
        val voiceMsgMatch = Regex("(?:whatsapp\\s+par\\s+)?([a-zA-Z\\u0600-\\u06FF\\s]{2,28}?)\\s+ko\\s+voice\\s+message\\s+bhej(?:o|ein|na)", RegexOption.IGNORE_CASE).find(text)
            ?: Regex("^send\\s+(?:a\\s+)?voice\\s+message\\s+to\\s+([a-zA-Z\\s]{2,28})$", RegexOption.IGNORE_CASE).find(text)
        if (voiceMsgMatch != null) {
            val contact = voiceMsgMatch.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "SEND_WHATSAPP_VOICE",
                targetApp = "WhatsApp",
                targetContact = contact,
                requiredPermission = "READ_CONTACTS + WhatsApp Intent",
                needsConfirmation = true,
                confirmationPrompt = reply(
                    lang,
                    "Open $contact's WhatsApp chat so you can send a voice message? Confirm to continue.",
                    "Kya main $contact ki WhatsApp chat khol doon taake aap voice message bhej sakein? Confirm karein."
                ),
                spokenReply = reply(lang, "Opening $contact's WhatsApp chat for voice message.", "$contact ki WhatsApp chat khol rahi hoon voice message ke liye."),
                detectedLanguage = lang
            )
        }

        // 4. WhatsApp send / reply to contact (Urdu / Roman Urdu / Hindi / English)
        val romanWhatsAppComplex = Regex(
            "^(?:whatsapp\\s+par\\s+)?([a-zA-Z\\u0600-\\u06FF\\s]{2,28}?)\\s+ko\\s+(?:message\\s+karo|message\\s+bhejo|bata\\s*do|likh\\s*do|bolo|reply\\s*karo)(?:\\s+(?:ke|kay|ki))?(?:\\s+(.+))?$",
            RegexOption.IGNORE_CASE
        ).find(text)
        if (romanWhatsAppComplex != null) {
            val contact = romanWhatsAppComplex.groupValues[1].trim()
            val body = romanWhatsAppComplex.groupValues[2].trim().ifEmpty { "Assalamualaikum, aap se baat karni thi." }
            return CommandIntentResponse(
                intent = "REPLY_WHATSAPP",
                targetApp = "WhatsApp",
                targetContact = contact,
                queryOrText = body,
                requiredPermission = "NotificationListenerService + READ_CONTACTS",
                needsConfirmation = true,
                confirmationPrompt = reply(
                    lang,
                    "Confirm sending WhatsApp message to $contact: \"$body\"?",
                    "Kya main $contact ko WhatsApp message bhej doon: \"$body\"?"
                ),
                spokenReply = reply(lang, "Message prepared for $contact. Confirm to send.", "$contact ke liye message tayyar hai. Confirm karein."),
                detectedLanguage = lang
            )
        }

        val enReply = Regex("^(?:send\\s+(?:a\\s+)?whatsapp\\s+(?:message\\s+)?to|reply\\s+to|message|tell)\\s+([a-zA-Z]+)(?:\\s+(?:that|saying)\\s+(.+))?$", RegexOption.IGNORE_CASE).find(text)
        if (enReply != null && !enReply.groupValues[1].equals("caller", true) && !enReply.groupValues[1].equals("everyone", true)) {
            val contact = enReply.groupValues[1].trim()
            val msg = enReply.groupValues[2].trim().ifEmpty { "I am currently busy, will text back soon." }
            return CommandIntentResponse(
                intent = "REPLY_WHATSAPP",
                targetApp = "WhatsApp",
                targetContact = contact,
                queryOrText = msg,
                requiredPermission = "NotificationListenerService + READ_CONTACTS",
                needsConfirmation = true,
                confirmationPrompt = "Confirm sending WhatsApp message to $contact: \"$msg\"?",
                spokenReply = "Message prepared for $contact. Confirm to send.",
                detectedLanguage = lang
            )
        }

        // 5. Complete / full message read follow-up & unread / latest WhatsApp messages
        if (Regex("\\b(complete|full|poora|mukammal)\\s+message\\s+(?:parho|read|sunao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "READ_WHATSAPP",
                targetApp = "WhatsApp",
                queryOrText = "full",
                requiredPermission = "NotificationListenerService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Reading complete message.", "Poora message parh kar suna rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(mujhe\\s+)?whatsapp\\s+messages\\s+dikhao\\b").containsMatchIn(lower) ||
            Regex("\\bshow\\s+(?:my\\s+)?whatsapp\\s+messages\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "SHOW_WHATSAPP_MESSAGES",
                targetApp = "WhatsApp",
                requiredPermission = "NotificationListenerService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Showing your latest WhatsApp messages.", "Aapke latest WhatsApp messages dikha rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(latest\\s+unread|unread\\s+messages|parh\\s+kar\\s+sunao|kis\\s+ka\\s+message|kis\\s+ka\\s+aaya|who\\s+(?:just\\s+)?messaged|read\\s+(?:my\\s+)?(?:whatsapp|messages|notifications))\\b").containsMatchIn(lower) ||
            ((lower.contains("whatsapp") || text.contains("واٹس ایپ")) && (lower.contains("message") || lower.contains("parho") || lower.contains("read") || lower.contains("kis")))
        ) {
            return CommandIntentResponse(
                intent = "READ_WHATSAPP",
                targetApp = "WhatsApp",
                requiredPermission = "NotificationListenerService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Reading your latest authorized WhatsApp messages.", "Aapke latest WhatsApp messages parh kar suna rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(read|check)\\s+(?:all\\s+)?notifications\\b").containsMatchIn(lower) ||
            Regex("\\bnotifications\\s+(?:parho|batao|check)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "READ_NOTIFICATIONS",
                requiredPermission = "NotificationListenerService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Checking your recent notifications.", "Aapki recent notifications check kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        // 6. Phone calls to contact & SMS with confirmation
        val callContactMatch = Regex("^([a-zA-Z\\u0600-\\u06FF\\s]{2,28}?)\\s+ko\\s+call\\s+(?:lagao|karo|milao)$", RegexOption.IGNORE_CASE).find(text)
            ?: Regex("^(?:call|dial|phone)\\s+([a-zA-Z\\s]{2,28})$", RegexOption.IGNORE_CASE).find(text)
        if (callContactMatch != null && !lower.contains("answer") && !lower.contains("reject") && !lower.contains("end")) {
            val contact = callContactMatch.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "CALL_CONTACT",
                targetContact = contact,
                requiredPermission = "READ_CONTACTS + CALL_PHONE",
                needsConfirmation = true,
                confirmationPrompt = reply(
                    lang,
                    "Confirm calling $contact?",
                    "Kya main $contact ko call mila doon? Confirm karein."
                ),
                spokenReply = reply(lang, "Checking contact $contact before calling.", "$contact ko call milane ke liye confirm karein."),
                detectedLanguage = lang
            )
        }

        val smsMatch = Regex("^(?:send\\s+sms\\s+to|sms)\\s+([a-zA-Z\\s]{2,28}?)(?:\\s+(?:that|saying)\\s+(.+))?$", RegexOption.IGNORE_CASE).find(text)
            ?: Regex("^([a-zA-Z\\s]{2,28}?)\\s+ko\\s+sms\\s+(?:bhejo|karo)(?:\\s+(?:ke)\\s+(.+))?$", RegexOption.IGNORE_CASE).find(text)
        if (smsMatch != null) {
            val contact = smsMatch.groupValues[1].trim()
            val msg = smsMatch.groupValues[2].trim().ifEmpty { "Hello, please call back when free." }
            return CommandIntentResponse(
                intent = "SEND_SMS",
                targetContact = contact,
                queryOrText = msg,
                requiredPermission = "READ_CONTACTS + SMS Intent",
                needsConfirmation = true,
                confirmationPrompt = reply(
                    lang,
                    "Confirm opening SMS to $contact: \"$msg\"?",
                    "Kya main $contact ko SMS bhejne ke liye composer khol doon: \"$msg\"?"
                ),
                spokenReply = reply(lang, "SMS prepared for $contact. Please confirm.", "$contact ke liye SMS tayyar hai. Confirm karein."),
                detectedLanguage = lang
            )
        }

        // 7. Screen Recording & Screenshot
        if (Regex("\\b(stop|band|end|rok)\\b.*\\b(record|recording)\\b").containsMatchIn(lower) ||
            Regex("\\b(recording)\\b.*\\b(band|stop|rok)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "STOP_RECORDING",
                requiredPermission = "MediaProjection",
                needsConfirmation = false,
                spokenReply = reply(lang, "Stopping screen recording.", "Screen recording band kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(pause)\\b.*\\b(record|recording)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "PAUSE_RECORDING",
                requiredPermission = "MediaProjection",
                needsConfirmation = false,
                spokenReply = reply(lang, "Pausing screen recording.", "Screen recording pause kar di hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(resume)\\b.*\\b(record|recording)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "RESUME_RECORDING",
                requiredPermission = "MediaProjection",
                needsConfirmation = false,
                spokenReply = reply(lang, "Resuming screen recording.", "Screen recording dobara shuru kar di hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(start|begin|shuru|on)\\b.*\\b(screen\\s*record|recording)\\b").containsMatchIn(lower) ||
            Regex("\\b(screen\\s*record|recording)\\b.*\\b(start|shuru)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "START_RECORDING",
                requiredPermission = "MediaProjection + FOREGROUND_SERVICE_MEDIA_PROJECTION",
                needsConfirmation = false,
                spokenReply = reply(lang, "Starting screen recording authorization.", "Screen recording shuru karne ki ijazat maang rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(screenshot|capture\\s*screen|analyze\\s*(?:my\\s*)?screen)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "CAPTURE_SCREENSHOT",
                requiredPermission = "MediaProjection",
                needsConfirmation = false,
                spokenReply = reply(lang, "Requesting screen capture for AI analysis.", "Screen analysis ke liye capture shuru kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        // 8. Accessibility Screen Reading & Navigation (Home + Back + Scroll + Click)
        if (Regex("\\b(read\\s*(?:my\\s*)?screen|what\\s*is\\s*written|explain\\s*this\\s*(?:page|screen)|summarize\\s*(?:the\\s*)?(?:current\\s*)?screen)\\b").containsMatchIn(lower) ||
            Regex("\\b(screen\\s*par|screen\\s*parho|kya\\s*likha|is\\s*page\\s*ko\\s*samjhao)\\b").containsMatchIn(lower) ||
            text.contains("اسکرین") || text.contains("स्क्रीन")
        ) {
            return CommandIntentResponse(
                intent = if (lower.contains("explain") || lower.contains("samjhao")) "EXPLAIN_SCREEN" else "READ_SCREEN",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Reading visible screen content.", "Screen par maujood content parh rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(go\\s*home|home\\s*screen|home\\s*jao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "NAVIGATE_HOME",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Going to Home screen.", "Home screen par ja rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(scroll\\s*down|neeche\\s*scroll|niche\\s*karo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SCROLL_DOWN",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Scrolling down.", "Neeche scroll kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(scroll\\s*up|upar\\s*scroll|oopar\\s*karo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SCROLL_UP",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Scrolling up.", "Upar scroll kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(go\\s*back|navigate\\s*back|peeche\\s*jao|back\\s*jao|wapas\\s*jao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "NAVIGATE_BACK",
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Going back.", "Back ja rahi hoon."),
                detectedLanguage = lang
            )
        }

        val clickMatch = Regex("^(?:click|tap|press|find)\\s+(?:the\\s+)?(.+?)(?:\\s+button)?$", RegexOption.IGNORE_CASE).find(text)
        if (clickMatch != null) {
            val label = clickMatch.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "CLICK_ELEMENT",
                queryOrText = label,
                requiredPermission = "AccessibilityService",
                needsConfirmation = false,
                spokenReply = reply(lang, "Clicking $label.", "$label par click kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        // 9. Incoming Call Controls
        if (Regex("\\b(answer|pick\\s*up|receive|uthao)\\b.*\\b(call)\\b").containsMatchIn(lower) ||
            Regex("\\b(call)\\b.*\\b(receive|uthao|answer)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "ANSWER_CALL",
                requiredPermission = "ANSWER_PHONE_CALLS",
                needsConfirmation = false,
                spokenReply = reply(lang, "Answering incoming call.", "Call receive kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(reject|decline|cut|kaat)\\b.*\\b(call)\\b").containsMatchIn(lower) ||
            Regex("\\b(call)\\b.*\\b(reject|cut|kaat)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "REJECT_CALL",
                requiredPermission = "ANSWER_PHONE_CALLS",
                needsConfirmation = true,
                confirmationPrompt = reply(lang, "Confirm rejecting the call?", "Kya main call reject kar doon? Confirm karein."),
                spokenReply = reply(lang, "Confirm rejecting call.", "Call reject karne ke liye confirm karein."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(end|disconnect|band)\\b.*\\b(call)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "END_CALL",
                requiredPermission = "ANSWER_PHONE_CALLS",
                needsConfirmation = true,
                confirmationPrompt = reply(lang, "Confirm ending the active call?", "Kya main call band kar doon? Confirm karein."),
                spokenReply = reply(lang, "Confirm ending call.", "Call end karne ke liye confirm karein."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(speaker|speakerphone|loudspeaker)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SPEAKERPHONE_ON",
                requiredPermission = "MODIFY_AUDIO_SETTINGS",
                needsConfirmation = false,
                spokenReply = reply(lang, "Turning speakerphone on.", "Speakerphone on kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(tell\\s*(?:the\\s*)?caller|caller\\s*ko\\s*batao).*\\b(busy)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "TELL_CALLER_BUSY",
                requiredPermission = "Telecom / Authorized SMS Notice",
                needsConfirmation = true,
                confirmationPrompt = reply(lang, "Send AI busy notice to caller?", "Kya main caller ko busy SMS notice bhej doon?"),
                spokenReply = reply(lang, "Confirm sending busy notice.", "Caller ko busy notice bhejne ke liye confirm karein."),
                detectedLanguage = lang
            )
        }

        // 10. System Status & Hardware Controls (Battery, DND/Silent, Flashlight, Volume, Media, Photos, Gallery, Contacts, Share)
        if (Regex("\\b(battery|charge|battery\\s*level|battery\\s*percentage|charging)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "CHECK_BATTERY",
                requiredPermission = "BatteryManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Checking battery level.", "Battery status check kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(do\\s*not\\s*disturb|dnd|silent\\s*kar|phone\\s*silent)\\b").containsMatchIn(lower)) {
            val disable = Regex("\\b(off|disable|band|normal)\\b").containsMatchIn(lower)
            return CommandIntentResponse(
                intent = if (disable) "DISABLE_DND" else "ENABLE_DND",
                requiredPermission = "ACCESS_NOTIFICATION_POLICY",
                needsConfirmation = false,
                spokenReply = reply(
                    lang,
                    if (disable) "Disabling Do Not Disturb mode." else "Enabling Do Not Disturb mode.",
                    if (disable) "Do Not Disturb band kar rahi hoon." else "Phone silent / Do Not Disturb on kar rahi hoon."
                ),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(turn\\s*on|on\\s*karo|jalao|enable)\\b.*\\b(flashlight|torch|light)\\b").containsMatchIn(lower) ||
            Regex("\\b(flashlight|torch)\\b.*\\b(on|jalao)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "FLASHLIGHT_ON",
                requiredPermission = "CAMERA",
                needsConfirmation = false,
                spokenReply = reply(lang, "Turning flashlight on.", "Flashlight on kar di hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(turn\\s*off|off\\s*karo|band|bujhao|disable)\\b.*\\b(flashlight|torch|light)\\b").containsMatchIn(lower) ||
            Regex("\\b(flashlight|torch)\\b.*\\b(off|band)\\b").containsMatchIn(lower)
        ) {
            return CommandIntentResponse(
                intent = "FLASHLIGHT_OFF",
                requiredPermission = "CAMERA",
                needsConfirmation = false,
                spokenReply = reply(lang, "Turning flashlight off.", "Flashlight band kar di hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(volume\\s*up|increase\\s*volume|awaz\\s*barhao|awaaz\\s*tez)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "VOLUME_UP",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Increasing volume.", "Volume barha rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(volume\\s*down|decrease\\s*volume|awaz\\s*kam|awaaz\\s*halki)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "VOLUME_DOWN",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Decreasing volume.", "Volume kam kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(pause\\s*(?:music|media|video)|gaana\\s*roko)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "MEDIA_PAUSE",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Pausing media.", "Media pause kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(play\\s*(?:music|media)|resume\\s*music|gaana\\s*chalao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "MEDIA_PLAY",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Playing media.", "Media play kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(next\\s*(?:track|song)|agla\\s*gaana)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "MEDIA_NEXT",
                requiredPermission = "AudioManager",
                needsConfirmation = false,
                spokenReply = reply(lang, "Skipping to next track.", "Next track chala rahi hoon."),
                detectedLanguage = lang
            )
        }

        // 11. Alarms, Timers, Reminders, Notes
        if (Regex("\\b(set\\s*(?:an\\s*)?alarm|alarm\\s*lagao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SET_ALARM",
                queryOrText = text,
                requiredPermission = "SET_ALARM",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Clock to set alarm.", "Alarm set kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(set\\s*(?:a\\s*)?timer|timer\\s*lagao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SET_TIMER",
                queryOrText = text,
                requiredPermission = "SET_ALARM",
                needsConfirmation = false,
                spokenReply = reply(lang, "Starting timer.", "Timer set kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(remind\\s*me|yaad\\s*dilana|reminder\\s*lagao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "ADD_REMINDER",
                queryOrText = text,
                requiredPermission = "EncryptedSharedPreferences (Local)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Reminder saved.", "Reminder save kar diya hai."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(add\\s*note|create\\s*note|note\\s*likho|take\\s*a\\s*note)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "ADD_NOTE",
                queryOrText = text,
                requiredPermission = "EncryptedSharedPreferences (Local)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Note saved.", "Note save kar diya hai."),
                detectedLanguage = lang
            )
        }

        // 12. Web & YouTube search, Camera photo, Gallery, Contacts, App Launch / Close
        val ytMatch = Regex("youtube\\s+(?:kholo\\s+(?:aur\\s+)?search\\s+karo|par\\s+search\\s+karo|search)\\s+(.+)", RegexOption.IGNORE_CASE).find(text)
        if (ytMatch != null) {
            val query = ytMatch.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "YOUTUBE_SEARCH",
                targetApp = "YouTube",
                queryOrText = query,
                requiredPermission = "None (Android Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Searching YouTube for $query.", "YouTube par \"$query\" search kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        val webMatch = Regex("^(?:search\\s+(?:the\\s+)?(?:internet|web|google)\\s+(?:for\\s+)?|google\\s+(?:par\\s+)?search\\s+(?:karo\\s+)?)(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (webMatch != null) {
            val query = webMatch.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "WEB_SEARCH",
                queryOrText = query,
                requiredPermission = "None (Browser Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Searching the web for $query.", "Internet par \"$query\" search kar rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(capture\\s*(?:a\\s*)?photo|take\\s*(?:a\\s*)?(?:photo|picture)|photo\\s*kheencho|tasveer\\s*banao)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "CAPTURE_PHOTO",
                requiredPermission = "Camera Intent",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening camera to capture a photo.", "Photo capture karne ke liye Camera khol rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(open\\s*gallery|open\\s*photos|gallery\\s*kholo|photos\\s*kholo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "OPEN_GALLERY",
                targetApp = "Gallery",
                requiredPermission = "READ_MEDIA_IMAGES / Intent",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Gallery.", "Gallery khol rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(open\\s*contacts|contacts\\s*kholo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "OPEN_CONTACTS",
                targetApp = "Contacts",
                requiredPermission = "READ_CONTACTS / Intent",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Contacts.", "Contacts khol rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(share\\s*file|file\\s*share)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "SHARE_FILE",
                requiredPermission = "Explicit User Share Sheet",
                needsConfirmation = true,
                confirmationPrompt = reply(lang, "Open Android Share Sheet? Personal files are only shared when you select them.", "Kya main Android Share Sheet khol doon? Confirm karein."),
                spokenReply = reply(lang, "Confirm opening Android Share Sheet.", "Share sheet kholne ke liye confirm karein."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(open\\s*settings|settings\\s*kholo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "OPEN_SETTINGS",
                targetApp = "Settings",
                requiredPermission = "None (Android Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Settings.", "Settings khol rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(open\\s*camera|camera\\s*kholo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "OPEN_CAMERA",
                targetApp = "Camera",
                requiredPermission = "None (Android Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Camera.", "Camera khol rahi hoon."),
                detectedLanguage = lang
            )
        }

        if (Regex("\\b(open\\s*dialer|dialer\\s*kholo)\\b").containsMatchIn(lower)) {
            return CommandIntentResponse(
                intent = "OPEN_DIALER",
                targetApp = "Dialer",
                requiredPermission = "None (Android Intent)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening Dialer.", "Phone Dialer khol rahi hoon."),
                detectedLanguage = lang
            )
        }

        val closeAppEn = Regex("^close\\s+([a-zA-Z0-9\\s]+)$", RegexOption.IGNORE_CASE).find(text)
            ?: Regex("^([a-zA-Z0-9\\s]+?)\\s+(?:band\\s*karo|close\\s*karo)$", RegexOption.IGNORE_CASE).find(text)
        if (closeAppEn != null) {
            val target = closeAppEn.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "CLOSE_APP",
                targetApp = target,
                requiredPermission = "AccessibilityService (HOME)",
                needsConfirmation = false,
                spokenReply = reply(lang, "Returning to Home to leave $target.", "$target se bahar aa kar Home screen par ja rahi hoon."),
                detectedLanguage = lang
            )
        }

        val openEn = Regex("^(?:open|launch|mujhe)\\s+([a-zA-Z0-9\\s]+?)(?:\\s+kholo)?$", RegexOption.IGNORE_CASE).find(text)
        if (openEn != null) {
            val app = openEn.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "OPEN_APP",
                targetApp = app,
                requiredPermission = "QUERY_ALL_PACKAGES / LAUNCHER_QUERY",
                needsConfirmation = false,
                spokenReply = reply(lang, "Opening $app.", "$app khol rahi hoon."),
                detectedLanguage = lang
            )
        }

        val openUr = Regex("^([a-zA-Z0-9\\s]+?)\\s+(?:kholo|open\\s*karo|chalao)$", RegexOption.IGNORE_CASE).find(text)
        if (openUr != null) {
            val app = openUr.groupValues[1].trim()
            return CommandIntentResponse(
                intent = "OPEN_APP",
                targetApp = app,
                requiredPermission = "QUERY_ALL_PACKAGES / LAUNCHER_QUERY",
                needsConfirmation = false,
                spokenReply = "$app khol rahi hoon.",
                detectedLanguage = lang
            )
        }

        return null
    }

    fun isLikelyDeviceAction(rawText: String, customWakePhrase: String = ""): Boolean {
        val (_, stripped) = stripWakePrefix(rawText, customWakePhrase)
        val lower = stripped.trim().lowercase(Locale.ROOT)
        if (lower.isEmpty()) return false
        if (Regex("^(hi|hello|hey|salam|assalamualaikum|kya haal|kaise ho|how are you|who are you|what is|explain|tell me|help me|aaj ka mausam|weather)\\b").containsMatchIn(lower)) {
            return false
        }
        return Regex("\\b(open|close|kholo|launch|scroll|click|tap|record|recording|screenshot|screen|whatsapp|message|reply|call|speaker|flashlight|torch|volume|alarm|timer|camera|dialer|settings|youtube|facebook|tiktok|gallery|photos|contacts|battery|silent|dnd|disturb|sms|search|share|mute|pause|play|remind|note|home|notifications)\\b").containsMatchIn(lower)
    }
}
