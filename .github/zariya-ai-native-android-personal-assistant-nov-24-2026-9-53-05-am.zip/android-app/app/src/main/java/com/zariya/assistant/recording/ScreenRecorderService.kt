package com.zariya.assistant.recording

import android.app.Activity
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import androidx.core.app.NotificationCompat
import com.zariya.assistant.MainActivity
import com.zariya.assistant.ZariyaApplication
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class RecordingStatus { IDLE, RECORDING, PAUSED }

/**
 * Native MediaProjection screen recording & frame capture service.
 * Never records silently: requires explicit MediaProjection user authorization intent
 * and displays a persistent foreground recording indicator notification.
 */
class ScreenRecorderService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var imageReader: ImageReader? = null
    private var outputUri: Uri? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_RECORDING -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                val withAudio = intent.getBooleanExtra(EXTRA_WITH_MIC, false)
                if (resultCode == Activity.RESULT_OK && data != null) {
                    promoteForeground("Recording screen...")
                    startRecording(resultCode, data, withAudio)
                } else {
                    stopSelf()
                }
            }

            ACTION_CAPTURE_FRAME -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                if (resultCode == Activity.RESULT_OK && data != null) {
                    promoteForeground("Capturing screen frame for AI analysis...")
                    captureSingleFrame(resultCode, data)
                } else {
                    stopSelf()
                }
            }

            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP -> stopRecordingAndRelease()
        }
        return START_NOT_STICKY
    }

    private fun promoteForeground(statusText: String) {
        val notification = buildNotification(statusText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startRecording(resultCode: Int, data: Intent, withMic: Boolean) {
        val projectionManager = getSystemService(MediaProjectionManager::class.java)
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        val metrics = resources.displayMetrics
        val width = (metrics.widthPixels / 2) * 2
        val height = (metrics.heightPixels / 2) * 2
        val density = metrics.densityDpi

        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(this)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "SMW_AI_Rec_$timestamp.mp4"

        if (withMic) {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
        }
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        if (withMic) {
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        }
        recorder.setVideoSize(width, height)
        recorder.setVideoFrameRate(30)
        recorder.setVideoEncodingBitRate(4_000_000)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ZariyaRecordings")
            }
            outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            val pfd = outputUri?.let { contentResolver.openFileDescriptor(it, "w") }
            if (pfd != null) {
                recorder.setOutputFile(pfd.fileDescriptor)
            }
        } else {
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ZariyaRecordings").apply { mkdirs() }
            val file = File(dir, fileName)
            outputUri = Uri.fromFile(file)
            recorder.setOutputFile(file.absolutePath)
        }

        recorder.prepare()
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ZariyaScreenRecorder",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            recorder.surface,
            null,
            null
        )
        recorder.start()
        mediaRecorder = recorder
        _status.value = RecordingStatus.RECORDING
        _lastSavedPath.value = outputUri?.toString()
    }

    private fun captureSingleFrame(resultCode: Int, data: Intent) {
        val projectionManager = getSystemService(MediaProjectionManager::class.java)
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels / 2
        val height = metrics.heightPixels / 2

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ZariyaScreenSnapshot",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )

        Handler(Looper.getMainLooper()).postDelayed({
            val image = imageReader?.acquireLatestImage()
            if (image != null) {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                val out = ByteArrayOutputStream()
                cropped.compress(Bitmap.CompressFormat.JPEG, 78, out)
                _latestFrameBase64.value = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                image.close()
            }
            stopRecordingAndRelease()
        }, 450)
    }

    private fun pauseRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && _status.value == RecordingStatus.RECORDING) {
            mediaRecorder?.pause()
            _status.value = RecordingStatus.PAUSED
        }
    }

    private fun resumeRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && _status.value == RecordingStatus.PAUSED) {
            mediaRecorder?.resume()
            _status.value = RecordingStatus.RECORDING
        }
    }

    private fun stopRecordingAndRelease() {
        runCatching {
            if (_status.value != RecordingStatus.IDLE) {
                mediaRecorder?.stop()
            }
        }
        runCatching { mediaRecorder?.release() }
        mediaRecorder = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.stop()
        mediaProjection = null
        _status.value = RecordingStatus.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, ScreenRecorderService::class.java).apply { action = ACTION_STOP }, PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, ZariyaApplication.CHANNEL_SCREEN_RECORDING)
            .setContentTitle("SMW AI Screen Capture")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()
    }

    companion object {
        const val ACTION_START_RECORDING = "com.zariya.assistant.recording.START"
        const val ACTION_CAPTURE_FRAME = "com.zariya.assistant.recording.CAPTURE_FRAME"
        const val ACTION_PAUSE = "com.zariya.assistant.recording.PAUSE"
        const val ACTION_RESUME = "com.zariya.assistant.recording.RESUME"
        const val ACTION_STOP = "com.zariya.assistant.recording.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_WITH_MIC = "with_mic"
        private const val NOTIFICATION_ID = 1002

        private val _status = MutableStateFlow(RecordingStatus.IDLE)
        val status: StateFlow<RecordingStatus> = _status

        private val _lastSavedPath = MutableStateFlow<String?>(null)
        val lastSavedPath: StateFlow<String?> = _lastSavedPath

        private val _latestFrameBase64 = MutableStateFlow<String?>(null)
        val latestFrameBase64: StateFlow<String?> = _latestFrameBase64

        fun clearCapturedFrame() {
            _latestFrameBase64.value = null
        }

        fun startRecording(context: Context, resultCode: Int, data: Intent, withMic: Boolean) {
            val intent = Intent(context, ScreenRecorderService::class.java).apply {
                action = ACTION_START_RECORDING
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
                putExtra(EXTRA_WITH_MIC, withMic)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun captureFrame(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, ScreenRecorderService::class.java).apply {
                action = ACTION_CAPTURE_FRAME
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun sendControl(context: Context, action: String) {
            context.startService(Intent(context, ScreenRecorderService::class.java).apply {
                this.action = action
            })
        }
    }
}
