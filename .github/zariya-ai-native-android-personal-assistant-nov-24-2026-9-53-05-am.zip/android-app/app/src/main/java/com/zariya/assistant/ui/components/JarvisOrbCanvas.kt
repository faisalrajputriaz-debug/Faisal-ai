package com.zariya.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.zariya.assistant.data.model.OrbState
import com.zariya.assistant.ui.theme.ElectricBlue
import com.zariya.assistant.ui.theme.SkyCyan
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisOrbCanvas(
    state: OrbState,
    rmsLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "jarvis_orb")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_phase"
    )

    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_pulse"
    )

    val ringColor = when (state) {
        OrbState.IDLE -> ElectricBlue.copy(alpha = 0.7f)
        OrbState.LISTENING -> SkyCyan
        OrbState.THINKING -> Color(0xFF60A5FA)
        OrbState.SPEAKING -> ElectricBlue
    }

    Canvas(
        modifier = modifier
            .size(210.dp)
            .clickable(onClick = onClick)
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val baseRadius = size.minDimension * 0.34f * (if (state == OrbState.IDLE) 1f else pulse)
        val dynamicBoost = if (state == OrbState.LISTENING || state == OrbState.SPEAKING) rmsLevel * 18f else 0f

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(ringColor.copy(alpha = 0.25f), Color.Transparent),
                center = center,
                radius = baseRadius * 1.45f
            ),
            center = center,
            radius = baseRadius * 1.45f
        )

        drawCircle(
            color = ringColor,
            radius = baseRadius + dynamicBoost,
            center = center,
            style = Stroke(width = 3.5f)
        )

        val bars = 36
        for (i in 0 until bars) {
            val angle = (i.toFloat() / bars) * (2f * Math.PI).toFloat()
            val wave = sin(angle * 4f + phase) * when (state) {
                OrbState.IDLE -> 4f
                OrbState.LISTENING -> 10f + rmsLevel * 22f
                OrbState.THINKING -> 14f
                OrbState.SPEAKING -> 18f
            }
            val startR = baseRadius + 10f
            val endR = startR + 10f + kotlin.math.abs(wave)
            val start = Offset(center.x + cos(angle) * startR, center.y + sin(angle) * startR)
            val end = Offset(center.x + cos(angle) * endR, center.y + sin(angle) * endR)

            drawLine(
                color = if (i % 2 == 0) SkyCyan else ElectricBlue,
                start = start,
                end = end,
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )
        }
    }
}
