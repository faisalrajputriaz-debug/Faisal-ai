package com.zariya.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zariya.assistant.accessibility.ZariyaAccessibilityService
import com.zariya.assistant.calls.ZariyaCallScreeningService
import com.zariya.assistant.notifications.ZariyaNotificationListenerService
import com.zariya.assistant.recording.RecordingStatus
import com.zariya.assistant.recording.ScreenRecorderService
import com.zariya.assistant.ui.ZariyaViewModel
import com.zariya.assistant.ui.theme.ElectricBlue
import com.zariya.assistant.ui.theme.HairlineBorder
import com.zariya.assistant.ui.theme.ObsidianBlack
import com.zariya.assistant.ui.theme.ObsidianSurface
import com.zariya.assistant.ui.theme.SkyCyan
import com.zariya.assistant.ui.theme.StatusError
import com.zariya.assistant.ui.theme.StatusNominal
import com.zariya.assistant.ui.theme.TextMuted
import com.zariya.assistant.ui.theme.TextPrimary

@Composable
fun AutomationHubScreen(
    viewModel: ZariyaViewModel,
    onRequestScreenRecord: () -> Unit,
    onRequestScreenSnapshot: () -> Unit
) {
    val context = LocalContext.current
    val accessibilityConnected by ZariyaAccessibilityService.isConnected.collectAsState()
    val latestScreen by ZariyaAccessibilityService.latestSnapshot.collectAsState()
    val recordingStatus by ScreenRecorderService.status.collectAsState()
    val whatsappConnected by ZariyaNotificationListenerService.isConnected.collectAsState()
    val whatsappMessages by ZariyaNotificationListenerService.messages.collectAsState()
    val callHistory by ZariyaCallScreeningService.callHistory.collectAsState()
    val dailyTasks by viewModel.dailyTasks.collectAsState()

    var autoReplyRule by remember { mutableStateOf(viewModel.memory.autoReplyRule) }
    var callConfig by remember { mutableStateOf(viewModel.memory.callAssistantConfig) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Device & Automation Controls", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)

        // 1. Screen Reading Card
        SectionSurface("Accessibility Screen Reader") {
            Text(
                text = if (accessibilityConnected) "AccessibilityService Active" else "AccessibilityService Disabled — enable in Permissions tab",
                color = if (accessibilityConnected) StatusNominal else StatusError,
                fontSize = 12.sp
            )
            latestScreen?.let { snap ->
                Text("Foreground App: ${snap.appTitle} (${snap.visibleTexts.size} nodes)", color = TextMuted, fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { viewModel.sendCommandOrChat("Read my screen") },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                ) { Text("Read Screen") }
                OutlinedButton(
                    onClick = onRequestScreenSnapshot,
                    border = BorderStroke(1.dp, HairlineBorder)
                ) { Text("Analyze Pixels", color = TextPrimary) }
            }
        }

        // 2. MediaProjection Screen Recording
        SectionSurface("MediaProjection Screen Recorder") {
            Text("Status: ${recordingStatus.name}", color = SkyCyan, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (recordingStatus == RecordingStatus.IDLE) {
                    Button(
                        onClick = onRequestScreenRecord,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                    ) { Text("Start Recording") }
                } else {
                    Button(
                        onClick = {
                            val act = if (recordingStatus == RecordingStatus.RECORDING) ScreenRecorderService.ACTION_PAUSE else ScreenRecorderService.ACTION_RESUME
                            ScreenRecorderService.sendControl(context, act)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                    ) { Text(if (recordingStatus == RecordingStatus.RECORDING) "Pause" else "Resume") }
                    OutlinedButton(
                        onClick = { ScreenRecorderService.sendControl(context, ScreenRecorderService.ACTION_STOP) },
                        border = BorderStroke(1.dp, HairlineBorder)
                    ) { Text("Stop", color = StatusError) }
                }
            }
        }

        // 3. WhatsApp Notification Reader & Auto-Reply
        SectionSurface("WhatsApp Notification & Auto-Reply") {
            Text(
                text = if (whatsappConnected) "NotificationListener Connected (${whatsappMessages.size} captured)" else "Notification Access Not Granted",
                color = if (whatsappConnected) StatusNominal else StatusError,
                fontSize = 12.sp
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Auto-Reply Active", color = TextPrimary, fontSize = 14.sp)
                Switch(
                    checked = autoReplyRule.enabled,
                    onCheckedChange = {
                        autoReplyRule = autoReplyRule.copy(enabled = it)
                        viewModel.updateAutoReplyRule(autoReplyRule)
                    }
                )
            }
            Text("Template: \"${autoReplyRule.activeTemplate}\"", color = TextMuted, fontSize = 12.sp)
            whatsappMessages.take(3).forEach { msg ->
                Text(
                    text = "${msg.senderName}${if (msg.isUrgent) " [URGENT]" else ""}: ${msg.messageText}",
                    color = TextPrimary,
                    fontSize = 12.sp
                )
            }
        }

        // 4. Call Assistant
        SectionSurface("Telecom Call Screening & Hands-Free") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Announce Caller Aloud", color = TextPrimary, fontSize = 14.sp)
                Switch(
                    checked = callConfig.announceCallerAloud,
                    onCheckedChange = {
                        callConfig = callConfig.copy(announceCallerAloud = it)
                        viewModel.updateCallConfig(callConfig)
                    }
                )
            }
            Text("AI Disclosure: \"${callConfig.defaultBusyNotice}\"", color = TextMuted, fontSize = 12.sp)
            Text("Recent Screened Calls: ${callHistory.size}", color = SkyCyan, fontSize = 12.sp)
        }

        // 5. Daily Notes & Reminders
        SectionSurface("Daily Assistant Tasks (${dailyTasks.size})") {
            if (dailyTasks.isEmpty()) {
                Text("Say \"Remind me...\" or \"Note likho...\" to add items.", color = TextMuted, fontSize = 12.sp)
            } else {
                dailyTasks.take(5).forEach { item ->
                    Text("${item.type.uppercase()}: ${item.title}", color = TextPrimary, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionSurface(title: String, content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ObsidianSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, HairlineBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            content()
        }
    }
}
