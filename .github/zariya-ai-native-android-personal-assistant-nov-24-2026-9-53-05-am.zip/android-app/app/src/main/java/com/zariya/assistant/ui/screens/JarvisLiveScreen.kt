package com.zariya.assistant.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zariya.assistant.R
import com.zariya.assistant.data.model.OrbState
import com.zariya.assistant.ui.ZariyaViewModel
import com.zariya.assistant.ui.theme.ElectricBlue
import com.zariya.assistant.ui.theme.ObsidianBlack
import com.zariya.assistant.ui.theme.SkyCyan
import com.zariya.assistant.ui.theme.TextPrimary
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

@Composable
fun JarvisLiveScreen(
    viewModel: ZariyaViewModel,
    onMicClick: () -> Unit,
    onOpenChat: () -> Unit
) {
    val orbState by viewModel.orbState.collectAsState()
    val rmsLevel by viewModel.voiceEngine.rmsLevel.collectAsState()
    val partialTranscript by viewModel.voiceEngine.partialTranscript.collectAsState()
    val messages by viewModel.messages.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.refreshBackendStatus()
    }

    val pulseTransition = rememberInfiniteTransition(label = "smwNeonPulse")
    val pulsePhase by pulseTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulsePhase"
    )

    val latestAssistantReply = messages.lastOrNull { it.role == "assistant" }?.text
    val captionText = when {
        orbState == OrbState.LISTENING && partialTranscript.isNotBlank() -> "\"$partialTranscript\""
        orbState == OrbState.LISTENING -> "Listening..."
        orbState == OrbState.THINKING -> "Thinking..."
        orbState == OrbState.SPEAKING && !latestAssistantReply.isNullOrBlank() -> latestAssistantReply
        partialTranscript.isNotBlank() -> partialTranscript
        else -> null
    }

    val isActiveAudio = orbState == OrbState.LISTENING || orbState == OrbState.SPEAKING
    val haloScale = when (orbState) {
        OrbState.LISTENING -> 1.06f + (rmsLevel * 0.18f)
        OrbState.SPEAKING -> 1.04f + abs(sin(pulsePhase)) * 0.14f
        OrbState.THINKING -> 1.03f
        OrbState.IDLE -> 1.0f + abs(sin(pulsePhase * 0.5f)) * 0.04f
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        // Full-Screen Centered Sidhu Moose Wala SMW AI Avatar Background
        Image(
            painter = painterResource(id = R.drawable.smw_ai_avatar),
            contentDescription = "SMW AI Sidhu Moose Wala Avatar",
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = Modifier.fillMaxSize()
        )

        // Bottom Obsidian-Black & Electric-Blue Neon Atmospheric Scrim
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(235.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            ObsidianBlack.copy(alpha = 0.88f),
                            ObsidianBlack
                        )
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            ElectricBlue.copy(alpha = 0.34f),
                            Color.Transparent
                        ),
                        radius = 520f
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!captionText.isNullOrBlank()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    color = Color(0xCC040B1B),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.38f))
                ) {
                    Text(
                        text = captionText,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
                Spacer(modifier = Modifier.height(18.dp))
            }

            // ONLY TWO CONTROLS: Left Chat Button + Central Animated Microphone Button with Symmetric Waveform
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                // Control 1: Text Chat Button (Left)
                Button(
                    onClick = onOpenChat,
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xDA051029),
                        contentColor = TextPrimary
                    ),
                    border = BorderStroke(1.5.dp, SkyCyan.copy(alpha = 0.78f)),
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .width(74.dp)
                        .height(52.dp)
                        .shadow(14.dp, RoundedCornerShape(16.dp), spotColor = ElectricBlue)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Open text chat",
                        tint = TextPrimary,
                        modifier = Modifier.size(26.dp)
                    )
                }

                // Control 2: Symmetric Electric-Blue Waveform + Central Microphone Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Left Waveform Bars
                    Row(
                        modifier = Modifier.height(42.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 6 downTo 0) {
                            val falloff = 1f - (i / 6f) * 0.62f
                            val amp = if (isActiveAudio) {
                                max(
                                    0.22f,
                                    (0.32f + rmsLevel * 0.68f) * falloff *
                                        (0.55f + 0.45f * abs(sin(pulsePhase * 2f + i * 0.7f)))
                                )
                            } else {
                                0.16f + falloff * (0.20f + 0.12f * abs(sin(pulsePhase + i * 0.5f)))
                            }
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height((6f + 34f * amp).dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(SkyCyan, ElectricBlue)
                                        )
                                    )
                            )
                        }
                    }

                    // Glowing Halo + Mic Button
                    Box(
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(102.dp)
                                .scale(haloScale)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            SkyCyan.copy(alpha = if (isActiveAudio) 0.55f else 0.30f),
                                            ElectricBlue.copy(alpha = 0.12f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )

                        Button(
                            onClick = onMicClick,
                            contentPadding = PaddingValues(0.dp),
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF071940),
                                contentColor = TextPrimary
                            ),
                            border = BorderStroke(
                                width = 2.5.dp,
                                color = if (orbState == OrbState.LISTENING) Color(0xFF7DD3FC) else SkyCyan
                            ),
                            modifier = Modifier
                                .size(82.dp)
                                .shadow(24.dp, CircleShape, spotColor = SkyCyan)
                        ) {
                            Icon(
                                imageVector = if (orbState == OrbState.LISTENING) {
                                    Icons.Default.MicOff
                                } else {
                                    Icons.Default.Mic
                                },
                                contentDescription = if (orbState == OrbState.LISTENING) {
                                    "Stop listening"
                                } else {
                                    "Start voice assistant"
                                },
                                tint = TextPrimary,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }

                    // Right Waveform Bars
                    Row(
                        modifier = Modifier.height(42.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 0..6) {
                            val falloff = 1f - (i / 6f) * 0.62f
                            val amp = if (isActiveAudio) {
                                max(
                                    0.22f,
                                    (0.32f + rmsLevel * 0.68f) * falloff *
                                        (0.55f + 0.45f * abs(sin(pulsePhase * 2f + i * 0.7f + 1.2f)))
                                )
                            } else {
                                0.16f + falloff * (0.20f + 0.12f * abs(sin(pulsePhase + i * 0.5f + 0.9f)))
                            }
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height((6f + 34f * amp).dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(SkyCyan, ElectricBlue)
                                        )
                                    )
                            )
                        }
                    }
                }
            }
        }
    }
}
