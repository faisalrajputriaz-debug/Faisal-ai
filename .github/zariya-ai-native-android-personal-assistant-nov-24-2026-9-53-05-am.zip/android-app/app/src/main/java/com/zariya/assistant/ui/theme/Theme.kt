package com.zariya.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF05070B)
val ObsidianSurface = Color(0xFF0B101B)
val ObsidianElevated = Color(0xFF111827)
val HairlineBorder = Color(0xFF1E293B)
val ElectricBlue = Color(0xFF2563EB)
val SkyCyan = Color(0xFF38BDF8)
val TextPrimary = Color(0xFFF1F5F9)
val TextMuted = Color(0xFF94A3B8)
val StatusNominal = Color(0xFF10B981)
val StatusWarning = Color(0xFFF59E0B)
val StatusError = Color(0xFFEF4444)

private val ZariyaColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    secondary = SkyCyan,
    onSecondary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianElevated,
    onSurfaceVariant = TextMuted,
    outline = HairlineBorder,
    error = StatusError
)

@Composable
fun ZariyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ZariyaColorScheme,
        content = content
    )
}
