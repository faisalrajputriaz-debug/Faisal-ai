import { useCallback, useEffect, useRef, useState } from 'react';
import { MessageCircleMore, Mic, MicOff, Send, X } from 'lucide-react';
import {
  AssistantMemory,
  AutoReplyRule,
  CallConfig,
  CallSession,
  ChatEntry,
  DailyTask,
  DeviceHardwareState,
  OrbState,
  PermissionRecord,
  TaskExecutionReport,
  WhatsAppMessage,
} from './types/assistant';
import {
  isLikelyDeviceAction,
  parseLocalCommand,
  resolveKnownContacts,
  stripWakePrefix,
} from './utils/localCommandParser';
import {
  AuthenticatedProfile,
  getGreetingFirstName,
  initAuth,
} from './lib/googleAuth';

const INITIAL_PERMISSIONS: PermissionRecord[] = [
  {
    id: 'mic',
    title: 'Microphone (RECORD_AUDIO)',
    androidPermission: 'android.permission.RECORD_AUDIO',
    category: 'Runtime',
    reason: 'Captures voice commands only when you tap Speak or enable Hands-Free Live Mode.',
    granted: true,
  },
  {
    id: 'accessibility',
    title: 'Accessibility Service (Screen Reader & Control)',
    androidPermission: 'android.permission.BIND_ACCESSIBILITY_SERVICE',
    category: 'Special System Access',
    reason: 'Reads visible non-protected text, summarizes screens, scrolls, and clicks supported elements.',
    granted: true,
  },
  {
    id: 'notif_listener',
    title: 'Notification Listener (WhatsApp Reader & Reply)',
    androidPermission: 'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE',
    category: 'Special System Access',
    reason: 'Reads authorized WhatsApp notifications and executes RemoteInput replies.',
    granted: true,
  },
  {
    id: 'mediaprojection',
    title: 'Screen Capture (MediaProjection)',
    androidPermission: 'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION',
    category: 'Special System Access',
    reason: 'Records the screen or captures a frame for AI analysis only after explicit consent.',
    granted: true,
  },
  {
    id: 'phone',
    title: 'Phone State & Answer Calls',
    androidPermission: 'android.permission.ANSWER_PHONE_CALLS',
    category: 'Runtime',
    reason: 'Enables voice-controlled call answering, rejecting, and ending via TelecomManager.',
    granted: true,
  },
  {
    id: 'camera',
    title: 'Camera & Flashlight',
    androidPermission: 'android.permission.CAMERA',
    category: 'Runtime',
    reason: 'Toggles the hardware torch via CameraManager and opens Camera.',
    granted: true,
  },
];

const DEFAULT_MEMORY: AssistantMemory = {
  assistantName: 'SMW AI',
  wakePhrase: 'Hey AI',
  wakeWordRequired: false,
  voiceGender: 'MALE',
  voicePersona: 'punjabi_legend',
  preferredLanguage: 'auto',
  priorityContacts: ['Ali', 'Ammi', 'Office Manager'],
  templates: [
    'Assalamualaikum, main abhi kaam kar raha hoon. Main baad mein aapse baat karta hoon.',
    'Main abhi busy hoon, aapka message mil gaya hai. Main free hote hi reply karunga.',
    'Main abhi available nahi hoon. Zaroori baat ho to message chhor dein.',
  ],
  readWhatsAppAloud: true,
  recordMicWithScreen: false,
};

const STORAGE_KEY = 'faizan_ai_memory_v1';
const SMW_AVATAR_BG = '/assets/aistudio/file_00000000e97c8211a3f2c82e9e614608_cfee5c79.png';

function formatTime(): string {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

async function safeFetchJson<T = Record<string, unknown>>(
  url: string,
  init: RequestInit,
  timeoutMs = 25000,
): Promise<{ ok: boolean; status: number; data: T & { error?: string } }> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    const rawText = await res.text();
    let parsed: unknown = {};
    if (rawText) {
      try {
        parsed = JSON.parse(rawText);
      } catch {
        parsed = { error: res.ok ? 'Invalid response format from server.' : `Server error (${res.status}).` };
      }
    }
    const data =
      parsed && typeof parsed === 'object' ? (parsed as T & { error?: string }) : ({} as T & { error?: string });
    return { ok: res.ok, status: res.status, data };
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Request timed out. Please check your connection and try again.');
    }
    throw err;
  } finally {
    window.clearTimeout(timer);
  }
}

export default function App() {
  const [orbState, setOrbState] = useState<OrbState>('IDLE');
  const [chatOpen, setChatOpen] = useState(false);
  const [partialTranscript, setPartialTranscript] = useState('');
  const [input, setInput] = useState('');
  const [authProfile, setAuthProfile] = useState<AuthenticatedProfile | null>(null);

  const [memory] = useState<AssistantMemory>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return DEFAULT_MEMORY;
      const parsed = JSON.parse(saved) as Partial<AssistantMemory> | null;
      if (!parsed || typeof parsed !== 'object') return DEFAULT_MEMORY;
      return {
        ...DEFAULT_MEMORY,
        ...parsed,
        assistantName: 'SMW AI',
        voiceGender: 'MALE',
        voicePersona: 'punjabi_legend',
      };
    } catch {
      return DEFAULT_MEMORY;
    }
  });

  const [permissions, setPermissions] = useState<PermissionRecord[]>(INITIAL_PERMISSIONS);
  const [, setLatestReport] = useState<TaskExecutionReport | null>(null);
  const [messages, setMessages] = useState<ChatEntry[]>([]);

  const [hardware, setHardware] = useState<DeviceHardwareState>({
    flashlightOn: false,
    volumePercent: 65,
    mediaPlaying: false,
    mediaTrack: 'Ambient Focus Mix',
    screenScrollIndex: 0,
    activeScreenKey: 'whatsapp',
    batteryPercent: null,
    batteryCharging: false,
  });

  const [, setDailyTasks] = useState<DailyTask[]>([
    {
      id: 't-1',
      type: 'reminder',
      title: 'Send Q4 presentation deck to Ali',
      detail: '4:00 PM today',
      createdAt: formatTime(),
    },
  ]);

  const [whatsappMessages, setWhatsappMessages] = useState<WhatsAppMessage[]>([
    {
      id: 'wa-1',
      appSource: 'WhatsApp',
      sender: 'Ali',
      text: 'Salam bhai, client presentation 4 PM ko confirm hui hai. Urgent deck bhej dein.',
      timestamp: formatTime(),
      isUrgent: true,
      urgencyReason: 'Time-sensitive client presentation request.',
      aiDraftReply: 'Walaikum Assalam Ali, deck 15 minutes mein bhej raha hoon.',
      autoReplied: false,
    },
  ]);

  const [autoReplyRule] = useState<AutoReplyRule>({
    enabled: false,
    audience: 'SELECTED_CONTACTS_ONLY',
    activeTemplate: DEFAULT_MEMORY.templates[0],
    scheduleEnabled: false,
    startHour: 9,
    endHour: 18,
    cooldownMinutes: 30,
    askBeforeUnconfigured: true,
  });

  const [callConfig, setCallConfig] = useState<CallConfig>({
    enabled: true,
    announceCallerAloud: true,
    autoAnswerSelectedContacts: false,
    handsFreeMode: false,
    speakerphoneActive: false,
    busyNotice:
      'Hello, I am the owner’s AI assistant. The owner is currently busy and will contact you later.',
  });

  const [activeCall, setActiveCall] = useState<CallSession | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioUrlRef = useRef<string | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const speechRafRef = useRef<number | null>(null);
  const speechLevelRef = useRef<number>(0);
  const recognitionRef = useRef<unknown>(null);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const micHaloRef = useRef<HTMLDivElement | null>(null);
  const stageAuraRef = useRef<HTMLDivElement | null>(null);
  const waveBarRefs = useRef<Array<HTMLSpanElement | null>>([]);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, orbState, chatOpen]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(memory));
    } catch {
      // Ignore storage restrictions
    }
  }, [memory]);

  useEffect(() => {
    const unsubscribe = initAuth(
      (profile) => {
        setAuthProfile(profile);
      },
      () => {
        setAuthProfile(null);
      },
    );
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    interface BatteryManagerLike extends EventTarget {
      level: number;
      charging: boolean;
    }
    const nav = navigator as Navigator & {
      getBattery?: () => Promise<BatteryManagerLike>;
    };
    if (typeof nav.getBattery !== 'function') return;

    let batteryRef: BatteryManagerLike | null = null;
    let active = true;

    const syncBattery = () => {
      if (!active || !batteryRef) return;
      setHardware((prev) => ({
        ...prev,
        batteryPercent: Math.round(batteryRef!.level * 100),
        batteryCharging: Boolean(batteryRef!.charging),
      }));
    };

    nav
      .getBattery()
      .then((battery) => {
        if (!active) return;
        batteryRef = battery;
        syncBattery();
        battery.addEventListener('levelchange', syncBattery);
        battery.addEventListener('chargingchange', syncBattery);
      })
      .catch(() => {
        // Battery Status API unavailable
      });

    return () => {
      active = false;
      if (batteryRef) {
        batteryRef.removeEventListener('levelchange', syncBattery);
        batteryRef.removeEventListener('chargingchange', syncBattery);
      }
    };
  }, []);

  const greetingName = getGreetingFirstName(authProfile);

  const isGranted = useCallback(
    (id: string) => permissions.find((p) => p.id === id)?.granted ?? false,
    [permissions],
  );

  const stopSpeechMeter = useCallback(() => {
    if (speechRafRef.current !== null) {
      window.cancelAnimationFrame(speechRafRef.current);
      speechRafRef.current = null;
    }
    speechLevelRef.current = 0;
  }, []);

  const ensureAudioContext = useCallback((): AudioContext | null => {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;
    if (!audioContextRef.current) {
      audioContextRef.current = new AudioCtx();
    }
    if (audioContextRef.current.state === 'suspended') {
      void audioContextRef.current.resume().catch(() => {});
    }
    return audioContextRef.current;
  }, []);

  const interruptSpeech = useCallback(() => {
    stopSpeechMeter();
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setOrbState((prev) => (prev === 'SPEAKING' ? 'IDLE' : prev));
  }, [stopSpeechMeter]);

  useEffect(() => {
    return () => {
      stopSpeechMeter();
      if (audioUrlRef.current) {
        URL.revokeObjectURL(audioUrlRef.current);
        audioUrlRef.current = null;
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        void audioContextRef.current.close().catch(() => {});
      }
    };
  }, [stopSpeechMeter]);

  const speakText = useCallback(
    async (text: string) => {
      if (!text.trim()) return;
      interruptSpeech();
      setOrbState('SPEAKING');
      const activePersona = memory.voicePersona || 'punjabi_legend';
      const isLegend = activePersona === 'punjabi_legend' && memory.voiceGender !== 'FEMALE';

      try {
        const { ok, data } = await safeFetchJson<{ audioBase64?: string; mimeType?: string }>(
          '/api/ai/tts',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              text,
              gender: memory.voiceGender,
              persona: activePersona,
              language: memory.preferredLanguage,
            }),
          },
          22000,
        );
        if (ok && data.audioBase64) {
          const binary = window.atob(data.audioBase64);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
          }
          const wavBlob = new Blob([bytes], { type: data.mimeType || 'audio/wav' });
          const objectUrl = URL.createObjectURL(wavBlob);
          audioUrlRef.current = objectUrl;

          const audio = new Audio(objectUrl);
          audioRef.current = audio;

          const cleanupAudio = () => {
            stopSpeechMeter();
            if (audioUrlRef.current === objectUrl) {
              URL.revokeObjectURL(objectUrl);
              audioUrlRef.current = null;
            }
            if (audioRef.current === audio) {
              audioRef.current = null;
            }
            setOrbState('IDLE');
          };

          audio.onended = cleanupAudio;
          audio.onerror = cleanupAudio;

          const ctx = ensureAudioContext();
          if (ctx) {
            try {
              const source = ctx.createMediaElementSource(audio);
              const analyser = ctx.createAnalyser();
              analyser.fftSize = 256;

              if (isLegend) {
                // Deep, bass-rich vocal mastering chain for Punjabi Legend presence
                const bassShelf = ctx.createBiquadFilter();
                bassShelf.type = 'lowshelf';
                bassShelf.frequency.value = 135;
                bassShelf.gain.value = 4.2;

                const grainPresence = ctx.createBiquadFilter();
                grainPresence.type = 'peaking';
                grainPresence.frequency.value = 2600;
                grainPresence.Q.value = 1.1;
                grainPresence.gain.value = 1.6;

                const compressor = ctx.createDynamicsCompressor();
                compressor.threshold.value = -18;
                compressor.knee.value = 12;
                compressor.ratio.value = 3.2;
                compressor.attack.value = 0.008;
                compressor.release.value = 0.16;

                source.connect(bassShelf);
                bassShelf.connect(grainPresence);
                grainPresence.connect(compressor);
                compressor.connect(analyser);
              } else {
                source.connect(analyser);
              }
              analyser.connect(ctx.destination);
              analyserRef.current = analyser;

              const dataArray = new Uint8Array(analyser.frequencyBinCount);
              const tickMeter = () => {
                if (!audioRef.current || audioRef.current.paused || audioRef.current.ended) {
                  speechLevelRef.current = 0;
                  return;
                }
                analyser.getByteTimeDomainData(dataArray);
                let sumSq = 0;
                for (let i = 0; i < dataArray.length; i++) {
                  const normalized = (dataArray[i] - 128) / 128;
                  sumSq += normalized * normalized;
                }
                const rms = Math.sqrt(sumSq / dataArray.length);
                speechLevelRef.current = Math.min(1, Math.max(0, rms * 3.8));
                speechRafRef.current = window.requestAnimationFrame(tickMeter);
              };
              speechRafRef.current = window.requestAnimationFrame(tickMeter);
            } catch {
              const start = performance.now();
              const tickEnvelope = (now: number) => {
                if (!audioRef.current || audioRef.current.paused || audioRef.current.ended) {
                  speechLevelRef.current = 0;
                  return;
                }
                const elapsed = (now - start) * 0.001;
                speechLevelRef.current = 0.25 + 0.45 * Math.abs(Math.sin(elapsed * 11));
                speechRafRef.current = window.requestAnimationFrame(tickEnvelope);
              };
              speechRafRef.current = window.requestAnimationFrame(tickEnvelope);
            }
          }

          await audio.play();
          return;
        }
      } catch {
        // Fallback to browser SpeechSynthesis below
      }

      if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(text);
        const voices = window.speechSynthesis.getVoices();
        const preferLang =
          memory.preferredLanguage !== 'auto'
            ? memory.preferredLanguage
            : /[\u0A00-\u0A7F]/.test(text)
              ? 'pa-IN'
              : /[\u0600-\u06FF]/.test(text)
                ? 'ur-PK'
                : /[\u0900-\u097F]/.test(text)
                  ? 'hi-IN'
                  : 'en-IN';
        utter.lang = preferLang;

        if (voices.length > 0) {
          const wantMale = isLegend || memory.voiceGender === 'MALE';
          const scored = voices
            .map((v) => {
              let score = 0;
              const name = v.name.toLowerCase();
              const lang = v.lang.toLowerCase();
              if (lang.startsWith(preferLang.slice(0, 2).toLowerCase())) score += 4;
              if (lang.includes('-in') || lang.includes('-pk')) score += 2;
              if (wantMale && /(male|rishi|prabhat|madhur|david|daniel|alex|google.*uk.*male|guy)/i.test(name)) {
                score += 5;
              }
              if (!wantMale && /(female|lekha|swara|heera|samantha|zira|google.*female)/i.test(name)) {
                score += 5;
              }
              return { v, score };
            })
            .sort((a, b) => b.score - a.score);
          if (scored[0] && scored[0].score > 0) {
            utter.voice = scored[0].v;
          }
        }

        utter.pitch = isLegend ? 0.72 : memory.voiceGender === 'FEMALE' ? 1.1 : 0.88;
        utter.rate = isLegend ? 0.92 : memory.voiceGender === 'FEMALE' ? 1.12 : 1.02;

        let pulseBoost = 0.65;
        const start = performance.now();
        const tickSynth = (now: number) => {
          if (!window.speechSynthesis.speaking) {
            speechLevelRef.current = 0;
            speechRafRef.current = null;
            return;
          }
          const t = (now - start) * 0.001;
          pulseBoost = Math.max(0.22, pulseBoost * 0.93);
          speechLevelRef.current = Math.min(
            1,
            pulseBoost * (0.55 + 0.45 * Math.abs(Math.sin(t * 13.5))),
          );
          speechRafRef.current = window.requestAnimationFrame(tickSynth);
        };

        utter.onboundary = () => {
          pulseBoost = 0.88;
        };
        utter.onstart = () => {
          speechRafRef.current = window.requestAnimationFrame(tickSynth);
        };
        utter.onend = () => {
          stopSpeechMeter();
          setOrbState('IDLE');
        };
        utter.onerror = () => {
          stopSpeechMeter();
          setOrbState('IDLE');
        };
        window.speechSynthesis.speak(utter);
      } else {
        stopSpeechMeter();
        setOrbState('IDLE');
      }
    },
    [
      ensureAudioContext,
      interruptSpeech,
      memory.preferredLanguage,
      memory.voiceGender,
      memory.voicePersona,
      stopSpeechMeter,
    ],
  );

  const executeParsedCommand = useCallback(
    (
      rawCommand: string,
      parsed: {
        intent: string;
        targetApp?: string;
        queryOrText?: string;
        targetContact?: string;
        requiredPermission: string;
        needsConfirmation: boolean;
        confirmationPrompt?: string;
        spokenReply: string;
      },
      confirmed: boolean,
      executionSource: 'Local Native Engine' | 'Gemini AI',
    ): { reply: string; report: TaskExecutionReport; pendingConfirm?: boolean } => {
      const intent = (parsed.intent || 'CONVERSATION').toUpperCase();
      const knownContacts = Array.from(
        new Set([
          ...memory.priorityContacts,
          ...whatsappMessages.map((m) => m.sender),
        ]),
      );

      let resolvedContact = parsed.targetContact?.trim() || '';
      if (
        resolvedContact &&
        ['REPLY_WHATSAPP', 'SEND_WHATSAPP_VOICE', 'CALL_CONTACT', 'SEND_SMS'].includes(intent)
      ) {
        const contactCheck = resolveKnownContacts(resolvedContact, knownContacts);
        if (contactCheck.status === 'ambiguous') {
          const clarifyMsg = `Multiple contacts match "${resolvedContact}": ${contactCheck.matches.join(', ')}. Please specify the exact contact name before I proceed.`;
          return {
            reply: clarifyMsg,
            report: {
              userRequest: rawCommand,
              identifiedAction: `${intent} (Ambiguous Contact)`,
              requiredPermission: parsed.requiredPermission || 'Contacts',
              actionPerformed: 'Blocked ambiguous contact selection',
              succeeded: false,
              failureReason: clarifyMsg,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }
        if (contactCheck.status === 'unique') {
          resolvedContact = contactCheck.matches[0];
        }
      }

      const highRiskIntent = [
        'REPLY_WHATSAPP',
        'AUTO_REPLY_RULE',
        'REJECT_CALL',
        'END_CALL',
        'TELL_CALLER_BUSY',
        'CALL_CONTACT',
        'SEND_SMS',
        'SEND_WHATSAPP_VOICE',
        'SHARE_FILE',
      ].includes(intent);

      if ((parsed.needsConfirmation || highRiskIntent) && !confirmed) {
        return {
          reply:
            parsed.confirmationPrompt ||
            parsed.spokenReply ||
            `Confirm executing ${intent.toLowerCase().replace(/_/g, ' ')}?`,
          pendingConfirm: true,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: parsed.requiredPermission,
            actionPerformed: 'Waiting for explicit user approval',
            succeeded: false,
            failureReason: 'Confirmation required before executing external or irreversible action.',
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (
        [
          'READ_SCREEN',
          'EXPLAIN_SCREEN',
          'SCROLL_DOWN',
          'SCROLL_UP',
          'NAVIGATE_BACK',
          'NAVIGATE_HOME',
          'CLOSE_APP',
          'CLICK_ELEMENT',
          'TYPE_TEXT',
        ].includes(intent) &&
        !isGranted('accessibility')
      ) {
        const msg =
          'Accessibility Service is disabled. Please enable it in Settings before I can read or control the screen.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'AccessibilityService',
            actionPerformed: 'Verified AccessibilityService permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (
        [
          'READ_WHATSAPP',
          'SHOW_WHATSAPP_MESSAGES',
          'OPEN_CONTACT_MESSAGE',
          'READ_CONTACT_MESSAGE',
          'READ_NOTIFICATIONS',
          'REPLY_WHATSAPP',
          'SEND_WHATSAPP_VOICE',
          'AUTO_REPLY_RULE',
        ].includes(intent) &&
        !isGranted('notif_listener')
      ) {
        const msg =
          'Notification Listener permission is not allowed. Enable it to read or reply to WhatsApp messages.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'NotificationListenerService',
            actionPerformed: 'Verified Notification Access',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (['FLASHLIGHT_ON', 'FLASHLIGHT_OFF', 'CAPTURE_PHOTO'].includes(intent) && !isGranted('camera')) {
        const msg = 'Camera permission is required to control the flashlight or capture photos.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'CAMERA',
            actionPerformed: 'Checked CAMERA permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      if (['ANSWER_CALL', 'REJECT_CALL', 'END_CALL', 'CALL_CONTACT'].includes(intent) && !isGranted('phone')) {
        const msg = 'Phone Call permission is disabled. Enable it in Permissions before placing or managing calls.';
        return {
          reply: msg,
          report: {
            userRequest: rawCommand,
            identifiedAction: intent,
            requiredPermission: 'ANSWER_PHONE_CALLS',
            actionPerformed: 'Checked Phone Call permission',
            succeeded: false,
            failureReason: msg,
            executionSource,
            timestamp: formatTime(),
          },
        };
      }

      switch (intent) {
        case 'WAKE_ACK':
          return {
            reply: greetingName
              ? `Haan ${greetingName}, boliye. Main sun raha hoon.`
              : parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'WAKE_ACK',
              requiredPermission: 'Microphone (RECORD_AUDIO)',
              actionPerformed: 'Activated on wake word',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_APP': {
          const target = (parsed.targetApp || 'WhatsApp').toLowerCase();
          if (target.includes('whatsapp')) {
            setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          } else if (target.includes('setting')) {
            setHardware((h) => ({ ...h, activeScreenKey: 'settings' }));
          } else {
            setHardware((h) => ({ ...h, activeScreenKey: 'article' }));
          }
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: `OPEN_APP (${parsed.targetApp || 'App'})`,
              requiredPermission: 'Launcher Intent',
              actionPerformed: `Opened ${parsed.targetApp || 'target app'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'CLOSE_APP':
        case 'NAVIGATE_HOME':
          setHardware((h) => ({ ...h, screenScrollIndex: 0 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AccessibilityService',
              actionPerformed:
                intent === 'CLOSE_APP'
                  ? `Closed ${parsed.targetApp || 'app'} and returned Home`
                  : 'Navigated to Home screen',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_SETTINGS':
          setHardware((h) => ({ ...h, activeScreenKey: 'settings' }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'OPEN_SETTINGS',
              requiredPermission: 'Android Settings Intent',
              actionPerformed: 'Opened Android Settings',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'OPEN_CAMERA':
        case 'CAPTURE_PHOTO':
        case 'OPEN_DIALER':
        case 'OPEN_GALLERY':
        case 'OPEN_CONTACTS':
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'Android Intent',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'WEB_SEARCH':
        case 'YOUTUBE_SEARCH':
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'Android Search Intent',
              actionPerformed: `Searched: ${parsed.queryOrText || rawCommand}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'CHECK_BATTERY': {
          const batteryReply =
            hardware.batteryPercent !== null
              ? `Battery level is ${hardware.batteryPercent}%${hardware.batteryCharging ? ' (Charging)' : ''}.`
              : 'Device battery telemetry is managed natively on Android via BatteryManager.';
          return {
            reply: `${parsed.spokenReply} ${batteryReply}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'CHECK_BATTERY',
              requiredPermission: 'BatteryManager',
              actionPerformed: batteryReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'ENABLE_DND':
        case 'DISABLE_DND': {
          const dndOn = intent === 'ENABLE_DND';
          setHardware((h) => ({ ...h, dndEnabled: dndOn }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'ACCESS_NOTIFICATION_POLICY',
              actionPerformed: `Set Do Not Disturb to ${dndOn ? 'ON' : 'OFF'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'READ_SCREEN':
        case 'EXPLAIN_SCREEN': {
          const latestWa = whatsappMessages[0];
          const screenText =
            hardware.activeScreenKey === 'whatsapp' && latestWa
              ? `WhatsApp chat with ${latestWa.sender}: "${latestWa.text}". Buttons visible: Reply, Voice Call, Video Call.`
              : hardware.activeScreenKey === 'settings'
                ? 'Android Settings screen: Bluetooth ready, Digital Assistant set to SMW AI.'
                : 'Chrome article: Android Accessibility and MediaProjection privacy boundaries.';
          return {
            reply: `${parsed.spokenReply} ${screenText}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AccessibilityService',
              actionPerformed: screenText,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SCROLL_DOWN':
          setHardware((h) => ({ ...h, screenScrollIndex: h.screenScrollIndex + 240 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SCROLL_DOWN',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Scrolled down 240px',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'SCROLL_UP':
          setHardware((h) => ({
            ...h,
            screenScrollIndex: Math.max(0, h.screenScrollIndex - 240),
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SCROLL_UP',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Scrolled up 240px',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'NAVIGATE_BACK':
          setHardware((h) => ({ ...h, activeScreenKey: 'settings', screenScrollIndex: 0 }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'NAVIGATE_BACK',
              requiredPermission: 'AccessibilityService',
              actionPerformed: 'Performed Android GLOBAL_ACTION_BACK',
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };

        case 'SHOW_WHATSAPP_MESSAGES': {
          setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          const list = whatsappMessages
            .slice(0, 3)
            .map((m) => `${m.sender}: "${m.text}"`)
            .join(' | ');
          const summary = list || 'No WhatsApp messages in stream.';
          return {
            reply: `${parsed.spokenReply} ${summary}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: 'SHOW_WHATSAPP_MESSAGES',
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'OPEN_CONTACT_MESSAGE':
        case 'READ_CONTACT_MESSAGE': {
          const contactQuery = (resolvedContact || parsed.targetContact || '').toLowerCase();
          const matched = whatsappMessages.find((m) =>
            m.sender.toLowerCase().includes(contactQuery),
          );
          if (intent === 'OPEN_CONTACT_MESSAGE') {
            setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          }
          const summary = matched
            ? matched.repliedText
              ? `${matched.sender}: "${matched.text}". Sent reply: "${matched.repliedText}"`
              : `${matched.sender} ne bheja hai: "${matched.text}"`
            : `${resolvedContact || parsed.targetContact || 'Contact'} ka koi unread WhatsApp message nahi mila.`;
          return {
            reply: summary,
            report: {
              userRequest: rawCommand,
              identifiedAction: `${intent} (${resolvedContact || parsed.targetContact || 'Contact'})`,
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: Boolean(matched),
              failureReason: matched ? undefined : 'No message found for requested contact.',
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'READ_WHATSAPP':
        case 'READ_NOTIFICATIONS': {
          const latest = whatsappMessages[0];
          const summary =
            parsed.queryOrText === 'full' && latest
              ? `${latest.sender} ka poora message: "${latest.text}"`
              : latest
                ? `${latest.sender} sent (${latest.isUrgent ? 'Urgent' : 'Normal'}): "${latest.text}"`
                : 'No unread WhatsApp notifications.';
          return {
            reply: `${parsed.spokenReply} ${summary}`,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'NotificationListenerService',
              actionPerformed: summary,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SEND_WHATSAPP_VOICE': {
          const contact = resolvedContact || parsed.targetContact || whatsappMessages[0]?.sender || 'Ali';
          setHardware((h) => ({ ...h, activeScreenKey: 'whatsapp' }));
          return {
            reply: `${contact} ki WhatsApp chat khol di hai taake aap voice message record karke bhej sakein.`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `SEND_WHATSAPP_VOICE (${contact})`,
              requiredPermission: 'NotificationListenerService + READ_CONTACTS',
              actionPerformed: `Opened WhatsApp chat for ${contact} voice message`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'REPLY_WHATSAPP': {
          const contact = resolvedContact || parsed.targetContact || whatsappMessages[0]?.sender || 'Ali';
          const replyText = parsed.queryOrText || autoReplyRule.activeTemplate;
          setWhatsappMessages((prev) => {
            const exists = prev.some((m) =>
              m.sender.toLowerCase().includes(contact.toLowerCase()),
            );
            if (!exists) {
              return [
                {
                  id: `wa-${Date.now()}`,
                  appSource: 'WhatsApp',
                  sender: contact,
                  text: 'Conversation started via SMW AI',
                  timestamp: formatTime(),
                  isUrgent: false,
                  autoReplied: true,
                  repliedText: replyText,
                },
                ...prev,
              ];
            }
            return prev.map((m) =>
              m.sender.toLowerCase().includes(contact.toLowerCase())
                ? { ...m, autoReplied: true, repliedText: replyText }
                : m,
            );
          });
          return {
            reply: `${contact} ko WhatsApp message bhej diya gaya hai: "${replyText}"`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `REPLY_WHATSAPP (${contact})`,
              requiredPermission: 'NotificationListenerService + RemoteInput',
              actionPerformed: `Sent WhatsApp message to ${contact}: "${replyText}"`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'CALL_CONTACT': {
          const contact = resolvedContact || parsed.targetContact || 'Contact';
          setActiveCall({
            id: `call-out-${Date.now()}`,
            callerName: contact,
            phoneNumber: 'Authorized Contact',
            status: 'ACTIVE',
          });
          return {
            reply: `${contact} ko call milayi ja rahi hai.`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `CALL_CONTACT (${contact})`,
              requiredPermission: 'ANSWER_PHONE_CALLS + Contacts',
              actionPerformed: `Initiated call to ${contact}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SEND_SMS': {
          const contact = resolvedContact || parsed.targetContact || 'Contact';
          const smsText = parsed.queryOrText || 'Please call me back.';
          return {
            reply: `${contact} ko SMS composer mein message tayyar karke bhej diya gaya hai: "${smsText}"`,
            report: {
              userRequest: rawCommand,
              identifiedAction: `SEND_SMS (${contact})`,
              requiredPermission: 'SMS Intent + Contacts',
              actionPerformed: `Prepared SMS to ${contact}: "${smsText}"`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'FLASHLIGHT_ON':
        case 'FLASHLIGHT_OFF': {
          const on = intent === 'FLASHLIGHT_ON';
          setHardware((h) => ({ ...h, flashlightOn: on }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'CAMERA',
              actionPerformed: `Turned flashlight ${on ? 'ON' : 'OFF'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'VOLUME_UP':
        case 'VOLUME_DOWN': {
          const delta = intent === 'VOLUME_UP' ? 15 : -15;
          setHardware((h) => ({
            ...h,
            volumePercent: Math.max(0, Math.min(100, h.volumePercent + delta)),
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AudioManager',
              actionPerformed: `Adjusted volume (${delta > 0 ? '+15%' : '-15%'})`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'MEDIA_PLAY':
        case 'MEDIA_PAUSE':
        case 'MEDIA_NEXT': {
          setHardware((h) => ({
            ...h,
            mediaPlaying: intent !== 'MEDIA_PAUSE',
          }));
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'AudioManager',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'SET_ALARM':
        case 'SET_TIMER':
        case 'ADD_NOTE':
        case 'ADD_REMINDER': {
          const typeMap: Record<string, DailyTask['type']> = {
            SET_ALARM: 'alarm',
            SET_TIMER: 'timer',
            ADD_NOTE: 'note',
            ADD_REMINDER: 'reminder',
          };
          setDailyTasks((prev) => [
            {
              id: `task-${Date.now()}`,
              type: typeMap[intent] || 'note',
              title: parsed.queryOrText || rawCommand,
              detail: 'Created via SMW AI command',
              createdAt: formatTime(),
            },
            ...prev,
          ]);
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'SET_ALARM / Local Store',
              actionPerformed: `Saved ${typeMap[intent] || 'task'}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        case 'ANSWER_CALL':
        case 'REJECT_CALL':
        case 'END_CALL':
        case 'SPEAKERPHONE_ON':
        case 'TELL_CALLER_BUSY': {
          if (!activeCall && intent !== 'SPEAKERPHONE_ON') {
            return {
              reply: 'No active incoming call right now.',
              report: {
                userRequest: rawCommand,
                identifiedAction: intent,
                requiredPermission: 'ANSWER_PHONE_CALLS',
                actionPerformed: 'Checked active call state',
                succeeded: false,
                failureReason: 'No active call present.',
                executionSource,
                timestamp: formatTime(),
              },
            };
          }
          if (intent === 'ANSWER_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'ACTIVE' } : null));
          } else if (intent === 'REJECT_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'REJECTED' } : null));
          } else if (intent === 'END_CALL') {
            setActiveCall((c) => (c ? { ...c, status: 'ENDED' } : null));
          } else if (intent === 'SPEAKERPHONE_ON') {
            setCallConfig((cfg) => ({ ...cfg, speakerphoneActive: true }));
          } else if (intent === 'TELL_CALLER_BUSY') {
            setActiveCall((c) =>
              c ? { ...c, status: 'BUSY_NOTIFIED', aiDisclosureSent: callConfig.busyNotice } : null,
            );
          }
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: 'ANSWER_PHONE_CALLS',
              actionPerformed: `Executed ${intent}`,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
        }

        default:
          return {
            reply: parsed.spokenReply,
            report: {
              userRequest: rawCommand,
              identifiedAction: intent,
              requiredPermission: parsed.requiredPermission || 'None',
              actionPerformed: parsed.spokenReply,
              succeeded: true,
              executionSource,
              timestamp: formatTime(),
            },
          };
      }
    },
    [
      activeCall,
      autoReplyRule.activeTemplate,
      callConfig.busyNotice,
      greetingName,
      hardware.activeScreenKey,
      hardware.batteryCharging,
      hardware.batteryPercent,
      isGranted,
      memory.priorityContacts,
      whatsappMessages,
    ],
  );

  const handleSendCommand = useCallback(
    async (text: string, confirmed = false) => {
      interruptSpeech();
      const latestPending = [...messages]
        .reverse()
        .find((m) => m.role === 'assistant' && m.pendingConfirmation)?.pendingConfirmation;

      if (!confirmed && latestPending) {
        const cleanLower = text.trim().toLowerCase().replace(/[.!?]+$/, '');
        if (/^(yes|yeah|yep|haan|han|ji|ok|okay|confirm|approved?|bhej\s*do|kar\s*do|send(?:\s*it)?|mila\s*do)$/i.test(cleanLower)) {
          setMessages((prev) => [
            ...prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
            {
              id: `u-${Date.now()}`,
              role: 'user',
              text,
              timestamp: formatTime(),
            },
          ]);
          await handleSendCommand(latestPending.rawCommand, true);
          return;
        }
        if (/^(no|nahi|cancel|abort|stop|mat\s*bhejo|rehne\s*do)$/i.test(cleanLower)) {
          setMessages((prev) => [
            ...prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
            {
              id: `u-${Date.now()}`,
              role: 'user',
              text,
              timestamp: formatTime(),
            },
            {
              id: `a-cancel-${Date.now()}`,
              role: 'assistant',
              text: 'Action cancelled. Kuch bhi nahi bheja gaya.',
              timestamp: formatTime(),
            },
          ]);
          void speakText('Action cancelled.');
          return;
        }
      }

      if (confirmed) {
        setMessages((prev) =>
          prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
        );
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: `u-${Date.now()}`,
            role: 'user',
            text,
            timestamp: formatTime(),
          },
        ]);
      }

      const localMatch = parseLocalCommand(text, memory.wakePhrase);
      if (localMatch) {
        const result = executeParsedCommand(text, localMatch, confirmed, 'Local Native Engine');
        setLatestReport(result.report);
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: 'assistant',
            text: result.reply,
            timestamp: formatTime(),
            taskReport: result.report,
            pendingConfirmation: result.pendingConfirm
              ? { rawCommand: text, prompt: result.reply }
              : undefined,
          },
        ]);
        speakText(result.reply);
        return;
      }

      setOrbState('THINKING');
      const wantsDeviceAction = isLikelyDeviceAction(text, memory.wakePhrase);

      if (!wantsDeviceAction) {
        try {
          const { ok, status, data } = await safeFetchJson<{ reply?: string; modelUsed?: string }>(
            '/api/ai/chat',
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                message: text,
                assistantName: memory.assistantName,
                preferredLanguage: memory.preferredLanguage,
                persona: memory.voicePersona || 'punjabi_legend',
                userName: greetingName || '',
                history: messages.slice(-6).map((m) => ({ role: m.role, text: m.text })),
              }),
            },
          );

          if (!ok) {
            throw new Error(data.error || `AI chat server returned status ${status}.`);
          }

          const replyText = data.reply || 'I am ready to help.';
          const chatReport: TaskExecutionReport = {
            userRequest: text,
            identifiedAction: 'CONVERSATIONAL_CHAT',
            requiredPermission: 'None',
            actionPerformed: data.modelUsed
              ? `Conversational reply generated via ${data.modelUsed}`
              : 'Conversational reply generated via Gemini AI',
            succeeded: true,
            executionSource: 'Gemini AI',
            timestamp: formatTime(),
          };
          setLatestReport(chatReport);
          setMessages((prev) => [
            ...prev,
            {
              id: `a-${Date.now()}`,
              role: 'assistant',
              text: replyText,
              timestamp: formatTime(),
              taskReport: chatReport,
            },
          ]);
          speakText(replyText);
        } catch (err) {
          const errMsg = err instanceof Error ? err.message : 'Network error reaching AI chat backend.';
          const failReport: TaskExecutionReport = {
            userRequest: text,
            identifiedAction: 'CONVERSATIONAL_CHAT',
            requiredPermission: 'Server AI API',
            actionPerformed: 'Attempted conversational reply via /api/ai/chat',
            succeeded: false,
            failureReason: errMsg,
            executionSource: 'Gemini AI',
            timestamp: formatTime(),
          };
          setLatestReport(failReport);
          setMessages((prev) => [
            ...prev,
            {
              id: `err-${Date.now()}`,
              role: 'assistant',
              text: `${errMsg} — Native device commands (Open WhatsApp, Read Screen, Flashlight, Scroll, Calls, Alarms) work locally without Gemini.`,
              timestamp: formatTime(),
              taskReport: failReport,
            },
          ]);
          setOrbState('IDLE');
        }
        return;
      }

      try {
        const { ok, status, data } = await safeFetchJson<{
          intent: string;
          targetApp?: string;
          queryOrText?: string;
          targetContact?: string;
          requiredPermission: string;
          needsConfirmation: boolean;
          confirmationPrompt?: string;
          spokenReply: string;
        }>('/api/ai/command', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text,
            assistantName: memory.assistantName,
            preferredLanguage: memory.preferredLanguage,
            persona: memory.voicePersona || 'punjabi_legend',
            screenSummary: `Active screen: ${hardware.activeScreenKey}`,
            unreadNotificationsCount: whatsappMessages.length,
          }),
        });

        if (!ok) {
          throw new Error(data.error || `AI server returned status ${status}.`);
        }

        const result = executeParsedCommand(text, data, confirmed, 'Gemini AI');
        setLatestReport(result.report);
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: 'assistant',
            text: result.reply,
            timestamp: formatTime(),
            taskReport: result.report,
            pendingConfirmation: result.pendingConfirm
              ? { rawCommand: text, prompt: result.reply }
              : undefined,
          },
        ]);
        speakText(result.reply);
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : 'Network error reaching AI backend.';
        const failReport: TaskExecutionReport = {
          userRequest: text,
          identifiedAction: 'AI_COMMAND_PARSE',
          requiredPermission: 'Server AI API',
          actionPerformed: 'Attempted device-action parsing via Gemini AI',
          succeeded: false,
          failureReason: errMsg,
          executionSource: 'Gemini AI',
          timestamp: formatTime(),
        };
        setLatestReport(failReport);
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            role: 'assistant',
            text: `${errMsg} — Native device commands (Open WhatsApp, Read Screen, Flashlight, Scroll, Calls, Alarms) work locally without Gemini.`,
            timestamp: formatTime(),
            taskReport: failReport,
          },
        ]);
        setOrbState('IDLE');
      }
    },
    [
      executeParsedCommand,
      greetingName,
      hardware.activeScreenKey,
      interruptSpeech,
      memory.assistantName,
      memory.preferredLanguage,
      memory.voicePersona,
      memory.wakePhrase,
      messages,
      speakText,
      whatsappMessages.length,
    ],
  );

  const startVoiceRecognition = useCallback(
    (continuous: boolean) => {
      if (!isGranted('mic')) {
        setMessages((prev) => [
          ...prev,
          {
            id: `mic-err-${Date.now()}`,
            role: 'assistant',
            text: 'Microphone permission is currently denied. Allow it in Settings to use voice commands.',
            timestamp: formatTime(),
          },
        ]);
        return;
      }

      const SpeechRec =
        (window as unknown as { SpeechRecognition?: new () => unknown; webkitSpeechRecognition?: new () => unknown })
          .SpeechRecognition ||
        (window as unknown as { webkitSpeechRecognition?: new () => unknown })
          .webkitSpeechRecognition;

      if (!SpeechRec) {
        setMessages((prev) => [
          ...prev,
          {
            id: `sr-na-${Date.now()}`,
            role: 'assistant',
            text: 'Browser SpeechRecognition is not supported in this browser tab. Use the text message input.',
            timestamp: formatTime(),
          },
        ]);
        return;
      }

      interruptSpeech();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const rec = new (SpeechRec as any)();
      rec.continuous = continuous;
      rec.interimResults = true;
      rec.lang =
        memory.preferredLanguage === 'pa-IN'
          ? 'pa-IN'
          : memory.preferredLanguage === 'hi-IN'
            ? 'hi-IN'
            : memory.preferredLanguage === 'ur-PK'
              ? 'ur-PK'
              : memory.preferredLanguage === 'en-US'
                ? 'en-US'
                : 'en-IN';

      rec.onstart = () => setOrbState('LISTENING');
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      rec.onresult = (event: any) => {
        const last = event.results[event.results.length - 1];
        const transcript = last[0]?.transcript?.trim() || '';
        setPartialTranscript(transcript);
        if (last.isFinal && transcript) {
          setPartialTranscript('');
          if (memory.wakeWordRequired && continuous) {
            const { wakeWord } = stripWakePrefix(transcript, memory.wakePhrase);
            if (!wakeWord) return;
          }
          if (!continuous) {
            rec.stop();
          }
          void handleSendCommand(transcript);
        }
      };
      rec.onerror = () => {
        setOrbState('IDLE');
        setPartialTranscript('');
      };
      rec.onend = () => {
        setOrbState((curr) => (curr === 'LISTENING' ? 'IDLE' : curr));
        setPartialTranscript('');
      };

      recognitionRef.current = rec;
      rec.start();
    },
    [
      handleSendCommand,
      interruptSpeech,
      isGranted,
      memory.preferredLanguage,
      memory.wakePhrase,
      memory.wakeWordRequired,
    ],
  );

  const stopVoiceRecognition = useCallback(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const rec = recognitionRef.current as any;
    if (rec) {
      rec.stop();
      recognitionRef.current = null;
    }
    setOrbState('IDLE');
    setPartialTranscript('');
  }, []);

  const handleToggleListen = () => {
    if (orbState === 'LISTENING') {
      stopVoiceRecognition();
    } else {
      startVoiceRecognition(false);
    }
  };

  const grantPermission = (id: string) => {
    setPermissions((prev) =>
      prev.map((p) => (p.id === id ? { ...p, granted: true } : p)),
    );
  };

  const handleSubmitText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const text = input.trim();
    setInput('');
    void handleSendCommand(text);
  };

  const handleMicPress = () => {
    ensureAudioContext();
    if (orbState === 'SPEAKING') {
      interruptSpeech();
      return;
    }
    if (!isGranted('mic')) {
      grantPermission('mic');
    }
    handleToggleListen();
  };

  const handleCancelConfirmation = useCallback(() => {
    setMessages((prev) => [
      ...prev.map((m) => (m.pendingConfirmation ? { ...m, pendingConfirmation: undefined } : m)),
      {
        id: `a-cancel-btn-${Date.now()}`,
        role: 'assistant',
        text: 'Action cancelled. Kuch bhi nahi bheja gaya.',
        timestamp: formatTime(),
      },
    ]);
    void speakText('Action cancelled.');
  }, [speakText]);

  useEffect(() => {
    let rafId = 0;
    const startTime = performance.now();
    let smoothed = 0;

    const animateNeonStage = (now: number) => {
      const elapsed = (now - startTime) * 0.001;
      const targetLevel =
        orbState === 'SPEAKING'
          ? Math.max(0.12, speechLevelRef.current)
          : orbState === 'LISTENING'
            ? 0.28 + 0.2 * Math.abs(Math.sin(elapsed * 6.2))
            : orbState === 'THINKING'
              ? 0.16 + 0.1 * Math.sin(elapsed * 4.2)
              : 0.04;
      smoothed += (targetLevel - smoothed) * 0.24;

      if (stageAuraRef.current) {
        const auraOpacity =
          orbState === 'IDLE' ? 0.45 : Math.min(0.95, 0.52 + smoothed * 0.55);
        stageAuraRef.current.style.opacity = auraOpacity.toFixed(3);
      }

      if (micHaloRef.current) {
        const haloScale = 1 + smoothed * 0.28;
        const haloOpacity =
          orbState === 'IDLE' ? 0.45 : Math.min(1, 0.58 + smoothed * 0.55);
        micHaloRef.current.style.transform = `scale(${haloScale.toFixed(4)})`;
        micHaloRef.current.style.opacity = haloOpacity.toFixed(3);
      }

      waveBarRefs.current.forEach((bar, idx) => {
        if (!bar) return;
        const localIdx = idx % 8;
        const falloff = 1 - (localIdx / 7) * 0.65;
        const isActive = orbState === 'SPEAKING' || orbState === 'LISTENING';
        const dynamicHeight = isActive
          ? Math.max(
              6,
              Math.min(
                44,
                8 +
                  smoothed *
                    38 *
                    falloff *
                    (0.55 + 0.45 * Math.abs(Math.sin(elapsed * 10.5 + idx * 0.72))),
              ),
            )
          : orbState === 'THINKING'
            ? 8 + 7 * Math.abs(Math.sin(elapsed * 4.5 + idx * 0.55))
            : 6 + 10 * falloff * (0.65 + 0.35 * Math.sin(elapsed * 2.1 + idx * 0.4));
        bar.style.height = `${dynamicHeight.toFixed(1)}px`;
        bar.style.opacity = isActive ? '1' : orbState === 'THINKING' ? '0.85' : '0.68';
      });

      rafId = window.requestAnimationFrame(animateNeonStage);
    };

    rafId = window.requestAnimationFrame(animateNeonStage);
    return () => window.cancelAnimationFrame(rafId);
  }, [orbState]);

  const latestAssistantMsg = [...messages].reverse().find((m) => m.role === 'assistant');

  return (
    <div className="relative flex min-h-dvh w-full flex-col items-center justify-end overflow-hidden bg-[#02050D] text-white">
      {/* Ambient Deep Black & Electric Blue Glow Backdrop */}
      <div
        ref={stageAuraRef}
        className="animate-smw-aura pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_50%_42%,rgba(30,136,255,0.38),rgba(2,5,13,0.92)_68%,#02050D_100%)]"
      />

      {/* Full-Screen Dominant Sidhu Moose Wala Avatar Stage */}
      <div className="pointer-events-none fixed inset-0 flex items-center justify-center">
        <div className="relative h-full w-full md:max-w-[540px]">
          <img
            src={SMW_AVATAR_BG}
            alt="Sidhu Moose Wala SMW AI Assistant"
            referrerPolicy="no-referrer"
            className="h-full w-full select-none object-cover object-top"
          />
          {/* Seamless Side Edge Vignettes for Wide / Desktop Screens */}
          <div className="hidden md:block md:absolute md:inset-y-0 md:left-0 md:w-20 md:bg-gradient-to-r md:from-[#02050D] md:to-transparent" />
          <div className="hidden md:block md:absolute md:inset-y-0 md:right-0 md:w-20 md:bg-gradient-to-l md:from-[#02050D] md:to-transparent" />
          <div className="hidden md:block md:absolute md:inset-x-0 md:top-0 md:h-12 md:bg-gradient-to-b md:from-[#02050D] md:to-transparent" />
        </div>
      </div>

      {/* Bottom Electric-Blue Atmospheric Scrim for Controls */}
      <div className="pointer-events-none fixed inset-x-0 bottom-0 h-56 bg-gradient-to-t from-[#02050D] via-[#02050D]/92 to-transparent" />
      <div className="pointer-events-none fixed inset-x-0 bottom-0 h-32 bg-[radial-gradient(ellipse_at_50%_100%,rgba(30,136,255,0.45),transparent_72%)]" />

      {/* Live Voice Transcript / Spoken Response Caption (Non-interactive) */}
      {(orbState !== 'IDLE' || partialTranscript || latestAssistantMsg) && !chatOpen && (
        <div className="pointer-events-none relative z-10 mb-5 max-w-md px-6 text-center">
          <p className="rounded-2xl border border-[#1E88FF]/35 bg-[#030A18]/80 px-4 py-2 text-xs leading-relaxed text-sky-100 shadow-[0_0_24px_rgba(30,136,255,0.28)] backdrop-blur-md">
            {orbState === 'LISTENING'
              ? partialTranscript
                ? `"${partialTranscript}"`
                : 'Listening...'
              : orbState === 'THINKING'
                ? 'Thinking...'
                : orbState === 'SPEAKING' && latestAssistantMsg
                  ? latestAssistantMsg.text
                  : partialTranscript || latestAssistantMsg?.text}
          </p>
        </div>
      )}

      {/* ONLY TWO INTERFACE CONTROLS: Chat Button + Central Animated Microphone Button */}
      <main className="relative z-10 flex w-full max-w-[540px] items-center justify-center px-5 pb-8 pt-2">
        <div className="relative flex w-full items-center justify-center">
          {/* Control 1: Text Chat Button (Left) */}
          <button
            type="button"
            onClick={() => setChatOpen(true)}
            aria-label="Open text chat"
            className="absolute left-2 flex h-[56px] w-[82px] items-center justify-center rounded-2xl border border-[#38BDF8]/75 bg-[#040D22]/85 text-white shadow-[0_0_24px_rgba(30,136,255,0.55),inset_0_0_12px_rgba(56,189,248,0.25)] backdrop-blur-md transition-transform duration-150 hover:scale-105 hover:border-[#38BDF8] active:scale-95 sm:left-6"
          >
            <MessageCircleMore className="h-7 w-7 text-white drop-shadow-[0_0_8px_rgba(56,189,248,0.85)]" />
          </button>

          {/* Symmetric Live Electric-Blue Audio Waveform + Control 2: Microphone Button */}
          <div className="flex items-center justify-center gap-3">
            <div className="flex h-11 items-center gap-1" aria-hidden="true">
              {[7, 6, 5, 4, 3, 2, 1, 0].map((idx) => (
                <span
                  key={`wl-${idx}`}
                  ref={(el) => {
                    waveBarRefs.current[idx] = el;
                  }}
                  className="h-2 w-[3px] rounded-full bg-gradient-to-t from-[#0066FF] via-[#1E88FF] to-[#7DD3FC] shadow-[0_0_8px_rgba(56,189,248,0.8)] transition-[height,opacity] duration-75"
                />
              ))}
            </div>

            <div className="relative flex items-center justify-center">
              <div
                ref={micHaloRef}
                aria-hidden="true"
                className="pointer-events-none absolute -inset-3 rounded-full bg-[radial-gradient(circle,rgba(56,189,248,0.55),rgba(30,136,255,0.12)_65%,transparent_75%)] blur-md"
              />
              <button
                type="button"
                onClick={handleMicPress}
                aria-label={
                  orbState === 'LISTENING'
                    ? 'Stop voice listening'
                    : orbState === 'SPEAKING'
                      ? 'Stop AI speech'
                      : 'Start voice conversation'
                }
                className={`relative flex h-[86px] w-[86px] shrink-0 items-center justify-center rounded-full border-[3px] bg-gradient-to-b from-[#0A2558] via-[#061538] to-[#030A1F] text-white transition-transform duration-150 hover:scale-105 active:scale-95 ${
                  orbState === 'LISTENING'
                    ? 'animate-pulse border-[#7DD3FC] shadow-[0_0_46px_rgba(56,189,248,1),inset_0_0_24px_rgba(56,189,248,0.65)]'
                    : orbState === 'SPEAKING'
                      ? 'border-[#38BDF8] shadow-[0_0_40px_rgba(30,136,255,0.95),inset_0_0_20px_rgba(56,189,248,0.55)]'
                      : 'border-[#38BDF8] shadow-[0_0_34px_rgba(30,136,255,0.9),inset_0_0_16px_rgba(56,189,248,0.45)]'
                }`}
              >
                {orbState === 'LISTENING' ? (
                  <MicOff className="h-9 w-9 text-white drop-shadow-[0_0_12px_rgba(125,211,252,0.9)]" />
                ) : (
                  <Mic className="h-9 w-9 text-white drop-shadow-[0_0_12px_rgba(125,211,252,0.9)]" />
                )}
              </button>
            </div>

            <div className="flex h-11 items-center gap-1" aria-hidden="true">
              {[8, 9, 10, 11, 12, 13, 14, 15].map((idx) => (
                <span
                  key={`wr-${idx}`}
                  ref={(el) => {
                    waveBarRefs.current[idx] = el;
                  }}
                  className="h-2 w-[3px] rounded-full bg-gradient-to-t from-[#0066FF] via-[#1E88FF] to-[#7DD3FC] shadow-[0_0_8px_rgba(56,189,248,0.8)] transition-[height,opacity] duration-75"
                />
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Functional Text-Chat Interface Overlay (Opened ONLY by Chat Button) */}
      {chatOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="SMW AI Text Chat"
          className="fixed inset-0 z-50 flex items-end justify-center bg-[#02050D]/85 backdrop-blur-md sm:items-center sm:p-4"
        >
          <div className="flex h-[88dvh] w-full max-w-xl flex-col overflow-hidden rounded-t-3xl border border-[#1E88FF]/45 bg-gradient-to-b from-[#060E20] via-[#030816] to-[#02050D] shadow-[0_0_60px_rgba(30,136,255,0.35)] sm:h-[82vh] sm:rounded-3xl">
            {/* Minimal Chat Header */}
            <div className="flex items-center justify-between border-b border-[#1E88FF]/20 px-5 py-3.5">
              <div className="flex items-center gap-3">
                <img
                  src={SMW_AVATAR_BG}
                  alt="SMW AI"
                  className="h-9 w-9 rounded-full border border-[#38BDF8] object-cover object-top"
                />
                <h2 className="font-display text-base font-bold tracking-wide text-white">
                  SMW <span className="text-[#38BDF8]">AI</span>
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setChatOpen(false)}
                aria-label="Close chat"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full border border-slate-700/80 bg-[#071126] text-slate-200 transition-colors hover:border-[#38BDF8] hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Conversation Stream */}
            <div ref={chatScrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
              {messages.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center px-6 text-center">
                  <p className="text-sm text-slate-300">
                    Type a message or command in Punjabi, Urdu, Hindi, or English.
                  </p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isUser = msg.role === 'user';
                  return (
                    <div
                      key={msg.id}
                      className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                        isUser
                          ? 'ml-8 border border-[#1E88FF]/45 bg-[#0E2046]/90 text-white'
                          : 'mr-8 border border-slate-700/60 bg-[#050C1B]/95 text-slate-100'
                      }`}
                    >
                      <p className="break-words">{msg.text}</p>
                      {msg.pendingConfirmation && (
                        <div className="mt-3 flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              void handleSendCommand(msg.pendingConfirmation!.rawCommand, true)
                            }
                            className="min-h-[40px] rounded-xl bg-[#1677FF] px-4 py-1.5 text-xs font-semibold text-white hover:bg-[#2684FF]"
                          >
                            Approve &amp; Send
                          </button>
                          <button
                            type="button"
                            onClick={handleCancelConfirmation}
                            className="min-h-[40px] rounded-xl border border-slate-700 bg-[#040917] px-4 py-1.5 text-xs font-medium text-slate-300 hover:border-slate-500 hover:text-white"
                          >
                            Cancel
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
              {orbState === 'THINKING' && (
                <div className="mr-8 rounded-2xl border border-[#1E88FF]/30 bg-[#050C1B]/95 px-4 py-3 text-xs text-sky-300">
                  SMW AI is thinking...
                </div>
              )}
            </div>

            {/* Text Input Form */}
            <form
              onSubmit={handleSubmitText}
              className="flex items-center gap-2 border-t border-[#1E88FF]/20 bg-[#030816] px-4 py-3"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                autoFocus
                className="min-h-[44px] min-w-0 flex-1 rounded-full border border-[#1E88FF]/35 bg-[#08132B] px-4 text-sm text-white placeholder:text-slate-400 focus:border-[#38BDF8] focus:outline-none"
              />
              <button
                type="submit"
                aria-label="Send message"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#1677FF] text-white shadow-[0_0_18px_rgba(22,119,255,0.65)] transition-colors hover:bg-[#2684FF]"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
