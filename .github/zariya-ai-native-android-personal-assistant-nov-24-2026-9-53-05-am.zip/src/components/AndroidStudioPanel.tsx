import { useEffect, useState } from 'react';
import { Copy, Check, Download, FileCode2, Terminal } from 'lucide-react';
import { AndroidFileEntry } from '../types/assistant';

export function AndroidStudioPanel() {
  const [files, setFiles] = useState<AndroidFileEntry[]>([]);
  const [selectedPath, setSelectedPath] = useState<string>(
    'app/src/main/AndroidManifest.xml',
  );
  const [fileContent, setFileContent] = useState<string>('');
  const [loadingFile, setLoadingFile] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch('/api/android/tree')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data.files)) {
          setFiles(data.files);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!selectedPath) return;
    setLoadingFile(true);
    fetch(`/api/android/file?path=${encodeURIComponent(selectedPath)}`)
      .then((r) => r.json())
      .then((data) => {
        setFileContent(data.content || '');
        setLoadingFile(false);
      })
      .catch(() => {
        setFileContent('Unable to load file.');
        setLoadingFile(false);
      });
  }, [selectedPath]);

  const handleCopy = () => {
    navigator.clipboard.writeText(fileContent);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="space-y-8">
      {/* Top Row: Setup, APK Compilation & Feature Compatibility Matrix */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        <section className="flex flex-col gap-4 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-5">
          <div className="flex items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
            <div>
              <h2 className="text-lg font-semibold text-slate-100">
                Android Studio &amp; APK Build
              </h2>
              <p className="text-xs text-slate-400">
                Kotlin 2.0 · Jetpack Compose · Compile SDK 35 · Min SDK 26
              </p>
            </div>
            <a
              href="/api/android/download-zip"
              className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-medium text-white hover:bg-blue-500"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export ZIP</span>
            </a>
          </div>

          <div className="space-y-3 text-xs leading-relaxed text-slate-300">
            <div>
              <p className="font-semibold text-slate-100">1. Open Project</p>
              <p className="mt-0.5 text-slate-400">
                Download <span className="font-mono text-sky-400">SMW_AI-Android.zip</span> or open <span className="font-mono text-sky-400">android-app/</span> directly in Android Studio Ladybug (2024.2+) with JDK 17.
              </p>
            </div>
            <div>
              <p className="font-semibold text-slate-100">2. Configure Backend URL</p>
              <p className="mt-0.5 text-slate-400">
                Set <span className="font-mono text-sky-400">ZARIYA_BACKEND_URL</span> in <span className="font-mono">gradle.properties</span> to keep the Gemini API key safely on the Express server.
              </p>
            </div>
            <div>
              <p className="font-semibold text-slate-100">3. Compile Android APK</p>
              <pre className="mt-1.5 overflow-x-auto rounded-xl border border-slate-800 bg-[#05070B] p-3 font-mono text-xs text-sky-300">
                <Terminal className="mb-1 inline h-3.5 w-3.5 text-slate-400" />{' '}
                {`cd android-app\n./gradlew assembleDebug\n# APK -> app/build/outputs/apk/debug/app-debug.apk`}
              </pre>
            </div>
          </div>
        </section>

        {/* Working vs Android-Restricted Capabilities */}
        <section className="flex flex-col gap-4 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-7">
          <div className="border-b border-slate-800/80 pb-4">
            <h2 className="text-lg font-semibold text-slate-100">
              Native Capabilities vs. Android OS Restrictions
            </h2>
            <p className="text-xs text-slate-400">
              Transparent engineering documentation — no hidden workarounds or false claims
            </p>
          </div>

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
                Working Native Features
              </h3>
              <ul className="space-y-1.5 text-xs text-slate-300">
                <li>SpeechRecognizer voice input + TTS Male/Female output with voice barge-in</li>
                <li>Explicit Foreground Service hands-free mode with persistent notification</li>
                <li>AccessibilityService screen text reading, scrolling, clicking, back &amp; text fill</li>
                <li>MediaProjection screen recording (MP4), pause/resume, &amp; Gemini Vision snapshot</li>
                <li>NotificationListenerService WhatsApp reader, urgency check &amp; RemoteInput reply</li>
                <li>CallScreeningService caller ID announcement &amp; TelecomManager answer/end/speaker</li>
                <li>DeviceControlManager: app launch, flashlight, volume, media, alarms, share</li>
                <li>AES256-GCM EncryptedSharedPreferences local memory</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-amber-400">
                Restricted by Android OS (Supported Alternatives)
              </h3>
              <ul className="space-y-2 text-xs text-slate-300">
                <li>
                  <strong className="text-slate-100">Silent Background Mic / Closed-Screen DSP Wake Word:</strong>{' '}
                  Android 14+ blocks silent background mic start. Supported alternative: user-activated <span className="font-mono">JarvisForegroundService</span> with visible notification.
                </li>
                <li>
                  <strong className="text-slate-100">Injecting AI Voice Into Cellular Call Uplink:</strong>{' '}
                  Third-party apps cannot inject TTS audio directly into cellular carrier voice streams. Supported alternative: <span className="font-mono">CallScreeningService</span> + Telecom answer/end + AI-disclosed SMS busy notice.
                </li>
                <li>
                  <strong className="text-slate-100">FLAG_SECURE &amp; Password Fields:</strong>{' '}
                  Protected banking/auth screens block MediaProjection &amp; Accessibility by OS policy and are explicitly respected.
                </li>
              </ul>
            </div>
          </div>
        </section>
      </div>

      {/* Bottom Row: Interactive Native Android Source Code Explorer */}
      <section className="grid grid-cols-1 overflow-hidden rounded-2xl border border-slate-800/90 bg-[#0B101B] lg:grid-cols-12">
        <aside className="max-h-[540px] overflow-y-auto border-b border-slate-800/80 bg-[#070B14] p-4 lg:col-span-4 lg:border-b-0 lg:border-r">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-200">
              Native Project Files ({files.length})
            </span>
          </div>
          <div className="space-y-1">
            {files.map((f) => {
              const active = f.path === selectedPath;
              return (
                <button
                  key={f.path}
                  type="button"
                  onClick={() => setSelectedPath(f.path)}
                  className={`flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-1.5 text-left font-mono text-xs transition-colors ${
                    active
                      ? 'bg-blue-600/20 text-sky-300'
                      : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                  }`}
                >
                  <span className="flex min-w-0 items-center gap-2">
                    <FileCode2 className="h-3.5 w-3.5 shrink-0" />
                    <span className="truncate">{f.path}</span>
                  </span>
                  <span className="shrink-0 tabular-nums text-[11px] text-slate-500">
                    {(f.size / 1024).toFixed(1)}k
                  </span>
                </button>
              );
            })}
          </div>
        </aside>

        <div className="flex max-h-[540px] flex-col lg:col-span-8">
          <div className="flex items-center justify-between gap-4 border-b border-slate-800/80 px-5 py-3">
            <span className="truncate font-mono text-xs text-sky-400">{selectedPath}</span>
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-slate-700 bg-[#070B14] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-blue-500"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Code'}</span>
            </button>
          </div>
          <pre className="flex-1 overflow-auto bg-[#05070B] p-5 font-mono text-xs leading-relaxed text-slate-200">
            {loadingFile ? 'Loading file...' : fileContent}
          </pre>
        </div>
      </section>
    </div>
  );
}
