import { useState } from 'react';
import { Phone, PhoneOff, Volume2, MessageSquare, ShieldCheck, Clock } from 'lucide-react';
import {
  AutoReplyAudience,
  AutoReplyRule,
  CallConfig,
  CallSession,
  WhatsAppMessage,
} from '../types/assistant';

interface AutomationPanelProps {
  whatsappMessages: WhatsAppMessage[];
  autoReplyRule: AutoReplyRule;
  priorityContacts: string[];
  templates: string[];
  callConfig: CallConfig;
  activeCall: CallSession | null;
  notificationPermissionGranted: boolean;
  callPermissionGranted: boolean;
  onUpdateAutoReply: (patch: Partial<AutoReplyRule>) => void;
  onAddTemplate: (tpl: string) => void;
  onReplyWhatsApp: (id: string, text: string) => void;
  onSimulateIncomingWhatsApp: (sender: string, text: string) => Promise<void>;
  onReadMessageAloud: (text: string) => void;
  onUpdateCallConfig: (patch: Partial<CallConfig>) => void;
  onSimulateCall: (callerName: string | null, phone: string) => void;
  onCallAction: (action: 'ANSWER' | 'REJECT' | 'END' | 'SPEAKER' | 'BUSY_NOTICE') => void;
  onGrantPermission: (id: string) => void;
}

export function AutomationPanel({
  whatsappMessages,
  autoReplyRule,
  priorityContacts,
  templates,
  callConfig,
  activeCall,
  notificationPermissionGranted,
  callPermissionGranted,
  onUpdateAutoReply,
  onAddTemplate,
  onReplyWhatsApp,
  onSimulateIncomingWhatsApp,
  onReadMessageAloud,
  onUpdateCallConfig,
  onSimulateCall,
  onCallAction,
  onGrantPermission,
}: AutomationPanelProps) {
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [simSender, setSimSender] = useState('Ali');
  const [simText, setSimText] = useState('Bhai urgent hai, meeting 5 min mein start ho rahi hai!');
  const [newTemplate, setNewTemplate] = useState('');
  const [simBusy, setSimBusy] = useState(false);

  const handleSimMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!simSender.trim() || !simText.trim()) return;
    setSimBusy(true);
    await onSimulateIncomingWhatsApp(simSender.trim(), simText.trim());
    setSimBusy(false);
  };

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
      {/* Left: WhatsApp Notification Reader & Auto-Reply Rules */}
      <section className="flex flex-col gap-6 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-7">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-100">
              WhatsApp Notification Reader &amp; Auto-Reply
            </h2>
            <p className="text-xs text-slate-400">
              WhatsApp &amp; WhatsApp Business · Priority contacts, schedules &amp; repeat cooldown
            </p>
          </div>
          {!notificationPermissionGranted && (
            <button
              type="button"
              onClick={() => onGrantPermission('notif_listener')}
              className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500"
            >
              Allow Notification Listener
            </button>
          )}
        </div>

        {/* Auto-Reply Rule Engine */}
        <div className="space-y-4 rounded-xl border border-slate-800 bg-[#070B14] p-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-slate-100">Automatic Reply Mode</p>
              <p className="text-xs text-slate-400">
                Never sends replies unless enabled here or explicitly confirmed
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={autoReplyRule.enabled}
              onClick={() => onUpdateAutoReply({ enabled: !autoReplyRule.enabled })}
              className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full border transition-colors ${
                autoReplyRule.enabled
                  ? 'border-blue-500 bg-blue-600'
                  : 'border-slate-700 bg-slate-800'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                  autoReplyRule.enabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="text-xs text-slate-400">Who Receives Auto-Replies</label>
              <select
                value={autoReplyRule.audience}
                onChange={(e) =>
                  onUpdateAutoReply({ audience: e.target.value as AutoReplyAudience })
                }
                className="mt-1 w-full rounded-lg border border-slate-800 bg-[#0B101B] px-3 py-2 text-xs text-slate-100 focus:border-blue-500 focus:outline-none"
              >
                <option value="SELECTED_CONTACTS_ONLY">Selected Contacts Only</option>
                <option value="PRIORITY_CONTACTS_ONLY">Priority Contacts Only</option>
                <option value="EVERYONE_EXPLICIT">Everyone (Explicit User Mode)</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-400">Repeat Reply Cooldown (min)</label>
              <input
                type="number"
                min={5}
                max={240}
                value={autoReplyRule.cooldownMinutes}
                onChange={(e) =>
                  onUpdateAutoReply({ cooldownMinutes: Math.max(5, Number(e.target.value)) })
                }
                className="mt-1 w-full rounded-lg border border-slate-800 bg-[#0B101B] px-3 py-2 font-mono text-xs tabular-nums text-slate-100 focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 border-t border-slate-800/70 pt-3">
            <label className="flex items-center gap-2 text-xs text-slate-300">
              <input
                type="checkbox"
                checked={autoReplyRule.scheduleEnabled}
                onChange={(e) => onUpdateAutoReply({ scheduleEnabled: e.target.checked })}
                className="accent-blue-600"
              />
              <Clock className="h-3.5 w-3.5 text-sky-400" />
              <span>Working Hours Schedule ({autoReplyRule.startHour}:00 - {autoReplyRule.endHour}:00)</span>
            </label>
            <span className="text-xs text-slate-400">
              Priority: {priorityContacts.join(', ')}
            </span>
          </div>

          {/* Reply Templates */}
          <div className="space-y-2 border-t border-slate-800/70 pt-3">
            <p className="text-xs font-medium text-slate-300">Active Auto-Reply Template</p>
            <select
              value={autoReplyRule.activeTemplate}
              onChange={(e) => onUpdateAutoReply({ activeTemplate: e.target.value })}
              className="w-full rounded-lg border border-slate-800 bg-[#0B101B] px-3 py-2 text-xs text-slate-100 focus:border-blue-500 focus:outline-none"
            >
              {templates.map((tpl, i) => (
                <option key={i} value={tpl}>
                  {tpl}
                </option>
              ))}
            </select>
            <div className="flex gap-2">
              <input
                type="text"
                value={newTemplate}
                onChange={(e) => setNewTemplate(e.target.value)}
                placeholder="Add custom Urdu / Roman Urdu / English template..."
                className="flex-1 rounded-lg border border-slate-800 bg-[#0B101B] px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => {
                  if (!newTemplate.trim()) return;
                  onAddTemplate(newTemplate.trim());
                  onUpdateAutoReply({ activeTemplate: newTemplate.trim() });
                  setNewTemplate('');
                }}
                className="rounded-lg border border-slate-700 bg-[#0B101B] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-blue-500"
              >
                Add
              </button>
            </div>
          </div>
        </div>

        {/* Incoming Notification Simulator */}
        <form onSubmit={handleSimMessage} className="grid grid-cols-1 gap-2 sm:grid-cols-12">
          <input
            type="text"
            value={simSender}
            onChange={(e) => setSimSender(e.target.value)}
            placeholder="Sender"
            className="rounded-xl border border-slate-800 bg-[#070B14] px-3 py-2 text-xs text-slate-100 sm:col-span-3"
          />
          <input
            type="text"
            value={simText}
            onChange={(e) => setSimText(e.target.value)}
            placeholder="Incoming WhatsApp message..."
            className="rounded-xl border border-slate-800 bg-[#070B14] px-3 py-2 text-xs text-slate-100 sm:col-span-6"
          />
          <button
            type="submit"
            disabled={simBusy}
            className="rounded-xl bg-blue-600 px-3 py-2 text-xs font-medium text-white hover:bg-blue-500 disabled:opacity-50 sm:col-span-3"
          >
            {simBusy ? 'Analyzing...' : 'Test Incoming Msg'}
          </button>
        </form>

        {/* Authorized Message Stream */}
        <div className="space-y-3">
          {whatsappMessages.map((msg) => (
            <div
              key={msg.id}
              className="rounded-xl border border-slate-800 bg-[#070B14] p-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-3.5 w-3.5 text-sky-400" />
                  <span className="font-semibold text-slate-100">{msg.sender}</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-400">{msg.appSource}</span>
                  {msg.isUrgent && (
                    <>
                      <span className="text-slate-500">·</span>
                      <span className="font-semibold text-amber-400">Urgent</span>
                    </>
                  )}
                </div>
                <span className="font-mono tabular-nums text-slate-500">{msg.timestamp}</span>
              </div>

              <p className="mt-2 text-sm text-slate-200">{msg.text}</p>
              {msg.urgencyReason && (
                <p className="mt-1 text-xs text-slate-400">AI Assessment: {msg.urgencyReason}</p>
              )}

              {msg.autoReplied && msg.repliedText && (
                <p className="mt-2 text-xs text-emerald-400">
                  Auto-replied via RemoteInput: &ldquo;{msg.repliedText}&rdquo;
                </p>
              )}

              <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-800/70 pt-3">
                <button
                  type="button"
                  onClick={() => onReadMessageAloud(`${msg.sender} says: ${msg.text}`)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 px-2.5 py-1 text-xs text-slate-300 hover:text-white"
                >
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>Read Aloud</span>
                </button>

                <input
                  type="text"
                  value={replyDrafts[msg.id] ?? msg.aiDraftReply ?? ''}
                  onChange={(e) =>
                    setReplyDrafts((prev) => ({ ...prev, [msg.id]: e.target.value }))
                  }
                  placeholder="Write reply..."
                  className="flex-1 rounded-lg border border-slate-800 bg-[#0B101B] px-3 py-1 text-xs text-slate-100"
                />
                <button
                  type="button"
                  onClick={() =>
                    onReplyWhatsApp(msg.id, replyDrafts[msg.id] ?? msg.aiDraftReply ?? '')
                  }
                  className="rounded-lg bg-blue-600 px-3 py-1 text-xs font-medium text-white hover:bg-blue-500"
                >
                  Send Reply
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Right: Telecom Call Screening & Hands-Free Call Assistant */}
      <section className="flex flex-col gap-6 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-100">Telecom Call Assistant</h2>
            <p className="text-xs text-slate-400">
              CallScreeningService &amp; TelecomManager · Discloses AI identity, never impersonates
            </p>
          </div>
          {!callPermissionGranted && (
            <button
              type="button"
              onClick={() => onGrantPermission('phone')}
              className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500"
            >
              Allow Phone Control
            </button>
          )}
        </div>

        <div className="space-y-3 rounded-xl border border-slate-800 bg-[#070B14] p-4">
          <label className="flex items-center justify-between text-sm text-slate-200">
            <span>Announce Incoming Caller Aloud</span>
            <input
              type="checkbox"
              checked={callConfig.announceCallerAloud}
              onChange={(e) => onUpdateCallConfig({ announceCallerAloud: e.target.checked })}
              className="h-4 w-4 accent-blue-600"
            />
          </label>
          <label className="flex items-center justify-between text-sm text-slate-200">
            <span>Auto-Answer Selected Contacts</span>
            <input
              type="checkbox"
              checked={callConfig.autoAnswerSelectedContacts}
              onChange={(e) =>
                onUpdateCallConfig({ autoAnswerSelectedContacts: e.target.checked })
              }
              className="h-4 w-4 accent-blue-600"
            />
          </label>
          <label className="flex items-center justify-between text-sm text-slate-200">
            <span>Hands-Free Speakerphone Default</span>
            <input
              type="checkbox"
              checked={callConfig.handsFreeMode}
              onChange={(e) => onUpdateCallConfig({ handsFreeMode: e.target.checked })}
              className="h-4 w-4 accent-blue-600"
            />
          </label>

          <div className="border-t border-slate-800/70 pt-3">
            <label className="flex items-center gap-1.5 text-xs font-medium text-sky-400">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>AI Assistant Caller Disclosure Notice</span>
            </label>
            <textarea
              rows={2}
              value={callConfig.busyNotice}
              onChange={(e) => onUpdateCallConfig({ busyNotice: e.target.value })}
              className="mt-1.5 w-full rounded-lg border border-slate-800 bg-[#0B101B] p-2.5 text-xs text-slate-200 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => onSimulateCall('Ali', '+92 300 5550142')}
            className="flex-1 rounded-xl border border-slate-700 bg-[#070B14] px-3 py-2 text-xs font-medium text-slate-200 hover:border-blue-500"
          >
            Simulate Priority Call (Ali)
          </button>
          <button
            type="button"
            onClick={() => onSimulateCall(null, '+92 321 9988110')}
            className="flex-1 rounded-xl border border-slate-700 bg-[#070B14] px-3 py-2 text-xs font-medium text-slate-200 hover:border-blue-500"
          >
            Simulate Unknown Call
          </button>
        </div>

        {activeCall ? (
          <div className="space-y-4 rounded-xl border border-blue-500/40 bg-[#070B14] p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-base font-semibold text-slate-100">
                  {activeCall.callerName || 'Unknown Caller'}
                </p>
                <p className="font-mono text-xs tabular-nums text-slate-400">
                  {activeCall.phoneNumber}
                </p>
              </div>
              <span className="font-mono text-xs font-semibold text-sky-400">
                {activeCall.status}
              </span>
            </div>

            {activeCall.aiDisclosureSent && (
              <p className="rounded-lg border border-slate-800 bg-[#0B101B] p-2.5 text-xs text-slate-300">
                {activeCall.aiDisclosureSent}
              </p>
            )}

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onCallAction('ANSWER')}
                className="flex min-h-[40px] items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-medium text-white hover:bg-emerald-500"
              >
                <Phone className="h-3.5 w-3.5" />
                <span>Answer Call</span>
              </button>
              <button
                type="button"
                onClick={() => onCallAction(activeCall.status === 'ACTIVE' ? 'END' : 'REJECT')}
                className="flex min-h-[40px] items-center justify-center gap-1.5 rounded-xl bg-red-600 px-3 py-2 text-xs font-medium text-white hover:bg-red-500"
              >
                <PhoneOff className="h-3.5 w-3.5" />
                <span>{activeCall.status === 'ACTIVE' ? 'End Call' : 'Reject Call'}</span>
              </button>
              <button
                type="button"
                onClick={() => onCallAction('SPEAKER')}
                className="flex min-h-[40px] items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-[#0B101B] px-3 py-2 text-xs font-medium text-slate-200"
              >
                <Volume2 className="h-3.5 w-3.5" />
                <span>Speaker {callConfig.speakerphoneActive ? 'On' : 'Off'}</span>
              </button>
              <button
                type="button"
                onClick={() => onCallAction('BUSY_NOTICE')}
                className="flex min-h-[40px] items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-[#0B101B] px-3 py-2 text-xs font-medium text-slate-200"
              >
                <span>Send AI Busy Notice</span>
              </button>
            </div>
          </div>
        ) : (
          <p className="rounded-xl border border-slate-800 bg-[#070B14] p-4 text-xs text-slate-400">
            No active call. Simulate an incoming call above or say &ldquo;Answer the call&rdquo; / &ldquo;Tell the caller I am busy&rdquo; in Jarvis Live Mode.
          </p>
        )}
      </section>
    </div>
  );
}
