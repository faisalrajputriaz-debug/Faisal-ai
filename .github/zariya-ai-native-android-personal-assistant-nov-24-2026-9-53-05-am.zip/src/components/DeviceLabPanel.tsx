import { useRef, useState } from 'react';
import {
  Camera,
  Eye,
  Flashlight,
  Monitor,
  Pause,
  Play,
  Square,
  Volume2,
  AlarmClock,
  SkipForward,
  StickyNote,
} from 'lucide-react';
import { DailyTask, DeviceHardwareState } from '../types/assistant';

interface DeviceLabPanelProps {
  hardware: DeviceHardwareState;
  accessibilityGranted: boolean;
  mediaProjectionGranted: boolean;
  cameraGranted: boolean;
  micGranted: boolean;
  dailyTasks: DailyTask[];
  onUpdateHardware: (patch: Partial<DeviceHardwareState>) => void;
  onAddDailyTask: (task: Omit<DailyTask, 'id' | 'createdAt'>) => void;
  onRunScreenReader: (mode: 'read' | 'explain' | 'click-reply') => void;
  onAnalyzeCapturedImage: (base64: string) => Promise<{
    summary: string;
    elements: string[];
    suggestedAction?: string;
  }>;
  onGrantPermission: (id: string) => void;
}

const SIMULATED_SCREENS: Record<
  DeviceHardwareState['activeScreenKey'],
  {
    app: string;
    headings: string[];
    buttons: string[];
    fields: string[];
    lines: string[];
    selectedText: string;
  }
> = {
  whatsapp: {
    app: 'WhatsApp · Ali Khan',
    headings: ['Ali Khan — Online', 'Today'],
    buttons: ['Voice Call', 'Video Call', 'Reply', 'Attach', 'Send'],
    fields: ['Message input box'],
    lines: [
      'Ali: Salam bhai, client presentation 4 PM ko confirm hui hai.',
      'Ali: Kya aap updated deck bhej sakte hain? Urgent hai.',
      'Protected field [PIN Lock] — skipped by AccessibilityService',
    ],
    selectedText: 'updated deck bhej sakte hain',
  },
  article: {
    app: 'Chrome · Android Architecture Guide',
    headings: ['Android Accessibility & MediaProjection', 'Privacy Boundaries'],
    buttons: ['Share', 'Bookmark', 'Back', 'Read More'],
    fields: ['Search or type URL'],
    lines: [
      'MediaProjection requires explicit user confirmation before each screen capture session.',
      'AccessibilityService reads non-password nodes to help hands-free navigation and screen summaries.',
      'Foreground services must display a visible persistent notification on Android 14+.',
    ],
    selectedText: 'explicit user confirmation before each screen capture session',
  },
  settings: {
    app: 'Android Settings · Connected Devices',
    headings: ['Connected devices', 'Audio & Flashlight'],
    buttons: ['Pair new device', 'Connection preferences', 'Back'],
    fields: ['Search settings'],
    lines: [
      'Bluetooth: Ready to connect',
      'Default digital assistant app: SMW AI',
      'Call screening role: Available',
    ],
    selectedText: 'Default digital assistant app',
  },
};

export function DeviceLabPanel({
  hardware,
  accessibilityGranted,
  mediaProjectionGranted,
  cameraGranted,
  micGranted,
  dailyTasks,
  onUpdateHardware,
  onAddDailyTask,
  onRunScreenReader,
  onAnalyzeCapturedImage,
  onGrantPermission,
}: DeviceLabPanelProps) {
  const [recState, setRecState] = useState<'IDLE' | 'RECORDING' | 'PAUSED'>('IDLE');
  const [includeMic, setIncludeMic] = useState(false);
  const [recordedUrl, setRecordedUrl] = useState<string | null>(null);
  const [capturedPreview, setCapturedPreview] = useState<string | null>(null);
  const [visionResult, setVisionResult] = useState<{
    summary: string;
    elements: string[];
    suggestedAction?: string;
  } | null>(null);
  const [visionLoading, setVisionLoading] = useState(false);
  const [captureError, setCaptureError] = useState<string | null>(null);
  const [noteInput, setNoteInput] = useState('');

  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const activeScreen = SIMULATED_SCREENS[hardware.activeScreenKey];

  const startLiveScreenCapture = async (mode: 'record' | 'snapshot') => {
    setCaptureError(null);
    if (!mediaProjectionGranted) {
      setCaptureError('Screen Capture permission is disabled in the Permissions Dashboard. Grant MediaProjection first.');
      return;
    }
    if (includeMic && !micGranted) {
      setCaptureError('Microphone permission must be granted separately before recording audio with screen.');
      return;
    }

    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 24 },
        audio: false,
      });

      if (mode === 'snapshot') {
        const video = document.createElement('video');
        video.srcObject = displayStream;
        await video.play();
        const canvas = document.createElement('canvas');
        canvas.width = Math.min(video.videoWidth || 1280, 1280);
        canvas.height = Math.round((canvas.width / (video.videoWidth || 1280)) * (video.videoHeight || 720));
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        displayStream.getTracks().forEach((t) => t.stop());

        setCapturedPreview(dataUrl);
        setVisionLoading(true);
        const analysis = await onAnalyzeCapturedImage(dataUrl);
        setVisionResult(analysis);
        setVisionLoading(false);
        return;
      }

      let combinedStream = displayStream;
      if (includeMic) {
        const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        combinedStream = new MediaStream([
          ...displayStream.getVideoTracks(),
          ...micStream.getAudioTracks(),
        ]);
      }

      streamRef.current = combinedStream;
      chunksRef.current = [];
      const recorder = new MediaRecorder(combinedStream, { mimeType: 'video/webm' });
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunksRef.current.push(ev.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        setRecordedUrl(URL.createObjectURL(blob));
        combinedStream.getTracks().forEach((t) => t.stop());
        setRecState('IDLE');
      };
      displayStream.getVideoTracks()[0].onended = () => {
        if (recorder.state !== 'inactive') recorder.stop();
      };
      recorder.start(500);
      recorderRef.current = recorder;
      setRecState('RECORDING');
    } catch (err) {
      setVisionLoading(false);
      setCaptureError(
        err instanceof Error ? err.message : 'Screen capture authorization was cancelled or unavailable.',
      );
    }
  };

  const pauseOrResumeRecording = () => {
    const rec = recorderRef.current;
    if (!rec) return;
    if (rec.state === 'recording') {
      rec.pause();
      setRecState('PAUSED');
    } else if (rec.state === 'paused') {
      rec.resume();
      setRecState('RECORDING');
    }
  };

  const stopRecording = () => {
    recorderRef.current?.stop();
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteInput.trim()) return;
    onAddDailyTask({
      type: 'note',
      title: noteInput.trim(),
      detail: 'Created from Device Lab',
    });
    setNoteInput('');
  };

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
      {/* Left: Accessibility Screen Reader & Device Controls */}
      <section className="flex flex-col gap-6 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-6">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-100">Accessibility Screen Reader</h2>
            <p className="text-xs text-slate-400">
              Reads headings, buttons, text fields, selected text · Skips password nodes
            </p>
          </div>
          {!accessibilityGranted && (
            <button
              type="button"
              onClick={() => onGrantPermission('accessibility')}
              className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500"
            >
              Enable Accessibility
            </button>
          )}
        </div>

        {/* Simulated Foreground App Switcher */}
        <div className="flex items-center gap-1 rounded-xl bg-[#070B14] p-1">
          {(['whatsapp', 'article', 'settings'] as const).map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => onUpdateHardware({ activeScreenKey: key, screenScrollIndex: 0 })}
              className={`flex-1 rounded-lg px-3 py-2 text-xs font-medium capitalize transition-colors ${
                hardware.activeScreenKey === key
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {key}
            </button>
          ))}
        </div>

        {/* Accessible Node Tree Inspector */}
        <div className="rounded-xl border border-slate-800 bg-[#070B14] p-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 text-xs">
            <span className="font-semibold text-sky-400">{activeScreen.app}</span>
            <span className="font-mono tabular-nums text-slate-400">
              Scroll Offset: {hardware.screenScrollIndex}px
            </span>
          </div>
          <div className="mt-3 space-y-2 text-sm text-slate-200">
            {activeScreen.lines.map((line, i) => (
              <p
                key={i}
                className={
                  line.includes('Protected field') ? 'font-mono text-xs text-slate-500' : ''
                }
              >
                {line}
              </p>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 border-t border-slate-800/80 pt-3 text-xs">
            <div>
              <span className="text-slate-400">Buttons: </span>
              <span className="text-slate-200">{activeScreen.buttons.join(', ')}</span>
            </div>
            <div>
              <span className="text-slate-400">Selected: </span>
              <span className="text-sky-400">&ldquo;{activeScreen.selectedText}&rdquo;</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <button
            type="button"
            onClick={() => onRunScreenReader('read')}
            className="flex min-h-[40px] items-center justify-center gap-2 rounded-xl bg-blue-600 px-3 py-2 text-xs font-medium text-white hover:bg-blue-500"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>Read My Screen</span>
          </button>
          <button
            type="button"
            onClick={() => onRunScreenReader('explain')}
            className="flex min-h-[40px] items-center justify-center gap-2 rounded-xl border border-slate-700 bg-[#070B14] px-3 py-2 text-xs font-medium text-slate-200 hover:border-slate-500"
          >
            <span>Explain Page</span>
          </button>
          <button
            type="button"
            onClick={() => onRunScreenReader('click-reply')}
            className="flex min-h-[40px] items-center justify-center gap-2 rounded-xl border border-slate-700 bg-[#070B14] px-3 py-2 text-xs font-medium text-slate-200 hover:border-slate-500"
          >
            <span>Click Reply</span>
          </button>
        </div>

        {/* Native Hardware & Intent Controls */}
        <div className="border-t border-slate-800/80 pt-4">
          <h3 className="text-sm font-semibold text-slate-100">Device Control Layer</h3>
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <button
              type="button"
              onClick={() => {
                if (!cameraGranted) {
                  onGrantPermission('camera');
                  return;
                }
                onUpdateHardware({ flashlightOn: !hardware.flashlightOn });
              }}
              className={`flex min-h-[42px] items-center justify-center gap-2 rounded-xl border px-3 py-2 text-xs font-medium transition-colors ${
                hardware.flashlightOn
                  ? 'border-blue-500 bg-blue-600/20 text-sky-300'
                  : 'border-slate-800 bg-[#070B14] text-slate-300'
              }`}
            >
              <Flashlight className="h-4 w-4" />
              <span>Torch {hardware.flashlightOn ? 'On' : 'Off'}</span>
            </button>

            <button
              type="button"
              onClick={() => onUpdateHardware({ mediaPlaying: !hardware.mediaPlaying })}
              className="flex min-h-[42px] items-center justify-center gap-2 rounded-xl border border-slate-800 bg-[#070B14] px-3 py-2 text-xs font-medium text-slate-200 hover:border-slate-600"
            >
              {hardware.mediaPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              <span>{hardware.mediaPlaying ? 'Pause' : 'Play'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                onUpdateHardware({
                  mediaTrack:
                    hardware.mediaTrack === 'Ambient Focus Mix'
                      ? 'Evening Briefing Audio'
                      : 'Ambient Focus Mix',
                })
              }
              className="flex min-h-[42px] items-center justify-center gap-2 rounded-xl border border-slate-800 bg-[#070B14] px-3 py-2 text-xs font-medium text-slate-200 hover:border-slate-600"
            >
              <SkipForward className="h-4 w-4" />
              <span>Next Track</span>
            </button>

            <button
              type="button"
              onClick={() =>
                onAddDailyTask({
                  type: 'alarm',
                  title: '07:00 AM Morning Alarm',
                  detail: 'Scheduled via AlarmClock intent',
                })
              }
              className="flex min-h-[42px] items-center justify-center gap-2 rounded-xl border border-slate-800 bg-[#070B14] px-3 py-2 text-xs font-medium text-slate-200 hover:border-slate-600"
            >
              <AlarmClock className="h-4 w-4" />
              <span>Set 7 AM Alarm</span>
            </button>
          </div>

          <div className="mt-4 flex items-center gap-4">
            <Volume2 className="h-4 w-4 text-sky-400" />
            <input
              type="range"
              min={0}
              max={100}
              value={hardware.volumePercent}
              onChange={(e) => onUpdateHardware({ volumePercent: Number(e.target.value) })}
              aria-label="Media volume"
              className="h-1.5 flex-1 accent-blue-600"
            />
            <span className="w-12 text-right font-mono text-xs tabular-nums text-slate-300">
              {hardware.volumePercent}%
            </span>
          </div>
        </div>
      </section>

      {/* Right: Real MediaProjection Screen Capture + Vision Analysis + Daily Notes */}
      <section className="flex flex-col gap-6 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-6">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-100">
              MediaProjection Screen Recorder &amp; Vision
            </h2>
            <p className="text-xs text-slate-400">
              Explicit user authorization required · Live browser display capture + Gemini Vision
            </p>
          </div>
          {!mediaProjectionGranted && (
            <button
              type="button"
              onClick={() => onGrantPermission('mediaprojection')}
              className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500"
            >
              Authorize Capture
            </button>
          )}
        </div>

        <div className="flex items-center justify-between gap-4 rounded-xl border border-slate-800 bg-[#070B14] px-4 py-3">
          <div>
            <p className="text-sm font-medium text-slate-200">Record Microphone Audio</p>
            <p className="text-xs text-slate-400">Requires separate Microphone permission</p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={includeMic}
            onClick={() => setIncludeMic((v) => !v)}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border transition-colors ${
              includeMic ? 'border-blue-500 bg-blue-600' : 'border-slate-700 bg-slate-800'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                includeMic ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        <div className="flex flex-wrap gap-3">
          {recState === 'IDLE' ? (
            <button
              type="button"
              onClick={() => startLiveScreenCapture('record')}
              className="flex min-h-[42px] items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-xs font-medium text-white hover:bg-blue-500"
            >
              <Monitor className="h-4 w-4" />
              <span>Start Screen Recording</span>
            </button>
          ) : (
            <>
              <button
                type="button"
                onClick={pauseOrResumeRecording}
                className="flex min-h-[42px] items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-xs font-medium text-white hover:bg-blue-500"
              >
                {recState === 'RECORDING' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                <span>{recState === 'RECORDING' ? 'Pause Recording' : 'Resume Recording'}</span>
              </button>
              <button
                type="button"
                onClick={stopRecording}
                className="flex min-h-[42px] items-center gap-2 rounded-xl border border-red-500/60 bg-red-950/30 px-4 py-2 text-xs font-medium text-red-300 hover:bg-red-950/50"
              >
                <Square className="h-4 w-4" />
                <span>Stop Recording</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => startLiveScreenCapture('snapshot')}
            className="flex min-h-[42px] items-center gap-2 rounded-xl border border-slate-700 bg-[#070B14] px-4 py-2 text-xs font-medium text-slate-200 hover:border-blue-500/60"
          >
            <Camera className="h-4 w-4" />
            <span>Capture &amp; Analyze Screen (Gemini Vision)</span>
          </button>
        </div>

        {captureError && (
          <p className="rounded-xl border border-amber-500/40 bg-amber-950/20 px-4 py-2.5 text-xs text-amber-300">
            {captureError}
          </p>
        )}

        {recordedUrl && (
          <div className="space-y-2 rounded-xl border border-slate-800 bg-[#070B14] p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-emerald-400">Recording Saved</span>
              <a
                href={recordedUrl}
                download="smw-ai-screen-recording.webm"
                className="text-xs font-medium text-blue-400 hover:text-blue-300"
              >
                Download WebM
              </a>
            </div>
            <video src={recordedUrl} controls className="max-h-48 w-full rounded-lg bg-black" />
          </div>
        )}

        {(visionLoading || visionResult) && (
          <div className="space-y-3 rounded-xl border border-slate-800 bg-[#070B14] p-4">
            {capturedPreview && (
              <img
                src={capturedPreview}
                alt="Captured screen frame"
                className="max-h-40 w-full rounded-lg border border-slate-800 object-cover"
              />
            )}
            {visionLoading ? (
              <p className="text-xs text-sky-400">Analyzing captured screen frame with Gemini AI...</p>
            ) : (
              visionResult && (
                <>
                  <p className="text-sm leading-relaxed text-slate-100">{visionResult.summary}</p>
                  {visionResult.elements.length > 0 && (
                    <p className="text-xs text-slate-400">
                      Detected elements: {visionResult.elements.join(' · ')}
                    </p>
                  )}
                  {visionResult.suggestedAction && (
                    <p className="text-xs text-sky-400">
                      Suggested next step: {visionResult.suggestedAction}
                    </p>
                  )}
                </>
              )
            )}
          </div>
        )}

        {/* Daily Notes & Reminders */}
        <div className="border-t border-slate-800/80 pt-4">
          <div className="flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-100">
              <StickyNote className="h-4 w-4 text-sky-400" />
              <span>Daily Notes, Alarms &amp; Reminders ({dailyTasks.length})</span>
            </h3>
          </div>
          <form onSubmit={handleSaveNote} className="mt-3 flex gap-2">
            <input
              type="text"
              value={noteInput}
              onChange={(e) => setNoteInput(e.target.value)}
              placeholder="Add quick note or reminder..."
              className="min-h-[40px] flex-1 rounded-xl border border-slate-800 bg-[#070B14] px-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
            />
            <button
              type="submit"
              className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-medium text-white hover:bg-blue-500"
            >
              Save
            </button>
          </form>
          <ul className="mt-3 max-h-36 space-y-2 overflow-y-auto text-xs">
            {dailyTasks.map((t) => (
              <li
                key={t.id}
                className="flex items-center justify-between gap-4 border-b border-slate-800/60 pb-2"
              >
                <div>
                  <span className="font-mono uppercase text-sky-400">{t.type}</span>
                  <span className="mx-2 text-slate-600">·</span>
                  <span className="text-slate-200">{t.title}</span>
                </div>
                <span className="font-mono tabular-nums text-slate-500">{t.createdAt}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
