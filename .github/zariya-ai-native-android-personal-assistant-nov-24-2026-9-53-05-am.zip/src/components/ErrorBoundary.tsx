import { Component, ErrorInfo, ReactNode } from 'react';
import { SmwEmblem } from './SmwEmblem';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = {
    hasError: false,
    errorMessage: '',
  };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error.message || 'An unexpected rendering issue occurred.',
    };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('SMW AI boundary caught error:', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen w-full flex-col items-center justify-center bg-[#02050D] px-6 text-center text-white">
          <div className="w-full max-w-sm rounded-3xl border border-[#1E88FF]/35 bg-[#0A1326] p-6 shadow-[0_0_50px_rgba(14,116,255,0.28)]">
            <div className="mx-auto h-24 w-24 overflow-hidden rounded-2xl border border-[#1E88FF]/50 bg-[#02050D]">
              <SmwEmblem alt="SMW AI" className="h-full w-full object-contain" />
            </div>
            <h1 className="mt-4 font-display text-xl font-bold text-white">
              SMW <span className="text-[#1E88FF]">AI</span> Recovery
            </h1>
            <p className="mt-2 text-xs leading-relaxed text-slate-300">
              {this.state.errorMessage}
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-5 inline-flex min-h-[44px] w-full items-center justify-center rounded-xl bg-[#1677FF] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#2585FF]"
            >
              Reload SMW AI
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
