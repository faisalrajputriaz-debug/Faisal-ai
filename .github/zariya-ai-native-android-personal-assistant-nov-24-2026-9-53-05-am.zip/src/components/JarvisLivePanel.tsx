import { useState } from 'react';
import { Mic, MicOff, Send, VolumeX, CheckCircle2, AlertTriangle, ShieldAlert } from 'lucide-react';
import {
  AssistantMemory,
  ChatEntry,
  OrbState,
  TaskExecutionReport,
} from '../types/assistant';
import { JarvisOrb } from './JarvisOrb';

interface JarvisLivePanelProps {
  orbState: OrbState;
  memory: AssistantMemory;
  messages: ChatEntry[];
  latestReport: TaskExecutionReport | null;
  handsFreeMode: boolean;
  micPermissionGranted: boolean;
  partialTranscript: string;
  onToggleHandsFree: (enabled: boolean) => void;
  onToggleListen: () => void;
  onInterruptSpeech: () => void;
  onSendCommand: (text: string, confirmed?: boolean) => void;
  onRequestMicPermission: () => void;
  onNavigateToPermissions: () => void;
}

const SAMPLE_COMMANDS = [
  'Meri screen par kya likha hai?',
  'WhatsApp kholo aur latest message parho',
  'Ali ko bata do main busy hoon',
  'YouTube kholo aur search karo Lo-fi focus',
  'Turn on the flashlight',
  'Start screen recording',
  'Scroll down',
  'Set an alarm for 7 AM',
];

export function JarvisLivePanel({
  orbState,
  memory,
  messages,
  latestReport,
  handsFreeMode,
  micPermissionGranted,
  partialTranscript,
  onToggleHandsFree,
  onToggleListen,
  onInterruptSpeech,
  onSendCommand,
  onRequestMicPermission,
  onNavigateToPermissions,
}: JarvisLivePanelProps) {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    onSendCommand(input.trim());
    setInput('');
  };

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-start">
      {/* Left Column: Live Jarvis Orb & Controls */}
      <section className="flex flex-col gap-6 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-5">
        <div className="flex items-start justify-between gap-4 border-b border-slate-800/80 pb-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-slate-100">
              {memory.assistantName} Live Console
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              Urdu · Roman Urdu · Hindi · English · {memory.voiceGender === 'FEMALE' ? 'Female Voice' : 'Male Voice'}
            </p>
          </div>
        </div>

        <div className="py-2">
          <JarvisOrb
            state={orbState}
            assistantName={memory.assistantName}
            onToggleListen={onToggleListen}
            onInterrupt={onInterruptSpeech}
          />
          {partialTranscript && (
            <p className="mt-3 text-center text-sm text-slate-200">
              &ldquo;{partialTranscript}&rdquo;
            </p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={micPermissionGranted ? onToggleListen : onRequestMicPermission}
            className="flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
          >
            {orbState === 'LISTENING' ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            <span className="whitespace-nowrap">
              {!micPermissionGranted
                ? 'Allow Microphone'
                : orbState === 'LISTENING'
                  ? 'Stop Listening'
                  : 'Speak Command'}
            </span>
          </button>

          <button
            type="button"
            onClick={onInterruptSpeech}
            className="flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-slate-700 bg-[#070B14] px-4 py-2.5 text-sm font-medium text-slate-200 transition-colors hover:border-slate-500 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
          >
            <VolumeX className="h-4 w-4" />
            <span className="whitespace-nowrap">Interrupt Voice</span>
          </button>
        </div>

        <div className="flex items-center justify-between gap-4 border-t border-slate-800/80 pt-4">
          <div>
            <p className="text-sm font-medium text-slate-100">Hands-Free Continuous Mode</p>
            <p className="text-xs text-slate-400">
              {memory.wakeWordRequired
                ? `Listening for wake phrase "${memory.wakePhrase}"`
                : 'Explicit continuous conversation loop'}
            </p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={handsFreeMode}
            onClick={() => onToggleHandsFree(!handsFreeMode)}
            className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full border transition-colors ${
              handsFreeMode
                ? 'border-blue-500 bg-blue-600'
                : 'border-slate-700 bg-slate-800'
            }`}
          >
            <span
              className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                handsFreeMode ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        {/* Truthful Task Execution Status */}
        <div className="border-t border-slate-800/80 pt-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200">Last Task Status</h2>
            {latestReport && (
              <span
                className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                  latestReport.succeeded ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {latestReport.succeeded ? (
                  <CheckCircle2 className="h-3.5 w-3.5" />
                ) : (
                  <AlertTriangle className="h-3.5 w-3.5" />
                )}
                {latestReport.succeeded ? 'Succeeded' : 'Blocked or Incomplete'}
              </span>
            )}
          </div>

          {latestReport ? (
            <dl className="mt-3 space-y-2 text-xs">
              <div className="flex justify-between gap-4">
                <dt className="text-slate-400">Requested</dt>
                <dd className="text-right text-slate-200">{latestReport.userRequest}</dd>
              </div>
              {latestReport.executionSource && (
                <div className="flex justify-between gap-4">
                  <dt className="text-slate-400">Engine</dt>
                  <dd className="text-right text-sky-400">{latestReport.executionSource}</dd>
                </div>
              )}
              <div className="flex justify-between gap-4">
                <dt className="text-slate-400">Action</dt>
                <dd className="font-mono text-right text-sky-400">{latestReport.identifiedAction}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-slate-400">Permission</dt>
                <dd className="text-right text-slate-300">{latestReport.requiredPermission}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-slate-400">Outcome</dt>
                <dd className="text-right text-slate-200">{latestReport.actionPerformed}</dd>
              </div>
              {latestReport.failureReason && (
                <div className="flex items-center justify-between gap-4 pt-1 text-amber-300">
                  <dt>Reason</dt>
                  <dd className="text-right">{latestReport.failureReason}</dd>
                </div>
              )}
              {!latestReport.succeeded && (
                <button
                  type="button"
                  onClick={onNavigateToPermissions}
                  className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-blue-400 hover:text-blue-300"
                >
                  <ShieldAlert className="h-3.5 w-3.5" />
                  Review Permissions Dashboard
                </button>
              )}
            </dl>
          ) : (
            <p className="mt-2 text-xs text-slate-400">
              Give a voice or text command to inspect intent parsing, permission verification, and real execution outcome.
            </p>
          )}
        </div>
      </section>

      {/* Right Column: Multilingual Conversation & Quick Prompts */}
      <section className="flex flex-col rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-7">
        <div className="border-b border-slate-800/80 pb-4">
          <h2 className="text-lg font-semibold text-slate-100">Conversational Command Stream</h2>
          <p className="mt-1 text-xs text-slate-400">
            Natural commands without rigid phrasing
          </p>
        </div>

        {/* Quick Voice Command Presets */}
        <div className="mt-4 flex flex-wrap gap-2">
          {SAMPLE_COMMANDS.map((cmd) => (
            <button
              key={cmd}
              type="button"
              onClick={() => onSendCommand(cmd)}
              className="rounded-lg border border-slate-800 bg-[#070B14] px-3 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:border-blue-500/60 hover:text-white"
            >
              {cmd}
            </button>
          ))}
        </div>

        {/* Chat History */}
        <div className="mt-5 flex h-[390px] flex-col gap-3 overflow-y-auto pr-1">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`rounded-xl border p-4 ${
                  isUser
                    ? 'ml-8 border-blue-600/40 bg-[#0D1629]'
                    : 'mr-8 border-slate-800 bg-[#070B14]'
                }`}
              >
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className={isUser ? 'font-semibold text-sky-400' : 'font-semibold text-blue-400'}>
                    {isUser ? 'You' : memory.assistantName}
                  </span>
                  <span className="font-mono tabular-nums text-slate-500">{msg.timestamp}</span>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-slate-100">{msg.text}</p>

                {msg.taskReport && (
                  <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 border-t border-slate-800/80 pt-2 text-xs text-slate-400">
                    <span className={msg.taskReport.succeeded ? 'text-emerald-400' : 'text-amber-400'}>
                      {msg.taskReport.succeeded ? 'Executed' : 'Not Executed'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{msg.taskReport.identifiedAction}</span>
                    <span aria-hidden="true">·</span>
                    <span>{msg.taskReport.requiredPermission}</span>
                  </div>
                )}

                {msg.pendingConfirmation && (
                  <div className="mt-3 flex items-center gap-3 border-t border-slate-800/80 pt-3">
                    <button
                      type="button"
                      onClick={() => onSendCommand(msg.pendingConfirmation!.rawCommand, true)}
                      className="rounded-lg bg-blue-600 px-3.5 py-1.5 text-xs font-medium text-white hover:bg-blue-500"
                    >
                      Approve &amp; Send
                    </button>
                    <span className="text-xs text-slate-400">Explicit confirmation required</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Text Command Composer */}
        <form onSubmit={handleSubmit} className="mt-4 flex items-center gap-3 border-t border-slate-800/80 pt-4">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Bol kar ya likh kar poochein (e.g. Ali ko bata do main busy hoon)..."
            className="min-h-[44px] flex-1 rounded-xl border border-slate-800 bg-[#070B14] px-4 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
          />
          <button
            type="submit"
            className="flex min-h-[44px] items-center gap-2 rounded-xl bg-blue-600 px-5 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
          >
            <Send className="h-4 w-4" />
            <span>Send</span>
          </button>
        </form>
      </section>
    </div>
  );
}
