import { useEffect, useState } from 'react';
import { OrbState } from '../types/assistant';
import { SmwEmblem } from './SmwEmblem';

interface JarvisOrbProps {
  state: OrbState;
  assistantName: string;
  onToggleListen: () => void;
  onInterrupt: () => void;
}

export function JarvisOrb({
  state,
  assistantName,
  onToggleListen,
  onInterrupt,
}: JarvisOrbProps) {
  const [bars, setBars] = useState<number[]>(() => Array.from({ length: 28 }, () => 14));

  useEffect(() => {
    const intervalMs = state === 'IDLE' ? 240 : 90;
    const id = window.setInterval(() => {
      setBars((prev) =>
        prev.map((_, idx) => {
          if (state === 'IDLE') {
            return 10 + Math.round(Math.sin(Date.now() / 600 + idx * 0.4) * 4);
          }
          if (state === 'THINKING') {
            return 18 + Math.round(Math.cos(Date.now() / 180 + idx * 0.5) * 12);
          }
          return 12 + Math.round(Math.random() * 32);
        }),
      );
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [state]);

  const statusText =
    state === 'LISTENING'
      ? 'Listening for voice command'
      : state === 'THINKING'
        ? 'Parsing intent & checking permissions'
        : state === 'SPEAKING'
          ? 'Speaking — tap to interrupt'
          : `${assistantName} ready`;

  return (
    <div className="flex flex-col items-center gap-5">
      <button
        type="button"
        onClick={state === 'SPEAKING' ? onInterrupt : onToggleListen}
        aria-label={statusText}
        className="group relative flex h-52 w-52 items-center justify-center rounded-full border border-slate-800 bg-[#070B14] transition-transform duration-200 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
      >
        <div
          className={`absolute inset-2 rounded-full border transition-colors duration-200 ${
            state === 'LISTENING'
              ? 'border-sky-400/80'
              : state === 'SPEAKING'
                ? 'border-blue-500'
                : state === 'THINKING'
                  ? 'border-blue-400/60'
                  : 'border-slate-800'
          }`}
        />

        <div className="relative h-36 w-36 overflow-hidden rounded-full border border-slate-800/80 bg-[#05070B]">
          <SmwEmblem
            alt={`${assistantName} official emblem`}
            compact
            className={`h-full w-full object-cover transition-transform duration-300 ${
              state === 'LISTENING' || state === 'SPEAKING' ? 'scale-105' : 'scale-100'
            }`}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#05070B]/60 via-transparent to-transparent" />
        </div>
      </button>

      {/* Voice Waveform */}
      <div className="flex h-12 items-center justify-center gap-1" aria-hidden="true">
        {bars.map((height, index) => (
          <span
            key={index}
            style={{ transform: `scaleY(${Math.max(0.2, height / 44)})` }}
            className={`h-10 w-1 origin-center rounded-full transition-transform duration-100 ${
              state === 'LISTENING'
                ? 'bg-sky-400'
                : state === 'SPEAKING'
                  ? 'bg-blue-500'
                  : state === 'THINKING'
                    ? 'bg-blue-300'
                    : 'bg-slate-700'
            }`}
          />
        ))}
      </div>

      <p className="text-sm font-medium text-sky-400">{statusText}</p>
    </div>
  );
}
