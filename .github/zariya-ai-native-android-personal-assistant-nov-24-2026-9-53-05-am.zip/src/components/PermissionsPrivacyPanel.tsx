import { useState } from 'react';
import { Shield, Trash2, Check, X } from 'lucide-react';
import {
  AssistantMemory,
  PermissionRecord,
  PreferredLanguage,
  VoiceGender,
} from '../types/assistant';

interface PermissionsPrivacyPanelProps {
  permissions: PermissionRecord[];
  memory: AssistantMemory;
  onTogglePermission: (id: string) => void;
  onUpdateMemory: (patch: Partial<AssistantMemory>) => void;
  onClearMemory: () => void;
}

export function PermissionsPrivacyPanel({
  permissions,
  memory,
  onTogglePermission,
  onUpdateMemory,
  onClearMemory,
}: PermissionsPrivacyPanelProps) {
  const [newContact, setNewContact] = useState('');

  const grantedCount = permissions.filter((p) => p.granted).length;

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
      {/* Left: Transparent Permission Dashboard */}
      <section className="flex flex-col gap-5 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-7">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-100">
              Transparent Permission Management
            </h2>
            <p className="text-xs text-slate-400">
              Every permission is optional · Features verify real authorization before executing
            </p>
          </div>
          <span className="font-mono text-xs tabular-nums text-sky-400">
            {grantedCount} / {permissions.length} Allowed
          </span>
        </div>

        <div className="divide-y divide-slate-800/70">
          {permissions.map((perm) => (
            <div
              key={perm.id}
              className="flex flex-col justify-between gap-3 py-4 first:pt-0 last:pb-0 sm:flex-row sm:items-center"
            >
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-medium text-slate-100">{perm.title}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-xs text-slate-400">{perm.category}</span>
                </div>
                <p className="font-mono text-xs text-slate-500">{perm.androidPermission}</p>
                <p className="text-xs text-slate-400">{perm.reason}</p>
              </div>

              <div className="flex shrink-0 items-center gap-2">
                <button
                  type="button"
                  onClick={() => onTogglePermission(perm.id)}
                  className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border px-3.5 py-1.5 text-xs font-medium transition-colors ${
                    perm.granted
                      ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300 hover:bg-emerald-950/50'
                      : 'border-blue-500 bg-blue-600 text-white hover:bg-blue-500'
                  }`}
                >
                  {perm.granted ? (
                    <>
                      <Check className="h-3.5 w-3.5" />
                      <span>Allowed (Revoke)</span>
                    </>
                  ) : (
                    <>
                      <X className="h-3.5 w-3.5" />
                      <span>Allow</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Right: AI Memory & Personalization */}
      <section className="flex flex-col gap-6 rounded-2xl border border-slate-800/90 bg-[#0B101B] p-6 lg:col-span-5">
        <div className="border-b border-slate-800/80 pb-4">
          <h2 className="text-lg font-semibold text-slate-100">
            AI Memory &amp; Personalization
          </h2>
          <p className="text-xs text-slate-400">
            Encrypted local preferences in Android EncryptedSharedPreferences
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-slate-300">Assistant Name</label>
            <input
              type="text"
              value={memory.assistantName}
              onChange={(e) => onUpdateMemory({ assistantName: e.target.value || 'FAIZAN AI' })}
              className="mt-1.5 w-full rounded-xl border border-slate-800 bg-[#070B14] px-3.5 py-2.5 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300">Custom Wake Phrase</label>
            <input
              type="text"
              value={memory.wakePhrase}
              onChange={(e) => onUpdateMemory({ wakePhrase: e.target.value })}
              className="mt-1.5 w-full rounded-xl border border-slate-800 bg-[#070B14] px-3.5 py-2.5 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
            />
            <p className="mt-1.5 text-[11px] text-sky-400">
              Active wake words: Hey Siri · Hey AI · Hello AI · Faizan AI · Okay AI
            </p>
            <label className="mt-2 flex items-center gap-2 text-xs text-slate-400">
              <input
                type="checkbox"
                checked={memory.wakeWordRequired}
                onChange={(e) => onUpdateMemory({ wakeWordRequired: e.target.checked })}
                className="accent-blue-600"
              />
              <span>Require wake phrase in continuous Hands-Free mode</span>
            </label>
            <label className="mt-2 flex items-center gap-2 text-xs text-slate-400">
              <input
                type="checkbox"
                checked={memory.readWhatsAppAloud}
                onChange={(e) => onUpdateMemory({ readWhatsAppAloud: e.target.checked })}
                className="accent-blue-600"
              />
              <span>Announce new incoming WhatsApp messages aloud</span>
            </label>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300">Voice Persona</label>
            <div className="mt-1.5 grid grid-cols-2 gap-2">
              {(
                [
                  { id: 'punjabi_legend', label: 'Punjabi Legend (Deep)' },
                  { id: 'standard', label: 'Standard Assistant' },
                ] as const
              ).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() =>
                    onUpdateMemory({
                      voicePersona: opt.id,
                      voiceGender: opt.id === 'punjabi_legend' ? 'MALE' : memory.voiceGender,
                    })
                  }
                  className={`min-h-[40px] rounded-xl border px-3 py-2 text-xs font-medium transition-colors ${
                    (memory.voicePersona || 'punjabi_legend') === opt.id
                      ? 'border-blue-500 bg-blue-600/20 text-sky-300'
                      : 'border-slate-800 bg-[#070B14] text-slate-300'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300">Voice Output Option</label>
            <div className="mt-1.5 grid grid-cols-2 gap-2">
              {(['MALE', 'FEMALE'] as VoiceGender[]).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() =>
                    onUpdateMemory({
                      voiceGender: g,
                      voicePersona: g === 'FEMALE' ? 'standard' : memory.voicePersona || 'punjabi_legend',
                    })
                  }
                  className={`min-h-[40px] rounded-xl border px-3 py-2 text-xs font-medium transition-colors ${
                    memory.voiceGender === g
                      ? 'border-blue-500 bg-blue-600/20 text-sky-300'
                      : 'border-slate-800 bg-[#070B14] text-slate-300'
                  }`}
                >
                  {g === 'MALE' ? 'Male (Fenrir / Charon)' : 'Female (Fast & Clear · Kore)'}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300">Preferred Language</label>
            <select
              value={memory.preferredLanguage}
              onChange={(e) =>
                onUpdateMemory({ preferredLanguage: e.target.value as PreferredLanguage })
              }
              className="mt-1.5 w-full rounded-xl border border-slate-800 bg-[#070B14] px-3.5 py-2.5 text-sm text-slate-100 focus:border-blue-500 focus:outline-none"
            >
              <option value="auto">Auto-Detect (Punjabi · Urdu · Hindi · English)</option>
              <option value="pa-IN">Punjabi (ਪੰਜਾਬੀ / Roman Punjabi)</option>
              <option value="ur-PK">Urdu</option>
              <option value="hi-IN">Hindi</option>
              <option value="en-US">English</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300">Priority Contacts</label>
            <div className="mt-1.5 flex gap-2">
              <input
                type="text"
                value={newContact}
                onChange={(e) => setNewContact(e.target.value)}
                placeholder="Add contact name (e.g. Saad)"
                className="flex-1 rounded-xl border border-slate-800 bg-[#070B14] px-3 py-2 text-xs text-slate-100"
              />
              <button
                type="button"
                onClick={() => {
                  if (!newContact.trim()) return;
                  if (!memory.priorityContacts.includes(newContact.trim())) {
                    onUpdateMemory({
                      priorityContacts: [...memory.priorityContacts, newContact.trim()],
                    });
                  }
                  setNewContact('');
                }}
                className="rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-medium text-white hover:bg-blue-500"
              >
                Add
              </button>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              {memory.priorityContacts.map((contact) => (
                <button
                  key={contact}
                  type="button"
                  onClick={() =>
                    onUpdateMemory({
                      priorityContacts: memory.priorityContacts.filter((c) => c !== contact),
                    })
                  }
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-[#070B14] px-2.5 py-1 text-xs text-slate-300 hover:border-red-500/50 hover:text-red-300"
                >
                  <span>{contact}</span>
                  <X className="h-3 w-3" />
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-auto space-y-3 border-t border-slate-800/80 pt-4">
          <div className="flex items-start gap-2.5 text-xs text-slate-400">
            <Shield className="mt-0.5 h-4 w-4 shrink-0 text-sky-400" />
            <p>
              No silent background spying, no bypassing Android security, and no unauthorized calls or outgoing messages.
            </p>
          </div>
          <button
            type="button"
            onClick={onClearMemory}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/40 bg-red-950/20 px-4 py-2.5 text-xs font-medium text-red-300 hover:bg-red-950/40"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Clear Local Assistant Memory</span>
          </button>
        </div>
      </section>
    </div>
  );
}
