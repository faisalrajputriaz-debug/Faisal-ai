import { useState } from 'react';

export const SMW_IDENTITY_IMAGE =
  '/assets/aistudio/file_00000000e97c8211a3f2c82e9e614608_cfee5c79.png';

interface SmwEmblemProps {
  alt?: string;
  className?: string;
  compact?: boolean;
}

export function SmwEmblem({
  alt = 'SMW AI Official Identity',
  className = 'h-full w-full object-contain',
  compact = false,
}: SmwEmblemProps) {
  const [imgFailed, setImgFailed] = useState(false);

  if (!imgFailed) {
    return (
      <img
        src={SMW_IDENTITY_IMAGE}
        alt={alt}
        referrerPolicy="no-referrer"
        onError={() => setImgFailed(true)}
        className={className}
      />
    );
  }

  return (
    <div
      role="img"
      aria-label={alt}
      className="relative flex h-full w-full select-none flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-[#041028] via-[#06183A] to-[#02050D] text-white"
    >
      <svg
        viewBox="0 0 240 240"
        className="h-full w-full"
        aria-hidden="true"
      >
        <defs>
          <radialGradient id="smwAura" cx="50%" cy="42%" r="54%">
            <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.45" />
            <stop offset="55%" stopColor="#1E88FF" stopOpacity="0.18" />
            <stop offset="100%" stopColor="#02050D" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="smwRing" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38BDF8" />
            <stop offset="50%" stopColor="#1E88FF" />
            <stop offset="100%" stopColor="#0EA5E9" />
          </linearGradient>
          <linearGradient id="smwWing" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#E2E8F0" />
            <stop offset="100%" stopColor="#38BDF8" />
          </linearGradient>
        </defs>
        <rect width="240" height="240" fill="#030816" />
        <circle cx="120" cy="112" r="98" fill="url(#smwAura)" />
        <circle
          cx="120"
          cy="112"
          r="84"
          fill="none"
          stroke="url(#smwRing)"
          strokeWidth="3.5"
          opacity="0.88"
        />
        <circle
          cx="120"
          cy="112"
          r="72"
          fill="none"
          stroke="#38BDF8"
          strokeWidth="1"
          strokeDasharray="6 6"
          opacity="0.45"
        />
        {/* Crown crest */}
        <path
          d="M96 58 L104 42 L120 52 L136 42 L144 58 Z"
          fill="#F59E0B"
          stroke="#FDE68A"
          strokeWidth="1.5"
        />
        {/* Stylized Wings */}
        <path
          d="M36 126 L68 112 L62 128 L74 138 L42 142 Z"
          fill="url(#smwWing)"
          opacity="0.9"
        />
        <path
          d="M204 126 L172 112 L178 128 L166 138 L198 142 Z"
          fill="url(#smwWing)"
          opacity="0.9"
        />
        {/* Emblem Wordmark */}
        <text
          x="120"
          y={compact ? '126' : '122'}
          textAnchor="middle"
          fill="#FFFFFF"
          fontFamily="Plus Jakarta Sans, sans-serif"
          fontWeight="800"
          fontSize={compact ? '36' : '38'}
          letterSpacing="2"
        >
          SMW
        </text>
        {!compact && (
          <>
            <text
              x="120"
              y="156"
              textAnchor="middle"
              fill="#38BDF8"
              fontFamily="Plus Jakarta Sans, sans-serif"
              fontWeight="800"
              fontSize="26"
              letterSpacing="5"
            >
              AI
            </text>
            <text
              x="120"
              y="186"
              textAnchor="middle"
              fill="#CBD5E1"
              fontFamily="DM Sans, sans-serif"
              fontWeight="600"
              fontSize="10"
              letterSpacing="2.2"
            >
              SMART COMPANION
            </text>
          </>
        )}
      </svg>
    </div>
  );
}
