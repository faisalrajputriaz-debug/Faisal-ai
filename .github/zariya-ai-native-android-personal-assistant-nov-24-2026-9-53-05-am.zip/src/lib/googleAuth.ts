import { FirebaseOptions, getApp, getApps, initializeApp } from 'firebase/app';
import {
  Auth,
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User,
} from 'firebase/auth';
import firebaseConfigData from 'virtual:smw-firebase-config';

const firebaseConfig: FirebaseOptions =
  firebaseConfigData && typeof firebaseConfigData === 'object' ? firebaseConfigData : {};

let authInstance: Auth | null = null;
try {
  if (firebaseConfig.apiKey && firebaseConfig.projectId) {
    const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    authInstance = getAuth(app);
  }
} catch {
  authInstance = null;
}

export const auth = authInstance;

const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/userinfo.profile');
provider.addScope('https://www.googleapis.com/auth/userinfo.email');
provider.setCustomParameters({ prompt: 'select_account' });

// Keep OAuth access token and enriched profile strictly in JS memory.
let cachedAccessToken: string | null = null;
let cachedProfile: AuthenticatedProfile | null = null;
let isSigningIn = false;

export interface AuthenticatedProfile {
  uid: string;
  displayName: string;
  givenName: string;
  email: string;
  photoURL: string | null;
}

function buildProfileFromUser(
  user: User,
  overrides?: { givenName?: string; name?: string; email?: string; picture?: string },
): AuthenticatedProfile {
  const providerProfile = user.providerData?.[0];
  const rawDisplayName =
    overrides?.name?.trim() ||
    user.displayName?.trim() ||
    providerProfile?.displayName?.trim() ||
    '';
  const rawEmail =
    overrides?.email?.trim() ||
    user.email?.trim() ||
    providerProfile?.email?.trim() ||
    '';
  const rawGivenName =
    overrides?.givenName?.trim() ||
    (rawDisplayName ? rawDisplayName.split(/\s+/)[0] : '');

  return {
    uid: user.uid,
    displayName: rawDisplayName,
    givenName: rawGivenName,
    email: rawEmail,
    photoURL: overrides?.picture || user.photoURL || providerProfile?.photoURL || null,
  };
}

export function getGreetingFirstName(profile: AuthenticatedProfile | null): string | null {
  if (!profile) return null;
  if (profile.givenName.trim()) {
    return profile.givenName.trim();
  }
  if (profile.displayName.trim()) {
    return profile.displayName.trim().split(/\s+/)[0];
  }
  if (profile.email.includes('@')) {
    const localPart = profile.email.split('@')[0]?.replace(/[._-]+/g, ' ').trim();
    if (localPart) {
      const firstToken = localPart.split(/\s+/)[0];
      return firstToken.charAt(0).toUpperCase() + firstToken.slice(1);
    }
  }
  return null;
}

export function initAuth(
  onSignedIn: (profile: AuthenticatedProfile) => void,
  onSignedOut: () => void,
): () => void {
  if (!authInstance) {
    onSignedOut();
    return () => {};
  }
  return onAuthStateChanged(
    authInstance,
    (user) => {
      if (user) {
        if (isSigningIn) return;
        const profile =
          cachedProfile && cachedProfile.uid === user.uid
            ? cachedProfile
            : buildProfileFromUser(user);
        cachedProfile = profile;
        onSignedIn(profile);
      } else {
        cachedAccessToken = null;
        cachedProfile = null;
        onSignedOut();
      }
    },
    () => {
      cachedAccessToken = null;
      cachedProfile = null;
      onSignedOut();
    },
  );
}

export async function googleSignIn(): Promise<AuthenticatedProfile> {
  if (!authInstance) {
    throw new Error('Google Sign-In is unavailable because Firebase Auth is not configured.');
  }
  isSigningIn = true;
  try {
    const result = await signInWithPopup(authInstance, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    cachedAccessToken = credential?.accessToken ?? null;

    let userInfoOverrides:
      | { givenName?: string; name?: string; email?: string; picture?: string }
      | undefined;

    if (cachedAccessToken) {
      try {
        const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
          headers: { Authorization: `Bearer ${cachedAccessToken}` },
        });
        if (res.ok) {
          const info = (await res.json()) as {
            given_name?: string;
            name?: string;
            email?: string;
            picture?: string;
          };
          userInfoOverrides = {
            givenName: info.given_name,
            name: info.name,
            email: info.email,
            picture: info.picture,
          };
        }
      } catch {
        // Fallback to Firebase Auth user profile fields below
      }
    }

    const profile = buildProfileFromUser(result.user, userInfoOverrides);
    cachedProfile = profile;
    return profile;
  } finally {
    isSigningIn = false;
  }
}

export async function getAccessToken(): Promise<string | null> {
  return cachedAccessToken;
}

export async function logout(): Promise<void> {
  cachedAccessToken = null;
  cachedProfile = null;
  if (authInstance) {
    await signOut(authInstance);
  }
}
