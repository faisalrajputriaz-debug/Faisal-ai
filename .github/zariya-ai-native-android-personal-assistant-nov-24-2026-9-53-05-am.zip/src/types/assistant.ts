export type OrbState = 'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING';

export type VoiceGender = 'MALE' | 'FEMALE';

export type VoicePersona = 'punjabi_legend' | 'standard';

export type PreferredLanguage = 'auto' | 'pa-IN' | 'ur-PK' | 'hi-IN' | 'en-US';

export type AutoReplyAudience =
  | 'SELECTED_CONTACTS_ONLY'
  | 'PRIORITY_CONTACTS_ONLY'
  | 'EVERYONE_EXPLICIT';

export interface AssistantMemory {
  assistantName: string;
  wakePhrase: string;
  wakeWordRequired: boolean;
  voiceGender: VoiceGender;
  voicePersona?: VoicePersona;
  preferredLanguage: PreferredLanguage;
  priorityContacts: string[];
  templates: string[];
  readWhatsAppAloud: boolean;
  recordMicWithScreen: boolean;
}

export interface PermissionRecord {
  id: string;
  title: string;
  androidPermission: string;
  category: 'Runtime' | 'Special System Access' | 'System Role';
  reason: string;
  granted: boolean;
}

export interface TaskExecutionReport {
  userRequest: string;
  identifiedAction: string;
  requiredPermission: string;
  actionPerformed: string;
  succeeded: boolean;
  failureReason?: string;
  executionSource: 'Local Native Engine' | 'Gemini AI';
  timestamp: string;
}

export interface ChatEntry {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  taskReport?: TaskExecutionReport;
  pendingConfirmation?: {
    rawCommand: string;
    prompt: string;
  };
}

export interface WhatsAppMessage {
  id: string;
  appSource: 'WhatsApp' | 'WhatsApp Business';
  sender: string;
  text: string;
  timestamp: string;
  isUrgent: boolean;
  urgencyReason?: string;
  aiDraftReply?: string;
  autoReplied: boolean;
  repliedText?: string;
}

export interface AutoReplyRule {
  enabled: boolean;
  audience: AutoReplyAudience;
  activeTemplate: string;
  scheduleEnabled: boolean;
  startHour: number;
  endHour: number;
  cooldownMinutes: number;
  askBeforeUnconfigured: boolean;
}

export interface CallConfig {
  enabled: boolean;
  announceCallerAloud: boolean;
  autoAnswerSelectedContacts: boolean;
  handsFreeMode: boolean;
  speakerphoneActive: boolean;
  busyNotice: string;
}

export interface CallSession {
  id: string;
  callerName: string | null;
  phoneNumber: string;
  status: 'RINGING' | 'ACTIVE' | 'REJECTED' | 'ENDED' | 'BUSY_NOTIFIED';
  aiDisclosureSent?: string;
}

export interface DailyTask {
  id: string;
  type: 'alarm' | 'timer' | 'note' | 'reminder';
  title: string;
  detail: string;
  createdAt: string;
}

export interface DeviceHardwareState {
  flashlightOn: boolean;
  volumePercent: number;
  mediaPlaying: boolean;
  mediaTrack: string;
  screenScrollIndex: number;
  activeScreenKey: 'whatsapp' | 'settings' | 'article';
  batteryPercent: number | null;
  batteryCharging: boolean;
  dndEnabled?: boolean;
}

export interface AndroidFileEntry {
  path: string;
  size: number;
}

