export interface LocalParsedCommand {
  intent: string;
  targetApp?: string;
  queryOrText?: string;
  targetContact?: string;
  requiredPermission: string;
  needsConfirmation: boolean;
  confirmationPrompt?: string;
  spokenReply: string;
}

export const SUPPORTED_WAKE_WORDS = [
  'hey siri',
  'hey ai',
  'hello ai',
  'faizan ai',
  'okay ai',
  'ok ai',
  'smw ai',
  'hey assistant',
] as const;

function escapeRegex(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function stripWakePrefix(
  rawText: string,
  customWakePhrase = '',
): { wakeWord: string | null; stripped: string } {
  const trimmed = rawText.trim();
  if (!trimmed) return { wakeWord: null, stripped: '' };

  const seen = new Set<string>();
  const candidates: string[] = [];
  for (const w of [customWakePhrase.trim(), ...SUPPORTED_WAKE_WORDS]) {
    const key = w.toLowerCase();
    if (key && !seen.has(key)) {
      seen.add(key);
      candidates.push(w);
    }
  }
  candidates.sort((a, b) => b.length - a.length);

  const lower = trimmed.toLowerCase();
  for (const wake of candidates) {
    const wakeLower = wake.toLowerCase();
    if (lower === wakeLower) {
      return { wakeWord: wake, stripped: '' };
    }
    const pattern = new RegExp(`^${escapeRegex(wakeLower)}[\\s,.:!?-]+(.+)$`, 'i');
    const match = trimmed.match(pattern);
    if (match) {
      return { wakeWord: wake, stripped: match[1].trim() };
    }
  }
  return { wakeWord: null, stripped: trimmed };
}

export function resolveKnownContacts(
  query: string,
  knownContacts: string[],
): { status: 'unique' | 'ambiguous' | 'unlisted'; matches: string[] } {
  const q = query.trim().toLowerCase();
  if (!q) return { status: 'unlisted', matches: [] };
  const uniqueKnown = Array.from(
    new Set(knownContacts.map((c) => c.trim()).filter(Boolean)),
  );
  const substringMatches = uniqueKnown.filter((c) => c.toLowerCase().includes(q));
  if (substringMatches.length > 1) {
    return { status: 'ambiguous', matches: substringMatches };
  }
  if (substringMatches.length === 1) {
    return { status: 'unique', matches: substringMatches };
  }
  return { status: 'unlisted', matches: [] };
}

const DEVICE_ACTION_VERBS =
  /\b(open|close|kholo|launch|scroll|neeche|uppar|upar|back|peeche|wapis|read|parho|explain|samjhao|flashlight|torch|volume|awaz|awaaz|mute|play|pause|stop|next|alarm|timer|reminder|note|record|recording|screenshot|screen|whatsapp|youtube|facebook|tiktok|gallery|photos|contacts|settings|camera|dialer|phone|call|sms|battery|silent|dnd|disturb|answer|reject|end|speaker|busy|reply|bata|bhej|bhejo|bolo|likho|search|share|home|notifications|dikhao|sunao)\b/i;

export function isLikelyDeviceAction(input: string, customWakePhrase = ''): boolean {
  const { stripped } = stripWakePrefix(input, customWakePhrase);
  const trimmed = stripped.trim();
  if (!trimmed) return false;
  if (
    /^(hi|hello|hey|salam|assalamualaikum|kya haal|kaise ho|how are you|who are you|what is|explain|tell me|help me|aaj ka mausam|weather)\b/i.test(
      trimmed,
    )
  ) {
    return false;
  }
  return DEVICE_ACTION_VERBS.test(trimmed);
}

function cleanMessageBody(raw: string): string {
  const cleaned = raw.trim();
  if (!cleaned) return '';
  return cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
}

export function parseLocalCommand(
  input: string,
  customWakePhrase = '',
): LocalParsedCommand | null {
  const { wakeWord, stripped } = stripWakePrefix(input, customWakePhrase);
  const text = stripped.trim().replace(/[.?!]+$/, '').trim();

  if (!text) {
    if (wakeWord) {
      return {
        intent: 'WAKE_ACK',
        requiredPermission: 'Microphone (RECORD_AUDIO)',
        needsConfirmation: false,
        spokenReply: 'Ji, boliye. Main sun rahi hoon.',
      };
    }
    return null;
  }

  const lower = text.toLowerCase();

  // 1. Auto-reply rule
  if (
    /\b(jis\s*kisi|everyone|sab\s*ko|auto\s*reply|busy\s*mode)\b/i.test(lower) &&
    /\b(message|whatsapp|busy|kaam)\b/i.test(lower)
  ) {
    return {
      intent: 'AUTO_REPLY_RULE',
      targetApp: 'WhatsApp',
      queryOrText: text,
      requiredPermission: 'NotificationListenerService',
      needsConfirmation: true,
      confirmationPrompt:
        'Kya main incoming WhatsApp messages par automatic busy reply on kar doon? Confirm karein.',
      spokenReply: 'WhatsApp auto-reply rule ke liye aapki confirmation chahiye.',
    };
  }

  // 2. Contact-specific WhatsApp open / read / reply read
  const contactOpenMsg = text.match(
    /^([a-zA-Z\u0600-\u06FF\s]{2,28}?)\s+ka\s+(?:message|msg|reply)\s+(?:open\s+karo|kholo)$/i,
  );
  if (contactOpenMsg) {
    const contact = contactOpenMsg[1].trim();
    return {
      intent: 'OPEN_CONTACT_MESSAGE',
      targetApp: 'WhatsApp',
      targetContact: contact,
      requiredPermission: 'NotificationListenerService',
      needsConfirmation: false,
      spokenReply: `${contact} ka WhatsApp message open kar raha hoon.`,
    };
  }

  const contactReadMsg =
    text.match(/^([a-zA-Z\u0600-\u06FF\s]{2,28}?)\s+ne\s+kya\s+message\s+bheja\s+hai$/i) ||
    text.match(
      /^([a-zA-Z\u0600-\u06FF\s]{2,28}?)\s+ka\s+(?:reply|message)\s+(?:parh\s+kar\s+sunao|parho|batao|sunao)$/i,
    );
  if (contactReadMsg) {
    const contact = contactReadMsg[1].trim();
    return {
      intent: 'READ_CONTACT_MESSAGE',
      targetApp: 'WhatsApp',
      targetContact: contact,
      requiredPermission: 'NotificationListenerService',
      needsConfirmation: false,
      spokenReply: `${contact} ka latest message:`,
    };
  }

  // 3. WhatsApp voice message to contact
  const voiceMsgMatch =
    text.match(
      /(?:whatsapp\s+par\s+)?([a-zA-Z\u0600-\u06FF\s]{2,28}?)\s+ko\s+voice\s+message\s+bhej(?:o|ein|na)/i,
    ) || text.match(/^send\s+(?:a\s+)?voice\s+message\s+to\s+([a-zA-Z\s]{2,28})$/i);
  if (voiceMsgMatch) {
    const contact = voiceMsgMatch[1].trim();
    return {
      intent: 'SEND_WHATSAPP_VOICE',
      targetApp: 'WhatsApp',
      targetContact: contact,
      requiredPermission: 'NotificationListenerService + READ_CONTACTS',
      needsConfirmation: true,
      confirmationPrompt: `Kya main ${contact} ki WhatsApp chat khol doon taake voice message bheja ja sake? Confirm karein.`,
      spokenReply: `${contact} ko voice message bhejne ke liye confirm karein.`,
    };
  }

  // 4. WhatsApp send / reply to contact (Urdu / Roman Urdu / Hindi / English)
  const romanWhatsApp = text.match(
    /^(?:whatsapp\s+par\s+)?([a-zA-Z\u0600-\u06FF\s]{2,28}?)\s+ko\s+(?:message\s+karo|message\s+bhejo|bata\s*do|likh\s*do|bolo|reply\s*(?:karo|bhej(?:\s*do)?))(?:\s+(?:ke|kay|ki))?(?:\s+(.+))?$/i,
  );
  if (romanWhatsApp) {
    const contact = romanWhatsApp[1].trim();
    const rawBody = romanWhatsApp[2]?.trim() || '';
    const msgBody = cleanMessageBody(rawBody) || 'Main abhi busy hoon, baad mein rabta karta hoon.';
    return {
      intent: 'REPLY_WHATSAPP',
      targetApp: 'WhatsApp',
      targetContact: contact,
      queryOrText: msgBody,
      requiredPermission: 'NotificationListenerService + RemoteInput',
      needsConfirmation: true,
      confirmationPrompt: `Kya main ${contact} ko WhatsApp message bhej doon: "${msgBody}"?`,
      spokenReply: `${contact} ke liye message tayyar hai: "${msgBody}". Bhejne ke liye confirm karein.`,
    };
  }

  const enWhatsApp = text.match(
    /^(?:send\s+(?:a\s+)?whatsapp\s+(?:message\s+)?to|reply\s+to|message|tell)\s+([a-zA-Z\s]{2,28}?)(?:\s+(?:that|saying)\s+(.+))?$/i,
  );
  if (
    enWhatsApp &&
    !/^(caller|everyone)$/i.test(enWhatsApp[1].trim())
  ) {
    const contact = enWhatsApp[1].trim();
    const rawBody = enWhatsApp[2]?.trim() || '';
    const msgBody = cleanMessageBody(rawBody) || 'I am currently busy, will reply soon.';
    return {
      intent: 'REPLY_WHATSAPP',
      targetApp: 'WhatsApp',
      targetContact: contact,
      queryOrText: msgBody,
      requiredPermission: 'NotificationListenerService + RemoteInput',
      needsConfirmation: true,
      confirmationPrompt: `Confirm sending WhatsApp message to ${contact}: "${msgBody}"?`,
      spokenReply: `Message prepared for ${contact}: "${msgBody}". Please confirm to send.`,
    };
  }

  // 5. WhatsApp show / read / complete follow-up / notifications
  if (/\b(complete|full|poora|mukammal)\s+message\s+(?:parho|read|sunao)\b/i.test(lower)) {
    return {
      intent: 'READ_WHATSAPP',
      targetApp: 'WhatsApp',
      queryOrText: 'full',
      requiredPermission: 'NotificationListenerService',
      needsConfirmation: false,
      spokenReply: 'Poora message:',
    };
  }

  if (
    /\b(mujhe\s+)?whatsapp\s+messages\s+dikhao\b/i.test(lower) ||
    /\bshow\s+(?:my\s+)?whatsapp\s+messages\b/i.test(lower)
  ) {
    return {
      intent: 'SHOW_WHATSAPP_MESSAGES',
      targetApp: 'WhatsApp',
      requiredPermission: 'NotificationListenerService',
      needsConfirmation: false,
      spokenReply: 'Aapke latest WhatsApp messages dikha raha hoon:',
    };
  }

  if (
    /\b(latest\s+unread|unread\s+messages|parh\s+kar\s+sunao|kis\s+ka\s+message|kis\s+ka\s+aaya|who\s+(?:just\s+)?messaged|read\s+(?:my\s+)?whatsapp)\b/i.test(
      lower,
    ) ||
    (/\bwhatsapp\b/i.test(lower) && /\b(read|parho|check|latest|message|messages)\b/i.test(lower))
  ) {
    return {
      intent: 'READ_WHATSAPP',
      targetApp: 'WhatsApp',
      requiredPermission: 'NotificationListenerService',
      needsConfirmation: false,
      spokenReply: 'Latest WhatsApp message:',
    };
  }

  if (
    /\b(read|check)\s+(?:all\s+)?notifications\b/i.test(lower) ||
    /\bnotifications\s+(?:parho|batao|check)\b/i.test(lower)
  ) {
    return {
      intent: 'READ_NOTIFICATIONS',
      requiredPermission: 'NotificationListenerService',
      needsConfirmation: false,
      spokenReply: 'Aapki recent notifications:',
    };
  }

  // 6. Phone call to contact & SMS with confirmation
  const callContactMatch =
    text.match(/^([a-zA-Z\u0600-\u06FF\s]{2,28}?)\s+ko\s+call\s+(?:lagao|karo|milao)$/i) ||
    text.match(/^(?:call|dial|phone)\s+([a-zA-Z\s]{2,28})$/i);
  if (callContactMatch && !/\b(answer|reject|end|incoming)\b/i.test(lower)) {
    const contact = callContactMatch[1].trim();
    return {
      intent: 'CALL_CONTACT',
      targetContact: contact,
      requiredPermission: 'ANSWER_PHONE_CALLS + Contacts',
      needsConfirmation: true,
      confirmationPrompt: `Kya main ${contact} ko phone call mila doon? Confirm karein.`,
      spokenReply: `${contact} ko call milane ke liye confirmation darkar hai.`,
    };
  }

  const smsMatch =
    text.match(/^(?:send\s+sms\s+to|sms)\s+([a-zA-Z\s]{2,28}?)(?:\s+(?:that|saying)\s+(.+))?$/i) ||
    text.match(/^([a-zA-Z\s]{2,28}?)\s+ko\s+sms\s+(?:bhejo|karo)(?:\s+(?:ke)\s+(.+))?$/i);
  if (smsMatch) {
    const contact = smsMatch[1].trim();
    const smsText = cleanMessageBody(smsMatch[2] || '') || 'Please call me back when free.';
    return {
      intent: 'SEND_SMS',
      targetContact: contact,
      queryOrText: smsText,
      requiredPermission: 'SMS Intent + Contacts',
      needsConfirmation: true,
      confirmationPrompt: `Kya main ${contact} ko SMS bhej doon: "${smsText}"?`,
      spokenReply: `${contact} ke liye SMS tayyar hai. Bhejne ke liye confirm karein.`,
    };
  }

  // 7. Flashlight / Torch
  if (/\b(flashlight|torch)\b/i.test(lower)) {
    const turnOff = /\b(off|band|disable|close)\b/i.test(lower);
    return {
      intent: turnOff ? 'FLASHLIGHT_OFF' : 'FLASHLIGHT_ON',
      requiredPermission: 'CAMERA',
      needsConfirmation: false,
      spokenReply: turnOff ? 'Flashlight band kar di hai.' : 'Flashlight on kar di hai.',
    };
  }

  // 8. Battery & Do Not Disturb / Silent mode
  if (/\b(battery|charge|battery\s*level|battery\s*percentage|charging|kitni\s+battery)\b/i.test(lower)) {
    return {
      intent: 'CHECK_BATTERY',
      requiredPermission: 'BatteryManager',
      needsConfirmation: false,
      spokenReply: 'Battery status check kar raha hoon:',
    };
  }

  if (/\b(do\s*not\s*disturb|dnd|silent\s*kar|phone\s*silent)\b/i.test(lower)) {
    const disable = /\b(off|disable|band|normal)\b/i.test(lower);
    return {
      intent: disable ? 'DISABLE_DND' : 'ENABLE_DND',
      requiredPermission: 'ACCESS_NOTIFICATION_POLICY',
      needsConfirmation: false,
      spokenReply: disable
        ? 'Do Not Disturb mode band kar diya hai.'
        : 'Do Not Disturb / Silent mode on kar diya hai.',
    };
  }

  // 9. Screen scroll & navigation
  if (/\b(go\s*home|home\s*screen|home\s*jao)\b/i.test(lower)) {
    return {
      intent: 'NAVIGATE_HOME',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Home screen par ja raha hoon.',
    };
  }

  if (/\b(scroll down|neeche scroll|niche scroll|scroll neeche)\b/i.test(lower)) {
    return {
      intent: 'SCROLL_DOWN',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Screen neeche scroll kar di hai.',
    };
  }

  if (/\b(scroll up|uppar scroll|upar scroll|scroll upar)\b/i.test(lower)) {
    return {
      intent: 'SCROLL_UP',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Screen upar scroll kar di hai.',
    };
  }

  if (/\b(go back|navigate back|peeche jao|wapis jao|wapas jao|back jao)\b/i.test(lower)) {
    return {
      intent: 'NAVIGATE_BACK',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Pichli screen par wapis ja raha hoon.',
    };
  }

  // 10. Screen reading
  if (
    /\b(read screen|what is on my screen|meri screen par kya|screen parho|explain screen|screen samjhao)\b/i.test(
      lower,
    )
  ) {
    return {
      intent: /explain|samjhao/i.test(lower) ? 'EXPLAIN_SCREEN' : 'READ_SCREEN',
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: 'Screen ka summary:',
    };
  }

  // 11. YouTube search & Web search
  const ytSearch = text.match(/youtube\s+(?:kholo\s+(?:aur\s+)?search\s+karo|par\s+search\s+karo|search(?:\s+for)?)\s+(.+)$/i);
  if (ytSearch) {
    const query = ytSearch[1].trim() || 'Lo-fi focus';
    return {
      intent: 'YOUTUBE_SEARCH',
      targetApp: 'YouTube',
      queryOrText: query,
      requiredPermission: 'Android Search Intent',
      needsConfirmation: false,
      spokenReply: `YouTube par "${query}" search kar diya hai.`,
    };
  }

  const webSearch = text.match(
    /^(?:search\s+(?:the\s+)?(?:internet|web|google)\s+(?:for\s+)?|google\s+(?:par\s+)?search\s+(?:karo\s+)?)(.+)$/i,
  );
  if (webSearch) {
    const query = webSearch[1].trim();
    return {
      intent: 'WEB_SEARCH',
      queryOrText: query,
      requiredPermission: 'Browser Intent',
      needsConfirmation: false,
      spokenReply: `Internet par "${query}" search kar diya hai.`,
    };
  }

  // 12. Camera capture, Gallery, Contacts, Share
  if (/\b(capture\s*(?:a\s*)?photo|take\s*(?:a\s*)?(?:photo|picture)|photo\s*kheencho|tasveer\s*banao)\b/i.test(lower)) {
    return {
      intent: 'CAPTURE_PHOTO',
      targetApp: 'Camera',
      requiredPermission: 'CAMERA',
      needsConfirmation: false,
      spokenReply: 'Photo capture ke liye Camera khol raha hoon.',
    };
  }

  if (/\b(open\s*gallery|open\s*photos|gallery\s*kholo|photos\s*kholo)\b/i.test(lower)) {
    return {
      intent: 'OPEN_GALLERY',
      targetApp: 'Gallery',
      requiredPermission: 'Gallery Intent',
      needsConfirmation: false,
      spokenReply: 'Gallery khol raha hoon.',
    };
  }

  if (/\b(open\s*contacts|contacts\s*kholo)\b/i.test(lower)) {
    return {
      intent: 'OPEN_CONTACTS',
      targetApp: 'Contacts',
      requiredPermission: 'READ_CONTACTS',
      needsConfirmation: false,
      spokenReply: 'Contacts khol raha hoon.',
    };
  }

  if (/\b(share\s*file|file\s*share)\b/i.test(lower)) {
    return {
      intent: 'SHARE_FILE',
      requiredPermission: 'Explicit Share Sheet',
      needsConfirmation: true,
      confirmationPrompt: 'Kya main file share karne ke liye Share Sheet khol doon? Confirm karein.',
      spokenReply: 'File share karne ke liye confirm karein.',
    };
  }

  // 13. Close apps & Open common apps
  const closeMatch =
    text.match(/^close\s+([a-zA-Z0-9\s]+)$/i) ||
    text.match(/^([a-zA-Z0-9\s]+?)\s+(?:band\s*karo|close\s*karo)$/i);
  if (closeMatch && !/\b(flashlight|torch|call)\b/i.test(closeMatch[1])) {
    const target = closeMatch[1].trim();
    return {
      intent: 'CLOSE_APP',
      targetApp: target,
      requiredPermission: 'AccessibilityService',
      needsConfirmation: false,
      spokenReply: `${target} band karke Home screen par ja raha hoon.`,
    };
  }

  const openMatch =
    text.match(/^(?:open|launch)\s+(whatsapp|facebook|tiktok|youtube|settings|camera|dialer|phone|gallery|contacts)$/i) ||
    text.match(/^(whatsapp|facebook|tiktok|youtube|settings|camera|dialer|phone|gallery|contacts)\s+(?:kholo|open\s*karo|chalao)$/i);
  if (openMatch) {
    const target = openMatch[1].toLowerCase();
    if (target === 'settings') {
      return {
        intent: 'OPEN_SETTINGS',
        targetApp: 'Settings',
        requiredPermission: 'Android Settings Intent',
        needsConfirmation: false,
        spokenReply: 'Device Settings khol raha hoon.',
      };
    }
    if (target === 'camera') {
      return {
        intent: 'OPEN_CAMERA',
        targetApp: 'Camera',
        requiredPermission: 'Android Intent',
        needsConfirmation: false,
        spokenReply: 'Camera khol raha hoon.',
      };
    }
    if (target === 'dialer' || target === 'phone') {
      return {
        intent: 'OPEN_DIALER',
        targetApp: 'Phone Dialer',
        requiredPermission: 'Android Intent',
        needsConfirmation: false,
        spokenReply: 'Phone dialer khol raha hoon.',
      };
    }
    if (target === 'gallery') {
      return {
        intent: 'OPEN_GALLERY',
        targetApp: 'Gallery',
        requiredPermission: 'Gallery Intent',
        needsConfirmation: false,
        spokenReply: 'Gallery khol raha hoon.',
      };
    }
    if (target === 'contacts') {
      return {
        intent: 'OPEN_CONTACTS',
        targetApp: 'Contacts',
        requiredPermission: 'READ_CONTACTS',
        needsConfirmation: false,
        spokenReply: 'Contacts khol raha hoon.',
      };
    }
    const properMap: Record<string, string> = {
      whatsapp: 'WhatsApp',
      youtube: 'YouTube',
      facebook: 'Facebook',
      tiktok: 'TikTok',
    };
    const properName = properMap[target] || target.charAt(0).toUpperCase() + target.slice(1);
    return {
      intent: 'OPEN_APP',
      targetApp: properName,
      requiredPermission: 'Launcher Intent',
      needsConfirmation: false,
      spokenReply: `${properName} khol raha hoon.`,
    };
  }

  // 14. Volume & Media
  if (/\b(volume up|increase volume|awaz barhao|awaaz zyada)\b/i.test(lower)) {
    return {
      intent: 'VOLUME_UP',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Volume barha diya hai.',
    };
  }
  if (/\b(volume down|decrease volume|awaz kam|awaaz kam)\b/i.test(lower)) {
    return {
      intent: 'VOLUME_DOWN',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Volume kam kar diya hai.',
    };
  }
  if (/\b(play music|play media|resume music|gaana chalao)\b/i.test(lower)) {
    return {
      intent: 'MEDIA_PLAY',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Media playback shuru kar diya hai.',
    };
  }
  if (/\b(pause music|pause media|stop music)\b/i.test(lower)) {
    return {
      intent: 'MEDIA_PAUSE',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Media pause kar diya hai.',
    };
  }
  if (/\b(next track|next song|agla gaana)\b/i.test(lower)) {
    return {
      intent: 'MEDIA_NEXT',
      requiredPermission: 'AudioManager',
      needsConfirmation: false,
      spokenReply: 'Agla track chala raha hoon.',
    };
  }

  // 15. Alarms, Timers & Notes
  if (/\b(?:set\s+(?:an\s+)?alarm|alarm\s+lagao)\b/i.test(lower)) {
    return {
      intent: 'SET_ALARM',
      queryOrText: text,
      requiredPermission: 'SET_ALARM / Local Encrypted Store',
      needsConfirmation: false,
      spokenReply: 'Alarm note kar liya hai.',
    };
  }

  if (/\b(?:set\s+(?:a\s+)?timer|timer\s+lagao)\b/i.test(lower)) {
    return {
      intent: 'SET_TIMER',
      queryOrText: text,
      requiredPermission: 'SET_ALARM / Local Encrypted Store',
      needsConfirmation: false,
      spokenReply: 'Timer set kar diya hai.',
    };
  }

  if (/\b(add\s*note|create\s*note|note\s*likho|take\s*a\s*note)\b/i.test(lower)) {
    return {
      intent: 'ADD_NOTE',
      queryOrText: text,
      requiredPermission: 'Local Encrypted Store',
      needsConfirmation: false,
      spokenReply: 'Note save kar diya hai.',
    };
  }

  if (/\b(remind\s*me|yaad\s*dilana|reminder\s*lagao)\b/i.test(lower)) {
    return {
      intent: 'ADD_REMINDER',
      queryOrText: text,
      requiredPermission: 'Local Encrypted Store',
      needsConfirmation: false,
      spokenReply: 'Reminder save kar diya hai.',
    };
  }

  // 16. Incoming Call Controls
  if (/\b(answer the call|pick up the call|call uthao|call receive)\b/i.test(lower)) {
    return {
      intent: 'ANSWER_CALL',
      requiredPermission: 'ANSWER_PHONE_CALLS / TelecomManager',
      needsConfirmation: false,
      spokenReply: 'Incoming call answer kar raha hoon.',
    };
  }
  if (/\b(reject the call|end the call|call band|call kaato)\b/i.test(lower)) {
    const isEnd = /\bend\b/i.test(lower);
    return {
      intent: isEnd ? 'END_CALL' : 'REJECT_CALL',
      requiredPermission: 'ANSWER_PHONE_CALLS / TelecomManager',
      needsConfirmation: true,
      confirmationPrompt: 'Confirm ending or rejecting the active phone call?',
      spokenReply: 'Call action ke liye confirmation darkar hai.',
    };
  }
  if (/\b(tell the caller i am busy|caller ko busy)\b/i.test(lower)) {
    return {
      intent: 'TELL_CALLER_BUSY',
      requiredPermission: 'ANSWER_PHONE_CALLS / TelecomManager',
      needsConfirmation: true,
      confirmationPrompt: 'Send AI busy disclosure notice to the caller?',
      spokenReply: 'Caller ko busy notice bhejne ke liye confirm karein.',
    };
  }

  // 17. Screen recording & screenshot
  if (/\bstart\s+screen\s+recording\b/i.test(lower)) {
    return {
      intent: 'START_RECORDING',
      requiredPermission: 'MediaProjection',
      needsConfirmation: false,
      spokenReply: 'Screen recording session Device Lab mein ready hai.',
    };
  }
  if (/\b(take a screenshot|capture screenshot)\b/i.test(lower)) {
    return {
      intent: 'CAPTURE_SCREENSHOT',
      requiredPermission: 'MediaProjection',
      needsConfirmation: false,
      spokenReply: 'Screenshot capture request Device Lab ko bhej di hai.',
    };
  }

  return null;
}
