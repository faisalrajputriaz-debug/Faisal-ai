/// <reference types="vite/client" />

declare module 'virtual:smw-firebase-config' {
  import type { FirebaseOptions } from 'firebase/app';
  const config: FirebaseOptions;
  export default config;
}
