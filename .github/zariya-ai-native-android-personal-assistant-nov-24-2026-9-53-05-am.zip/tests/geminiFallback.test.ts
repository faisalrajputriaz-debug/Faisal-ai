import test from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { AddressInfo } from "node:net";
import {
  DEFAULT_GEMINI_MODELS,
  enforceCommandConfirmationPolicy,
  executeWithGeminiFallback,
  isOriginAllowedForMutation,
  isSafeAndroidRelativePath,
  resolveGeminiModelConfig,
  safeDecodeRequestPath,
  sanitizeSecretStrings,
  validateUploadedImagePayload,
} from "../serverSecurity.ts";
import { app } from "../server.ts";
import {
  parseLocalCommand,
  resolveKnownContacts,
  stripWakePrefix,
} from "../src/utils/localCommandParser.ts";

test("1. Primary model success", async () => {
  const tried: string[] = [];
  const res = await executeWithGeminiFallback(
    async (model) => {
      tried.push(model);
      return `ok-${model}`;
    },
    { models: ["gemini-4-hydrogen", "gemini-3.1-flash-lite"] },
  );
  assert.equal(res.modelUsed, "gemini-4-hydrogen");
  assert.equal(res.result, "ok-gemini-4-hydrogen");
  assert.deepEqual(tried, ["gemini-4-hydrogen"]);
});

test("2. Primary 429 and fallback success", async () => {
  const res = await executeWithGeminiFallback(
    async (model) => {
      if (model === "gemini-4-hydrogen") {
        const err = new Error("429 Resource Exhausted") as Error & { status?: number };
        err.status = 429;
        throw err;
      }
      return "recovered";
    },
    { models: ["gemini-4-hydrogen", "gemini-3.1-flash-lite"] },
  );
  assert.equal(res.modelUsed, "gemini-3.1-flash-lite");
  assert.equal(res.result, "recovered");
});

test("3. Primary 503 and fallback success", async () => {
  const res = await executeWithGeminiFallback(
    async (model) => {
      if (model === "gemini-4-hydrogen") {
        const err = new Error("503 Service Unavailable") as Error & { status?: number };
        err.status = 503;
        throw err;
      }
      return "healthy";
    },
    { models: ["gemini-4-hydrogen", "gemini-3.1-flash-lite"] },
  );
  assert.equal(res.modelUsed, "gemini-3.1-flash-lite");
  assert.equal(res.result, "healthy");
});

test("4. Primary model error (404/model unavailable) and multi-fallback priority order", async () => {
  const order: string[] = [];
  const res = await executeWithGeminiFallback(
    async (model) => {
      order.push(model);
      if (model !== "model-c") throw new Error("404 model not found");
      return "c-ok";
    },
    { models: ["model-a", "model-b", "model-c"] },
  );
  assert.deepEqual(order, ["model-a", "model-b", "model-c"]);
  assert.equal(res.modelUsed, "model-c");
});

test("5. All models failing throws clean error", async () => {
  await assert.rejects(
    () =>
      executeWithGeminiFallback(
        async () => {
          throw new Error("Upstream offline");
        },
        { models: ["m1", "m2"] },
      ),
    /All Gemini models failed/,
  );
});

test("6. Empty, deprecated, or malformed environment configuration falls back safely to defaults", () => {
  assert.deepEqual(resolveGeminiModelConfig("").models, [...DEFAULT_GEMINI_MODELS]);
  assert.deepEqual(
    resolveGeminiModelConfig("gemini-1.5-flash, gemini-2.0-flash").models,
    [...DEFAULT_GEMINI_MODELS],
  );
  assert.deepEqual(
    resolveGeminiModelConfig("AQ.Ab8RN6LxbVBfa8RruZCeir5_9RdhBMPF90Teydjn17lGSlbFOw").models,
    [...DEFAULT_GEMINI_MODELS],
  );
  assert.deepEqual(
    resolveGeminiModelConfig("models/gemini-3.1-flash-lite", "models/gemini-4-hydrogen").models,
    ["gemini-4-hydrogen", "gemini-3.1-flash-lite"],
  );
});

test("7. Duplicate model names are deduplicated in exact priority order", () => {
  const cfg = resolveGeminiModelConfig("gemini-4-hydrogen, gemini-3.1-flash-lite, gemini-4-hydrogen");
  assert.deepEqual(cfg.models, ["gemini-4-hydrogen", "gemini-3.1-flash-lite"]);
});

test("8. Permanent authentication errors (401 / invalid key) do not retry fallback models", async () => {
  const tried: string[] = [];
  await assert.rejects(
    () =>
      executeWithGeminiFallback(
        async (model) => {
          tried.push(model);
          const err = new Error("API_KEY_INVALID") as Error & { status?: number };
          err.status = 401;
          throw err;
        },
        { models: ["m1", "m2"] },
      ),
    /Gemini authentication failed/,
  );
  assert.deepEqual(tried, ["m1"]);
});

test("9. Secret sanitization scrubs API keys, AQ tokens, and bearer tokens", () => {
  const cleaned = sanitizeSecretStrings(
    "Failed with AIzaSyDUMMYKEY1234567890ABCDEFG, AQ.Ab8RN6LxbVBfa8RruZCeir5_9RdhBMPF90Teydjn17lGSlbFOw and Bearer ya29.secret_tok_999",
  );
  assert.ok(!cleaned.includes("AIzaSy"));
  assert.ok(!cleaned.includes("AQ.Ab8RN6"));
  assert.ok(!cleaned.includes("ya29.secret_tok_999"));
});

test("10. Safe URI decoding blocks malformed URIs and double-encoded path traversal", () => {
  assert.equal(safeDecodeRequestPath("/%E0%A4%A").ok, false);
  assert.equal(safeDecodeRequestPath("/%252e%252e/server.ts").ok, false);
  assert.deepEqual(safeDecodeRequestPath("/api/health"), { ok: true, decoded: "/api/health" });
});

test("11. Image upload validator checks real magic bytes and rejects spoofed MIME types", () => {
  const fakeScript = Buffer.from("<script>alert(1)</script>").toString("base64");
  const bad = validateUploadedImagePayload(fakeScript, "image/jpeg");
  assert.equal(bad.ok, false);

  const validPng = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]).toString("base64");
  const okRes = validateUploadedImagePayload(validPng, "image/png");
  assert.equal(okRes.ok, true);
});

test("12. Server-side confirmation policy overrides injected needsConfirmation=false on high-risk actions", () => {
  const enforced = enforceCommandConfirmationPolicy({
    intent: "REPLY_WHATSAPP",
    needsConfirmation: false,
  });
  assert.equal(enforced.needsConfirmation, true);
});

test("13. Cross-origin mutation guard blocks foreign Origins while permitting same-host or native requests", () => {
  assert.equal(
    isOriginAllowedForMutation({ origin: "https://evil.example", host: "localhost:3000" }),
    false,
  );
  assert.equal(
    isOriginAllowedForMutation({ origin: "http://localhost:3000", host: "localhost:3000" }),
    true,
  );
  assert.equal(isOriginAllowedForMutation({ host: "localhost:3000" }), true);
  assert.equal(
    isOriginAllowedForMutation({
      origin: "http://127.0.0.1:8080",
      host: "localhost:3000",
      forwardedHost: "127.0.0.1",
    }),
    true,
  );
});

test("14. HTTP security middleware enforces locked files, malformed URIs, origin guard, and upload checks", async () => {
  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const port = (server.address() as AddressInfo).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  try {
    for (const lockedPath of ["/.env", "/server.ts", "/package.json", "/firebase-applet-config.json"]) {
      const r = await fetch(`${baseUrl}${lockedPath}`);
      assert.equal(r.status, 403, `${lockedPath} should return 403`);
    }

    const malformed = await fetch(`${baseUrl}/%E0%A4%A`);
    assert.equal(malformed.status, 400);

    const foreignPost = await fetch(`${baseUrl}/api/ai/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Origin: "https://attacker.invalid",
      },
      body: JSON.stringify({ message: "hi" }),
    });
    assert.equal(foreignPost.status, 403);

    const spoofedUpload = await fetch(`${baseUrl}/api/ai/analyze-screen`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        imageBase64: Buffer.from("<script>alert(1)</script>").toString("base64"),
        mimeType: "image/jpeg",
      }),
    });
    assert.equal(spoofedUpload.status, 400);

    const emptyScreenAnalyze = await fetch(`${baseUrl}/api/ai/analyze-screen`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: "Summarize" }),
    });
    assert.equal(emptyScreenAnalyze.status, 400);

    const healthRes = await fetch(`${baseUrl}/api/health`);
    assert.equal(healthRes.status, 200);
    const healthJson = (await healthRes.json()) as { ok: boolean; service: string };
    assert.equal(healthJson.ok, true);
    assert.equal(healthJson.service, "SMW AI");

    const treeRes = await fetch(`${baseUrl}/api/android/tree`);
    assert.equal(treeRes.status, 200);
    const treeJson = (await treeRes.json()) as { files: Array<{ path: string; size: number }> };
    assert.ok(Array.isArray(treeJson.files) && treeJson.files.length > 5);
    assert.ok(treeJson.files.some((f) => f.path === "app/src/main/AndroidManifest.xml"));
    assert.ok(treeJson.files.some((f) => f.path === "app/src/main/res/drawable-nodpi/smw_ai_avatar.png"));
    assert.ok(!treeJson.files.some((f) => f.path.includes("local.properties")));

    const avatarMetaRes = await fetch(
      `${baseUrl}/api/android/file?path=${encodeURIComponent("app/src/main/res/drawable-nodpi/smw_ai_avatar.png")}`,
    );
    assert.equal(avatarMetaRes.status, 200);
    const avatarMetaJson = (await avatarMetaRes.json()) as { path: string; content: string };
    assert.ok(avatarMetaJson.content.includes("Binary image asset"));

    const manifestRes = await fetch(
      `${baseUrl}/api/android/file?path=${encodeURIComponent("app/src/main/AndroidManifest.xml")}`,
    );
    assert.equal(manifestRes.status, 200);
    const manifestJson = (await manifestRes.json()) as { path: string; content: string };
    assert.ok(manifestJson.content.includes("<manifest"));

    const blockedLocalProps = await fetch(`${baseUrl}/api/android/file?path=local.properties`);
    assert.equal(blockedLocalProps.status, 403);

    const blockedTraversal = await fetch(`${baseUrl}/api/android/file?path=../server.ts`);
    assert.equal(blockedTraversal.status, 403);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});

test("15. isSafeAndroidRelativePath allowlists Android sources and blocks sensitive/traversal paths", () => {
  assert.equal(isSafeAndroidRelativePath("app/src/main/AndroidManifest.xml"), true);
  assert.equal(isSafeAndroidRelativePath("app/src/main/java/com/zariya/assistant/voice/VoiceEngine.kt"), true);
  assert.equal(isSafeAndroidRelativePath("gradle.properties"), true);
  assert.equal(isSafeAndroidRelativePath("local.properties"), false);
  assert.equal(isSafeAndroidRelativePath("keystore.properties"), false);
  assert.equal(isSafeAndroidRelativePath("app/google-services.json"), false);
  assert.equal(isSafeAndroidRelativePath("../server.ts"), false);
  assert.equal(isSafeAndroidRelativePath(".gradle/cache.kt"), false);
  assert.equal(isSafeAndroidRelativePath("signing/release.keystore"), false);
  assert.equal(isSafeAndroidRelativePath("/abs/path.kt"), false);
});

test("16. Confirmation policy enforces confirmation for CALL_CONTACT, SEND_SMS, SEND_WHATSAPP_VOICE, and SHARE_FILE", () => {
  for (const intent of ["CALL_CONTACT", "SEND_SMS", "SEND_WHATSAPP_VOICE", "SHARE_FILE"]) {
    const enforced = enforceCommandConfirmationPolicy({ intent, needsConfirmation: false });
    assert.equal(enforced.needsConfirmation, true, `${intent} must force needsConfirmation=true`);
  }
});

test("17. Multi-wake-word parser strips Hey Siri, Hey AI, Hello AI, Faizan AI, Okay AI and handles wake-only utterances", () => {
  for (const wake of ["Hey Siri", "Hey AI", "Hello AI", "Faizan AI", "Okay AI"]) {
    const stripped = stripWakePrefix(`${wake}, Ali ko message karo ke main abhi busy hoon.`);
    assert.ok(stripped.wakeWord, `Expected wake word hit for ${wake}`);
    assert.equal(stripped.stripped, "Ali ko message karo ke main abhi busy hoon.");

    const ackOnly = parseLocalCommand(wake);
    assert.equal(ackOnly?.intent, "WAKE_ACK");
  }
});

test("18. All 12 WhatsApp voice commands and device controls parse deterministically", () => {
  const cases: Array<[string, string, boolean?]> = [
    ["WhatsApp kholo.", "OPEN_APP", false],
    ["Mujhe WhatsApp messages dikhao.", "SHOW_WHATSAPP_MESSAGES", false],
    ["Mera latest message kis ka aaya hai?", "READ_WHATSAPP", false],
    ["Ali ka message open karo.", "OPEN_CONTACT_MESSAGE", false],
    ["Ali ne kya message bheja hai?", "READ_CONTACT_MESSAGE", false],
    ["Mujhe latest unread messages parh kar sunao.", "READ_WHATSAPP", false],
    ["WhatsApp par Ali ko message bhejo.", "REPLY_WHATSAPP", true],
    ["Ali ko message karo ke main busy hoon.", "REPLY_WHATSAPP", true],
    ["Ali ko bolo main kaam kar raha hoon.", "REPLY_WHATSAPP", true],
    ["Ali ko message karo ke tum kahan ho?", "REPLY_WHATSAPP", true],
    ["Ali ko voice message bhejo.", "SEND_WHATSAPP_VOICE", true],
    ["Ali ka reply parh kar sunao.", "READ_CONTACT_MESSAGE", false],
    ["Hey AI, Ali ko message karo ke main abhi busy hoon.", "REPLY_WHATSAPP", true],
    ["Ali ko call karo", "CALL_CONTACT", true],
    ["Send SMS to Ali saying I will call later", "SEND_SMS", true],
    ["Battery kitni hai?", "CHECK_BATTERY", false],
    ["Do Not Disturb on karo", "ENABLE_DND", false],
    ["Gallery kholo", "OPEN_GALLERY", false],
    ["Contacts kholo", "OPEN_CONTACTS", false],
    ["Photo kheencho", "CAPTURE_PHOTO", false],
    ["Google par search karo latest cricket score", "WEB_SEARCH", false],
    ["YouTube band karo", "CLOSE_APP", false],
  ];

  for (const [cmd, expectedIntent, expectedConfirm] of cases) {
    const parsed = parseLocalCommand(cmd);
    assert.ok(parsed, `Expected local parse match for: ${cmd}`);
    assert.equal(parsed.intent, expectedIntent, `Mismatch intent for "${cmd}"`);
    if (typeof expectedConfirm === "boolean") {
      assert.equal(parsed.needsConfirmation, expectedConfirm, `Mismatch confirmation for "${cmd}"`);
    }
  }
});

test("19. Contact ambiguity detection prevents messaging or calling the wrong contact", () => {
  const ambiguous = resolveKnownContacts("Ali", ["Ali", "Ali Raza", "Ammi"]);
  assert.equal(ambiguous.status, "ambiguous");
  assert.deepEqual(ambiguous.matches, ["Ali", "Ali Raza"]);

  const unique = resolveKnownContacts("Ali", ["Ali", "Ammi", "Office Manager"]);
  assert.equal(unique.status, "unique");
  assert.deepEqual(unique.matches, ["Ali"]);
});


