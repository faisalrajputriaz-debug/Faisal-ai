import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  const rootDir = import.meta.dirname;
  const firebaseConfigPath = path.resolve(rootDir, 'firebase-applet-config.json');
  let publicFirebaseConfig: Record<string, string> = {};

  try {
    if (fs.existsSync(firebaseConfigPath)) {
      const raw = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf-8')) as Record<string, unknown>;
      publicFirebaseConfig = {
        projectId: String(raw.projectId || ''),
        appId: String(raw.appId || ''),
        apiKey: String(raw.apiKey || ''),
        authDomain: String(raw.authDomain || ''),
        storageBucket: String(raw.storageBucket || ''),
        messagingSenderId: String(raw.messagingSenderId || ''),
        measurementId: String(raw.measurementId || ''),
      };
    }
  } catch {
    publicFirebaseConfig = {};
  }

  const virtualFirebaseId = 'virtual:smw-firebase-config';
  const resolvedVirtualFirebaseId = '\0' + virtualFirebaseId;

  return {
    plugins: [
      {
        name: 'smw-virtual-firebase-config',
        resolveId(id: string) {
          if (id === virtualFirebaseId) return resolvedVirtualFirebaseId;
          return undefined;
        },
        load(id: string) {
          if (id === resolvedVirtualFirebaseId) {
            return `export default ${JSON.stringify(publicFirebaseConfig)};`;
          }
          return undefined;
        },
      },
      react(),
      tailwindcss(),
    ],
    resolve: {
      alias: {
        '@': path.resolve(rootDir, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
